# Committee: NDQ.AX

**Date**: 2025-05-14
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-14",
  "vix": 18.62,
  "tnx": 4.528,
  "usdcny": 7.2057,
  "audcny": 4.6639
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂不加仓，待 Quant 信号翻转至中性以上再议"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 $45.50（较现价约 -6%）且 10Y 国债收益率维持 >4.5% → 减仓 50%（约 ¥12,000 CNY）"
  what_if_wrong:
    worst_case_pnl_cny: -4867
    recovery_estimate: "3-6 个月（若利率见顶回落，科技股估值修复可期）"

PERSONAL_NOTE:
  - 当前 NDQ.AX 持仓约占总资产 23%，浮亏仅 -1.87%，头寸规模适中、尚无止损压力。
  - 本次不新增资金，子弹 ¥13,310 全额保留，为更具确定性的机会（如黄金续配或指数回调）备弹。
  - 为什么不加仓比加仓好：Quant 明确 bearish（价格 2 年分位 88% 极高 + downtrend regime + 成交量萎缩 RVOL 0.69x），Macro 虽然 VIX 回落但 10Y 收益率飙升至 4.53% 对长久期科技资产是实质利空——两方都不支持现在追加。在 Quant 信号未翻转前，持有现仓是纪律最优解。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙升至4.53%（MoM +37%），金融条件收紧压制长久期资产
KEY_TAILWIND: VIX骤降至18.6（MoM -43%）恐慌消退，叠加美元走弱+实际利率下行，黄金有双击条件
ONE_LINER: 利率飙升与恐慌消退并存，维持现有仓位不激进加减，黄金可小仓位增配
```


---

## Round 1 — Independent Briefs


### Quant Analyst
```json
{
  "thought_process": "REGIME是事实背景为downtrend，需要基于数据自行判断方向。从现有数据看：价格2年分位88%极高，处于历史高位；RSI 66.53接近超买但未到70；价格虽高于MA120但REGIME判定其MA20低于MA120，长期趋势结构向下；成交量萎缩(RVOL=0.69x)显示反弹动力不足。根据判定标准，价格分位≥70%是bearish的条件之一，虽然RSI未超买且未跌破MA250，但结合极高的分位和downtrend的regime背景，高位回调压力显著。因此判断为bearish。STRENGTH定为6，因为分位极高但RSI未极端超买。"
}
```

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（上下文未标注集中度字段）
DRY_POWDER_CNY: ¥13,310
PNL_PCT: -1.87%
WORST_CASE_LOSS_PCT_AT_-20: ≈1%（NDQ.AX 头寸约 ¥5,230，跌20%损失≈¥1,046）
ONE_LINER: NDQ.AX 浮亏仅 -1.87%，现金充裕 ¥13,310，头寸规模温和，Dreaming 无追涨模式。如加仓建议不超过子弹 30%（≈¥4,000），但需先确认近 7 日是否已多次买入该资产。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-14 > cutoff 2024-12-31)

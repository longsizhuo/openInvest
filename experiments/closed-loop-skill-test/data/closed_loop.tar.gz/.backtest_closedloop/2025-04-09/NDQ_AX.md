# Committee: NDQ.AX

**Date**: 2025-04-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-09",
  "vix": 33.62,
  "tnx": 4.4,
  "usdcny": 7.3388,
  "audcny": 4.3697
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不下新单，观望为主"

RISK_PLAN:
  stop_loss_trigger: "若 NDQ.AX 跌破 $37.50 AUD（较现价再跌约 9.5%）且 VIX 持续 > 35 → 减仓现有持仓 20%（约 21 份）止损"
  what_if_wrong:
    worst_case_pnl_cny: "若跌至 $35 AUD，现有持仓浮亏扩大至约 ¥-5,500 CNY（含已亏 ¥-4,300）"
    recovery_estimate: "宏观逆风消退 + RSI 回升至 45 以上需 3-6 个月；若衰退落地则可能 9-12 个月"

PERSONAL_NOTE:
  - "NDQ.AX 已浮亏 -16.04%，叠加 510300 也亏 -4.56%，账户整体承压，剩余子弹 ¥26,610 必须珍惜——此时不宜向下跌趋势中加仓。"
  - "本次裁决不新增任何资金投入 NDQ.AX，子弹 100% 留存，占仓位比 0%。"
  - "RSI 31.86 已处超卖区域，此时割肉大概率卖在短期底部附近；但宏观利率飙升 + VIX 33.62 + Quant 确认 downtrend 三重利空下也不该抄底——纪律要求你耐心等 RSI 回升突破 40 + 价格站上 MA250（$45.11）再考虑回补。浮亏心态焦虑属正常，但恐慌割肉 + 追涨杀跌才是真正的亏损来源。"
  - "GOLD 浮盈 +10.55% 是当前唯一亮点，可视为组合对冲锚——宏观 risk_off 环境下黄金反而受益，无需动。"


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y国债收益率月内飙升+56%至4.40%，VIX高企33.62，债券市场剧烈重定价冲击风险资产估值
KEY_TAILWIND: 美元走弱（DXY -1.59%）叠加实际利率下行（TIP +2.48%），形成黄金双击环境
ONE_LINER: 利率飙升+恐慌升温，风险资产偏向减仓；黄金/商品受益于美元+实际利率双利好，可维持或小幅加仓


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 31.86 超卖，但下降趋势中反弹动能待验证
  - 价格低于MA250 -8.10%，MA20低于MA120 -6.40%，趋势向下
  - 相对成交量1.52x，30天回报-15.91%，市场波动加剧
ONE_LINER: 下降趋势下RSI超卖提供短期支撑，但价格未突破MA250 (45.11) 阻力，维持中性信号。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 7  
DRY_POWDER_CNY: ¥26,610  
PNL_PCT: -16.04%  
WORST_CASE_LOSS_PCT_AT_-20: 4.0%  
ONE_LINER: 浮亏超过 5%，建议减仓 20% 或限制新增建仓比例不超过子弹的 30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-09 > cutoff 2024-12-31)

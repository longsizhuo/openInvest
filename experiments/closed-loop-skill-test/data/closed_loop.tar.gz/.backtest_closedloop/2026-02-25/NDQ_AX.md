# Committee: NDQ.AX

**Date**: 2026-02-25
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-25",
  "vix": 17.93,
  "tnx": 4.048,
  "usdcny": 6.8831,
  "audcny": 4.8592
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "子弹耗尽，无可执行加仓计划。如有新增现金流且NDQ回落至$48以下（MA250下方5%）且放量企稳，可考虑首轮补入 ¥6,800（约资产5%）"

RISK_PLAN:
  stop_loss_trigger: "收盘价连续2日低于 $49.50 且 RVOL > 1.3x → 减仓30%（约41股）锁定浮盈"
  what_if_wrong:
    worst_case_pnl_cny: "约 ¥-6,800（NDQ从现价再跌20%时组合整体浮亏约5%，当前+4.3%浮盈提供缓冲）"
    recovery_estimate: "维持现有仓位不动，名义利率拐头或量能修复后3-6个月可望回升"

PERSONAL_NOTE:
  - 用户子弹归零，NDQ仓位25.1%处于中性区间，当前浮盈+4.3%提供安全垫，但无力加仓也无减仓信号
  - 本次建议占可用子弹0%（¥0现金），属纯持仓维持决议；新增现金流应优先考虑黄金——宏观面DXY破98+实际利率大幅回落构成经典双击，黄金仓位浮盈+77.6%印证逻辑正确
  - Quant诊断的 downtrend + 价位71%分位需警惕：名义利率升至4.05%对纳斯达克成长股估值构成直接压力，价格正贴着MA250（$52.05）测试支撑，此时不宜追加；若后续量能放大跌破MA250，执行止损预案减仓锁定利润


---

## Macro Strategist (shared)

**宏观评估 — 2026-06-26**

---

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 名义利率10Y升至4.05%（6个月+13.5%），对久期/成长资产估值构成压力
KEY_TAILWIND: DXY跌至97.7（近周期低位）+ TIP月涨10.9%实际利率大幅回落，黄金/商品获双击支撑
ONE_LINER: 美元走弱+实际利率下行是主线，但名义利率上行限制全面risk-on，整体维持偏中性配置，商品/黄金方向明确偏多
```

**要点拆解：**
- **VIX 17.93**（<20）近期从21回落，市场恐慌消退但未至极端乐观
- **名义-实际利率背离**：名义利率升+实际利率降→市场正在定价通胀预期上行（关税/财政扩张传导）
- **DXY 97.7** 已远离109高点，美元弱势趋势确立，利好全球风险偏好及以美元计价资产
- **黄金货币面**：DXY↓ + 实际利率↓ = 经典双击环境，宏观层面无headwind


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价位分位71%高位，但RSI 38.13未超买/超卖
  - 价格跌破MA250(52.0460)但成交量萎缩(RVOL 0.57x)，量能不足
  - 30天回报-8.16%，下跌趋势延续，MA20低于MA120 -5.42%
ONE_LINER: 下降趋势中价格高位回调，RSI中性偏低且量能不足，SIGNAL neutral，关键支撑MA250附近，跌破或反弹需观察量能变化。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: 25.1%
DRY_POWDER_CNY: ¥0
PNL_PCT: +4.30%
WORST_CASE_LOSS_PCT_AT_-20: -5.0%
ONE_LINER: NDQ集中度25%处健康区间，浮盈+4.3%无止损压力，子弹耗尽无法加仓，维持现仓即可。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-25 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-02-19
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-19",
  "vix": 15.27,
  "tnx": 4.535,
  "usdcny": 7.2786,
  "audcny": 4.624
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 若价格回落至MA120附近（约$44.3，距现价-13.7%）且RSI<45 → 可小仓试探 ¥5,000
    - 若价格进一步跌至$42以下 + VIX回落<18 + 美元指数回落<105 → 加仓 ¥8,000

RISK_PLAN:
  stop_loss_trigger: NDQ.AX跌破$46（-10.3%）且10Y收益率站稳4.6%以上 → 减仓50%
  what_if_wrong:
    worst_case_pnl_cny: ≈¥4,182（NDQ跌20%情景下整体组合浮亏）
    recovery_estimate: 4-6个月（若宏观紧缩周期延长可能更久）

PERSONAL_NOTE:
  - 当前持有NDQ.AX仓位88份，浮盈+2.29%（约$101 AUD），仓位轻且处于盈利状态，无需恐慌操作。
  - 本次不加仓，核心原因三重叠加：（1）价格分位99%且偏离MA120达+15.85%，突破15%警戒线，均值回归压力极大；（2）10Y收益率飙至4.53%+DXY破107，金融条件快速收紧，对高久期科技股构成直接利空；（3）VIX低于15处于极度自满区间——这三个因素同时出现时追高风险极高。
  - uptrend ACCUMULATE 检查清单：①MA120偏离+15.85% > 15% → 均值回归风险高，不适合加仓；②VIX虽低于15但并非从低位急升，暂无崩盘预警；③若30天后跌10%，在99%分位+宏观紧缩背景下加仓逻辑不成立。三条均指向不应在当前位置ACCUMULATE。
  - 子弹¥38,300充裕（占总资产37%），耐心等待回归均线或宏观转向再行动。纪律比时机更重要——宁可错过最后一段鱼尾，不要在99%分位上加码。


---

## Macro Strategist (shared)

**宏观信号输出**

SIGNAL: neutral
STRENGTH: 4
SCORE: 0
KEY_HEADWIND: 10Y收益率飙升至4.53%+DXY突破107+实际利率上行，金融条件快速收紧，对利率敏感资产及黄金构成双杀
KEY_TAILWIND: VIX跌至15下方(-35%MoM)，市场恐慌消退，短期风险偏好尚存
ONE_LINER: 收益率与美元双升的紧缩力量被低波动率掩盖，当前非加仓窗口，建议维持现有仓位、对高久期/黄金类资产保持防御性观望


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格分位99%，历史高位，均值回归风险极高
  - 价格偏离MA120 +15.85%，远超警戒线
  - RSI 57.31 中性，未超买但支撑力不足
ONE_LINER: 趋势仍在但位于极端高位，偏离度与分位显示强烈回调压力，信号为中性。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥38,300
PNL_PCT: +2.29%
WORST_CASE_LOSS_PCT_AT_-20: ≈4.1%（NDQ跌20%致整体亏≈¥4,182）
ONE_LINER: NDQ.AX浮盈+2.29%，子弹充裕（¥38,300占总资产37%），无追涨历史，风险可控；建议单次建仓不超子弹25%（≈¥9,575），保留足够应对后续机会的弹药。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-19 > cutoff 2024-12-31)

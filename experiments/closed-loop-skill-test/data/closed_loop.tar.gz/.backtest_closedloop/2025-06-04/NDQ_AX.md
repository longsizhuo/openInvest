# Committee: NDQ.AX

**Date**: 2025-06-04
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-04",
  "vix": 17.61,
  "tnx": 4.365,
  "usdcny": 7.2037,
  "audcny": 4.6327
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回落至 MA250 支撑（$45.97 附近，约 -7%），可启动首轮加仓 ¥3,000"
    - "若价格进一步跌至 $43 以下（前低区域），第二轮加仓 ¥3,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 $45.97（MA250）且 VIX 升破 22 → 减仓 50%（约 54 份）"
  what_if_wrong:
    worst_case_pnl_cny: "按 -20% 情景，当前持仓浮亏约 ¥-24,000（含金价联动影响）"
    recovery_estimate: "若触发 MA250 破位，预计 3-6 个月在宽松预期回归后修复"

PERSONAL_NOTE:
  - "当前 NDQ.AX 持仓仅 108 份，浮盈 +0.36%，仓位轻且几乎无成本压力，无需急于操作。"
  - "本轮建议金额为 ¥0，占可用子弹 0%；为用户保留全部 ¥12,010 等待价格回落至 MA250 区域再出手。"
  - "价格处于 2 年 89 分位高位，RSI 62 尚未超买但 MA20/MA120 仅差 0.36% 表明多空胶着——此时 '不做什么' 本身就是纪律：89 分位追入的风险远高于错过区间内小幅上行的遗憾。耐心等回踩 MA250（$45.97），那里才是风险收益比真正合理的入场点。"


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y收益率飙升至4.36%（MoM+41%），名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数跌至98.79（MoM-8.6%）+实际利率下行，黄金/商品获双重利好
ONE_LINER: VIX回落+美元走弱改善风险偏好，但利率急升形成对冲；黄金板块维持偏多，权益类维持观望
```

**补充判断**：名义利率暴涨但实际利率反向下行，说明市场定价的是"增长预期改善"而非"通胀恶化"——软着陆叙事主导。DXY 破 99 关口是重要信号，若持续走弱，黄金上方空间打开。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价位分位89%高位，估值风险偏高
  - RSI 62.19中性偏强，未超买
  - MA20与MA120仅差0.36%，趋势纠缠
ONE_LINER: REGIME区间震荡，高位分位但RSI未超买，信号中性，支撑MA250 45.97，阻力前高附近。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
DRY_POWDER_CNY: 12,010
PNL_PCT: +0.36%
WORST_CASE_LOSS_PCT_AT_-20: -4.86%
ONE_LINER: 当前持仓状态健康，浮盈为正，子弹充足，建议本次加仓使用不超过可投现金的50%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-04 > cutoff 2024-12-31)

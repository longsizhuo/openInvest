# Committee: NDQ.AX

**Date**: 2025-06-11
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-11",
  "vix": 17.26,
  "tnx": 4.412,
  "usdcny": 7.1802,
  "audcny": 4.6864
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回调至 MA250 支撑位 $46.07 附近（约跌 -6.8%），可试探加仓 ¥2,000-3,000"
    - "若价格跌破 $44 且 RSI < 35，可考虑第二档加仓 ¥3,000（需届时重新评估宏观信号）"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 $46.07（250日均线）且 ^VIX 升破 25 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: "若从现价 $49.43 回落 20%，持仓浮亏约 -¥19,200（当前持仓约 ¥25,000）"
    recovery_estimate: "2-4 个月（range_bound 区间内历史平均恢复周期）"

PERSONAL_NOTE:
  - 当前 NDQ.AX 持仓约 ¥25,000，浮盈仅 +0.34%，处于盈亏平衡附近，仓位健康无需调整。
  - Quant 判定 regime=range_bound 且价格处于 2 年分位 89%（偏贵区间），叠加 Macro 10Y 收益率飙升至 4.41% 对科技股估值构成名义利率压力——在中性信号 + 高估值组合下，不追加是纪律。
  - 三方一致 neutral/ok，无分歧、无强信号——"没有信号"本身就是最好的信号：守住现有仓位、保留子弹 $11,010 等待 range_bound 下沿或更清晰的方向确认。**价格离 MA120 仅 +1.46%，均线纠缠阶段耐心比行动更有价值。**


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: 0
KEY_HEADWIND: 10Y收益率飙升50%至4.41%，名义利率压力压制风险资产估值
KEY_TAILWIND: 美元指数月跌7.5%+实际利率下行，双因子利好黄金/大宗商品
ONE_LINER: 利率冲击与避险回落对冲，黄金类有独立逻辑可持有，权益维持观望不追涨


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - 价格2年分位89%，历史高位，估值偏高  
  - RSI(14)=61.13，中性区域，无超买  
  - MA20与MA120纠缠（+1.46%），趋势不明确  
ONE_LINER: 价格处于range_bound区间高位，RSI中性，SIGNAL为neutral，支撑MA250（46.07），阻力近期高点。

### Risk Officer
SIGNAL: ok
STRENGTH: 3/10
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥11,010
PNL_PCT: +0.34%
WORST_CASE_LOSS_PCT_AT_-20: ~4.8%
ONE_LINER: 现金充裕（¥11,010），浮盈持平，无历史追涨记录；NDQ.AX持仓金额约¥25k，建议单次加仓不超过子弹的50%（≤¥5,500），保持组合分散。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-11 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-12-03
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.68)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-03",
  "vix": 16.08,
  "tnx": 4.057,
  "usdcny": 7.07,
  "audcny": 4.6472
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.68
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无可投资金，不执行任何买入"
    - "若后续有新资金入账，可考虑在 $54.20（MA120 附近）设置网格第一档"

RISK_PLAN:
  stop_loss_trigger: "若价格跌破 MA120 ($54.21) 且 RSI < 40 同时 VIX > 22 → 考虑减仓 20-30% 保护浮盈"
  what_if_wrong:
    worst_case_pnl_cny: "当前持仓市值约 ¥45,000，若回撤 20% 浮亏约 ¥-7,500，但目前浮盈 +15.58% 可吸收约 ¥7,000 回撤仍保本"
    recovery_estimate: "历史 uptrend 下中位回踩幅度约 -3.3%，中位 18 个交易日见底后回升，即使回调也能在 1-3 个月内修复"

PERSONAL_NOTE:
  - "NDQ.AX 浮盈 +15.58% 状态健康，占总资产约 38%，仓位合理但不轻；可投资金仅 ¥310 几乎为零，加仓在资金层面不现实"
  - "本次建议在子弹中占比 0%——核心原因并非看空，而是 Quant 信号中性 + 价格处于 2 年分位 97% 极端高位（估值偏贵），Risk Officer 指出流动性缓冲严重不足，此时任何加仓都违反审慎原则"
  - "操作纪律：当前最大风险不是 NDQ.AX 下跌，而是整个组合现金缓冲归零导致被动卖出——优先补充流动性再考虑加仓任何资产；价格偏离 MA120 仅 5.88% 尚在安全区间，但 97% 分位意味着上行空间有限、下行弹性大，耐心持仓优于追高"


---

## Macro Strategist (shared)

**宏观评估：**

VIX 大幅回落至 16，恐慌情绪消退，风险偏好改善。DXY 月跌 4.25% 美元走弱，叠加 TIP 暴涨 11.67% 实际利率急降，为黄金/商品提供"双击"环境。但 TNX 月涨 13.67% 至 4.06%，名义利率上行说明通胀预期在升温，隐含滞胀风险。整体美元走弱+实际利率下行主导，风险偏好尚可但需警惕利率反弹。

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: 2
KEY_HEADWIND: 名义利率月涨14%，通胀粘性风险未消，若反弹将压制估值
KEY_TAILWIND: 美元走弱+实际利率急降形成黄金双击，VIX回落至16恐慌消退
ONE_LINER: 宏观中性偏多，风险资产可维持，黄金/商品类受益于美元与实际利率双利好，可适度加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位97%，处于历史高位，估值偏高风险
  - RSI 54.46，中性区域未超买，动能有限
  - 价格离MA120偏差5.88%，均值回归风险低，但MA20-MA120价差需监控收窄
ONE_LINER: 尽管REGIME为uptrend，价格分位极高且RSI中性，支撑MA120@54.21，阻力未明，SIGNAL neutral以应对潜在回调。

### Risk Officer
```
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A（portfolio_summary未提供，未自算）
DRY_POWDER_CNY: ¥310
PNL_PCT: +15.58%
WORST_CASE_LOSS_PCT_AT_-20: ≈-6%（NDQ.AX市值约$7,765 AUD，跌20%损失≈¥7,500）
ONE_LINER: 浮盈健康但流动性严重不足（仅¥310），SolvencyBuffer未确认默认weak——NDQ.AX建议维持现状不加仓，子弹优先补现金缓冲。
```

**补充说明**：
- NDQ.AX当前浮盈+15.58%，无止损压力
- 可投子弹¥310已低于¥1,000阈值，且无SolvencyBuffer数据证明有外部流动性兜底，视为流动性风险
- Dreaming数据为空，无法判断是否存在追涨模式
- 510300.SS和GC=F均有正收益，整体组合健康，但**现金缓冲缺失是当前最大隐患**


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-03 > cutoff 2024-12-31)

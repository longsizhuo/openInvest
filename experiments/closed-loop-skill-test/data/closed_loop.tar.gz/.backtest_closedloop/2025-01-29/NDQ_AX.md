# Committee: NDQ.AX

**Date**: 2025-01-29
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.75)
**Dominant view**: quant
**Suggested allocation CNY**: 4000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-29",
  "vix": 16.56,
  "tnx": 4.555,
  "usdcny": 7.2502,
  "audcny": 4.5339
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.75
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 4000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 4000
  add_levels:
    - “若价格从现价下跌3%（约至$49.13），加仓 ¥5000”
    - “若价格从现价下跌5%（约至$48.12），再加仓 ¥8800”

RISK_PLAN:
  stop_loss_trigger: “价格跌破 MA120 支撑位（约 $46.0）且 VIX 升破 20 → 减仓 50%”
  what_if_wrong:
    worst_case_pnl_cny: -1000
    recovery_estimate: “3-6个月”

PERSONAL_NOTE:
  - 您当前 NDQ.AX 仓位极轻（约占总资产 5%），浮盈 +1.47%，整体风险敞口极小。
  - 本次建议加仓 ¥4,000，约占您可用子弹的 6.7%，属于试探性建仓。
  - uptrend 期 ACCUMULATE 检查清单：1. 价格偏离 MA120 10.19% (<15%)，均值回归风险尚可；2. VIX 从高位回落至 16.56，未显示新一轮恐慌上升；3. 若 30 天后跌 10%，因趋势未破且仓位已极轻，此策略仍可成立，但需严格分批以摊薄成本。历史高位估值（价格分位98%）要求我们必须保持耐心和纪律，采用金字塔加仓而非一次买满。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: DXY突破108强势上行+实际利率攀升（TIP月跌5%），黄金与大宗商品面临美元与实际利率"双杀"
KEY_TAILWIND: VIX回落至16.56低位，市场恐慌情绪消退，风险偏好短期回暖
ONE_LINER: 债市与汇市同步收紧（高利率+强美元），VIX低估了潜在风险，组合整体倾向"维持偏防御"，黄金仓位需警惕双压
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: bullish  
STRENGTH: 5  
KEY_DATA:  
  - 价格离MA120偏离度10.19%（<15%，均值回归风险低）  
  - RSI 54.42中性，未超买  
  - 价格分位98%历史高位，估值偏高需谨慎  
ONE_LINER: 上升趋势中价格处历史高位，但技术面未见衰竭信号，信号谨慎看涨，支撑在MA120 45.97。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（portfolio_summary 未明确给出）
DRY_POWDER_CNY: ¥59,300
PNL_PCT: +1.47%
WORST_CASE_LOSS_PCT_AT_-20: ~-2.9%（基于 57.38 份 × $50.65 × 20% ÷ 总资产 ¥100,269）
ONE_LINER: NDQ.AX 持仓体量小、浮盈为正、子弹充裕，风险可控；建议本次加仓上限不超过子弹的 30%（≈¥17,800），保持组合分散度。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-29 > cutoff 2024-12-31)

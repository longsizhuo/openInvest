# Committee: NDQ.AX

**Date**: 2025-01-15
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-15",
  "vix": 16.12,
  "tnx": 4.653,
  "usdcny": 7.3309,
  "audcny": 4.538
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.60
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 5000
  add_levels:
    - 价格跌至 $46.95 AUD（-5%）→ 加仓 ¥5,000
    - 价格跌至 $44.48 AUD（-10%，接近 MA120 支撑 $45.31）→ 加仓 ¥8,000

RISK_PLAN:
  stop_loss_trigger: 价格跌破 $43.50 AUD（MA120 下方约 4%）且 ^VIX > 25 → 清仓止损，最大损失约 ¥1,000
  what_if_wrong:
    worst_case_pnl_cny: -1000
    recovery_estimate: 3-6个月（需利率环境回落至4.3%以下或VIX持续低于15）

PERSONAL_NOTE:
  - 当前 NDQ.AX 仓位仅占总资产 8.2%，浮亏 -1.64%，仓位极轻，子弹充裕 ¥72,700（占总资产 72.9%）
  - 本次建仓 ¥5,000 仅占子弹 6.9%，属于最小试探仓，保留 93% 子弹应对后续网格加仓
  - **uptrend 怀疑清单已逐条检查**：①价格偏离 MA120 仅 9.06%（<15%），均值回归风险可控；②VIX 从高位回落至 16，并非从低位异常上升，暂无恐慌升温信号；③若 30 天后跌 10%，宏观面利率 4.65%+ 美元指数 109 的环境下纳斯达克反弹力度存疑，ACCUMULATE 理论将显著弱化——因此仅建小仓试探，不追涨。Quant 显示价格处于 2 年 95% 分位高位，叠加 Macro 强 risk_off（SCORE -3，利率冲击为近年罕见级别），绝不一次满仓。网格策略的核心逻辑是：趋势未破（MA20-MA120 偏离 11%）、风险可控（Risk ok）时先上车留子弹，若宏观恶化（VIX 重新飙升 / 利率继续走高）则止损退出，若温和回调则网格加仓拉低成本。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y国债收益率飙至4.65%且美元指数破109，实际利率上行，金融条件急剧收紧，对风险资产和黄金构成双杀。
KEY_TAILWIND: VIX从高位回落42%至16，恐慌情绪快速消退，市场短期风险偏好改善。
ONE_LINER: 利率飙升+美元强势主导宏观格局，VIX回落仅为情绪修复而非基本面转好，建议减仓或维持防御配置。
```

**核心逻辑**：
- 🔴 **利率冲击**：TNX 4.65% 配合 DXY 109，是2024年末典型的"美国例外论"叙事——经济强→利率高→美元强→资本回流美国
- 🔴 **黄金双杀**：实际利率上行（TIP -3.26%）+ 美元走强 = 黄金/商品的货币因子全面承压
- 🟢 **VIX悖论**：恐慌退潮但高位利率环境下的"平静"往往是脆弱的，需警惕二次波动
- **综合判断**：SCORE -3，信号指向 risk_off，利率风险压倒情绪改善


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 4  
KEY_DATA:
  - 价格2年分位95%，处于历史高位，估值偏高  
  - RSI(14) 47.33，中性区域，未超买  
  - 价格偏离MA120仅9.06%，均值回归风险可控，但MA20-MA120偏离11.09%显示趋势仍在  
ONE_LINER: 上升趋势中价格高位震荡，RSI中性，短期回落至支撑45.31（MA120），阻力50.34（MA20），信号中性因指标矛盾且高位风险。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: 8.2% (推算，portfolio_summary未显式给出集中度字段)
DRY_POWDER_CNY: ¥72,700
PNL_PCT: -1.64%
WORST_CASE_LOSS_PCT_AT_-20: -1.6%
ONE_LINER: NDQ.AX占比极低(≈8%)、浮亏仅-1.64%、子弹充裕¥72,700，风险敞口可控，建议单次建仓不超过子弹的30%（≈¥21,800）。
```

**补充说明**：
- portfolio_summary 未提供显式"集中度 X%"字段，8.2% 为按市值推算（≈$1,734 AUD / ¥99,716），如系统有精确值请以覆盖为准。
- 无 Dreaming 历史行为数据，无情绪化追涨证据。
- 现金占比 72.9%，加仓空间充裕，本次决策无流动性压力。
- 当前 NDQ.AX 仓位很小，继续建仓在比例上无问题，关键是控制单次节奏。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-15 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-23
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-23",
  "vix": 28.45,
  "tnx": 4.387,
  "usdcny": 7.3118,
  "audcny": 4.6614
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 暂不新增。若RSI跌至30以下且价格触及$39.5附近（MA250支撑），可考虑用≤¥2,100试加一笔
    - 若反弹至$45以上（接近MA250）且量价配合，可观望确认趋势是否反转再定

RISK_PLAN:
  stop_loss_trigger: 价格跌破$39.0（较现价再跌约9%）同时VIX突破28 → 考虑减仓50%止损
  what_if_wrong:
    worst_case_pnl_cny: 若继续下跌20%至$34.2，现有持仓浮亏扩大约¥1,500（AUD计），总资产浮亏约-5%
    recovery_estimate: 根据当前MA120=48.05，需涨12.3%回到均线，参考downtrend历史中位恢复周期约4-6个月

PERSONAL_NOTE:
  - 当前NDQ.AX持仓浮亏13.36%（104.8份，成本$49.39 vs 现价$42.79），已超过常规止损评估线，但未触及强制平仓规则
  - 本次建议为0加仓，维持现有仓位不动；NDQ占总资产约4.4%，集中度风险可控
  - 🔍 downtrend中HOLD而非加仓的理由：(1) 价格$42.79低于MA120(48.05)达11%，偏离度高，均线压制明确；(2) 10Y国债收益率暴涨至4.39%构成利率冲击，科技成长股估值承压的逻辑未变；(3) RSI 43.72非超卖区，尚无明确"超跌反弹"信号。如果30天后跌10%，当前持仓成本将进一步远离，此时加仓等于摊薄高位成本而非"抄底"——真正的底部信号应等RSI<30或VIX回落<18再评估
  - 心理建议：浮亏13%在科技ETF中属正常回撤幅度，不要因为"亏了就想补"而仓促加仓。纪律比情绪重要——等信号，不追价


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y国债收益率单月暴涨近60%至4.39%，利率冲击压制风险资产估值
KEY_TAILWIND: 美元指数跌破100且实际利率下行，黄金/商品获得货币端双击支撑
ONE_LINER: 利率冲击主导risk_off，VIX逼近恐慌区间，风险资产倾向减仓；但美元走弱+实际利率降对黄金形成结构性利好，可维持黄金仓位
```

**补充说明（超格式，供参考）：**

- **核心矛盾**：名义利率飙升（TNX 4.39%）vs 实际利率下行（TIP涨），说明市场定价的是"名义增长预期上修"而非"纯紧缩恐慌"——这通常是滞胀叙事的前兆。
- **DXY < 100** 且仍在走弱，叠加实际利率方向对黄金有利，货币端环境对贵金属类资产是**罕见的双击窗口**。
- **风险点**：若美联储因通胀粘性被迫鹰派回应，实际利率可能反转，届时黄金逻辑需重估。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 43.72 中性偏弱，未超卖
  - 价位分位65%，较高但未达70% bearish阈值
  - MA20低于MA120 8.22%，下降趋势确认，量减(RVOL 0.72x)
ONE_LINER: 在下降趋势中，价格42.79低于MA120(48.05)和MA250(45.23)，RSI中性且量减，SIGNAL neutral，需观察是否跌破近期低点。

### Risk Officer
SIGNAL: concerned
STRENGTH: 6
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: 21,010
PNL_PCT: -13.36%
WORST_CASE_LOSS_PCT_AT_-20: 该资产再跌20%，整体持仓浮亏将扩大
ONE_LINER: 当前持仓已浮亏13.36%，已超过止损评估线。建议在反弹至成本价前不新增仓位，或若决定加仓，单次投入不超过可投子弹的10%（约2,100元）。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-23 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-03-18
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-18",
  "vix": 25.09,
  "tnx": 4.259,
  "usdcny": 6.8863,
  "audcny": 4.8954
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前子弹为零，无法执行任何加仓指令。"
    - "建议将其他盈利资产（如GC=F）的部分利润变现，为NDQ.AX下一轮操作补充弹药。"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX价格跌破 $49.72（持仓均价）同时^VIX维持高位（>25） → 考虑止损离场"
  what_if_wrong:
    worst_case_pnl_cny: "若价格跌至历史路径悲观分位（约-10%），浮亏约 ¥3,000 (当前持仓价值约¥34,500)"
    recovery_estimate: "下行趋势中，若触发止损，解套需等待市场趋势反转，预计6-12个月"

PERSONAL_NOTE:
  - 您当前子弹为零，无法执行加仓操作，但NDQ.AX仓位（约26%）处中性区间，浮盈+3.82%，暂无立即减仓的紧迫性。
  - 本次建议占用子弹比例为0%。
  - **为何不建议操作（HOLD而非TRIM的理由）**：1) 市场情绪表盘显示INDEP_DEFENSE_FLAG: on（VIX高位），虽是风险信号，但您仓位已盈，非高杠杆，直接卖出可能错过反弹（尽管趋势向下）。2) 零子弹状态下，卖出后所得资金没有明确、更优的再投资渠道，且面临踏空风险。3) 核心矛盾是“无法加仓”，而非“持仓过重”，因此维持现状等待您补充资金或调整其他资产结构是更优选择。纪律上，建议您先处理“弹药”问题，再对NDQ.AX做出方向性决策。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 10Y国债收益率月涨20%+VIX月涨46%，金融条件急剧收紧，风险偏好受压
KEY_TAILWIND: 实际利率大幅回落（TIP月涨10.5%）+美元走弱，黄金获"双击"环境
ONE_LINER: 债率飙升叠加恐慌情绪膨胀，整体偏向防御；但实际利率下行+美元趋弱为黄金/贵金属类资产提供逆势支撑，权益类建议减仓，黄金可维持。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位68%，接近但未超70%高位阈值
  - RSI 46.50 处于中性区间，无趋势反转信号
  - MA20低于MA120 -6.27%，下行趋势结构完整
ONE_LINER: 下行趋势中，中性指标与高位分位叠加，SIGNAL为neutral；阻力位MA250 52.35和MA120 55.14，支撑参考30天低点反弹位。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5/10
CONCENTRATION_PCT: N/A（集中度 lens 已关闭）
DRY_POWDER_CNY: ¥0
PNL_PCT: +3.82%
WORST_CASE_LOSS_PCT_AT_-20: ≈5.2%（推算 NDQ.AX 现值约¥34,504，总资产¥133,069）
ONE_LINER: 零子弹无法执行任何加仓，NDQ.AX 存量浮盈+3.82%尚可；需等待资金补给或获利了结其他资产后再考虑操作，当前不建议加仓。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-18 > cutoff 2024-12-31)

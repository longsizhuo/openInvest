# Committee: NDQ.AX

**Date**: 2025-08-13
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-13",
  "vix": 14.49,
  "tnx": 4.238,
  "usdcny": 7.1785,
  "audcny": 4.6862
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若价格跌破MA120（约¥48.38）且VIX升破20，考虑减仓30%
  what_if_wrong:
    worst_case_pnl_cny: -648 （按当前持仓估算）
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 用户当前NDQ.AX持仓浮盈+8.64%，整体风险可控，但可投资金仅¥1,860，子弹极度有限。
  - 本次建议不加仓，子弹占比为0%。在资产估值处于历史极端高位（2年分位100%）、Quant中性、且子弹极少的情况下，加仓的风险收益比不佳。
  - 在历史高位保持耐心，避免在估值偏高时动用有限子弹追高。遵循纪律，等待更明确的回调信号或子弹补充后再行评估。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10年期美债收益率月涨22.5%至4.24%，名义利率快速攀升压制风险资产估值
KEY_TAILWIND: 美元指数月跌10.8%至97.84+实际利率下行（TIP+8.4%），黄金/大宗商品迎"双击"
ONE_LINER: VIX低至14.5显示市场极度平静，美元走弱+实际利率下行构成黄金强势窗口，风险资产可维持但需警惕收益率飙升的尾部风险
```

**补充说明**：
- 当前矛盾信号：低VIX（risk_on）vs 名义利率飙升（潜在风险）
- **货币因素对黄金极度友好**：DXY跌破98 + 实际利率下行 = 经典双击组合，短期黄金基本面强劲
- 需关注：名义利率与实际利率背离是否持续——若通胀预期被打破，双击可能逆转


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位100%，估值偏高，位于历史极端高位
  - RSI 63.65 中性偏强，未进入超买区
  - 价格偏离MA120约11.1%，趋势仍在但未过度拉伸
ONE_LINER: 上升趋势中，但价格已创历史新高且估值极高，MA120 (48.38) 为强支撑，需观察突破有效性，故暂判neutral。

### Risk Officer
SIGNAL: ok
STRENGTH: 1
DRY_POWDER_CNY: ¥1,860
PNL_PCT: +8.64%
WORST_CASE_LOSS_PCT_AT_-20: -5.82%
ONE_LINER: 整体风险可控，当前浮盈，子弹尚存，建议本次加仓不超过可投子弹的50%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-13 > cutoff 2024-12-31)

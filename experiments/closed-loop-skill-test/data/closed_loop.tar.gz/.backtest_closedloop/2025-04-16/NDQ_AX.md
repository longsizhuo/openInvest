# Committee: NDQ.AX

**Date**: 2025-04-16
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-16",
  "vix": 32.64,
  "tnx": 4.279,
  "usdcny": 7.3119,
  "audcny": 4.6335
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂无加仓计划，等待VIX回落至25以下且RSI进入超卖区(<30)再评估摊薄成本机会"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 $38.50（较现价再跌约10%）且 VIX 持续 > 30 → 减仓 30%（约30股）"
  what_if_wrong:
    worst_case_pnl_cny: "若跌至 $38，当前持仓额外浮亏约 ¥2,200（104.82股 × $4.71 × 4.7汇率），总浮亏扩大至约 ¥5,500"
    recovery_estimate: "利率冲击消化 + VIX回落至20以下后，估计6-12个月可收复失地"

PERSONAL_NOTE:
  - "NDQ.AX 已浮亏 -13.52%，持仓约占总资产 21%，规模适中无需恐慌减仓，但当前环境也不支持加仓摊平"
  - "本次不动用子弹，¥24,710 现金全部保留——利率冲击期（10Y美债单月飙升50bp）+ VIX 32.64高位，手持现金本身就是对冲"
  - "纪律建议：三方一致偏空但无人喊极端看空，最理性的做法是忍住不动；若下月 VIX 回落 + Quant 信号从 neutral 转 bullish，再用子弹 5-8%（约 ¥1,500-2,000）做试探仓，切忌在恐慌环境里一把摊平"
```


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10年期美债收益率单月飙升近50%，利率冲击剧烈压制风险资产估值；VIX高企32.64，恐慌情绪未退。
KEY_TAILWIND: 美元指数月跌3.65%+实际利率下行（TIP涨），双因子为黄金/商品提供支撑。
ONE_LINER: 利率冲击+高波动环境，整体偏向减仓防御；黄金类资产受弱美元+实际利率下行双击支撑，可择机配置。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI(14) 40.61 中性偏弱，未进入超卖区
  - 价格42.71已跌破MA250(45.20)，但当前成交量偏低(RVOL 0.68x)
  - 价格2年分位64%，结合下行趋势，估值偏高风险被短期下跌部分抵消
ONE_LINER: 下跌趋势中，价格已跌至中位但未放量，RSI未超卖，短期缺乏明确反转信号，建议等待45.20(MA250)阻力测试或超卖信号。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 5  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: ¥24,710  
PNL_PCT: -13.52%  
WORST_CASE_LOSS_PCT_AT_-20: 4.1%  
ONE_LINER: 浮亏显著，建议加仓比例上限不超过子弹的10%，并考虑止损评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-16 > cutoff 2024-12-31)

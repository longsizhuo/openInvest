# Committee: NDQ.AX

**Date**: 2025-02-05
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 3000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-05",
  "vix": 15.77,
  "tnx": 4.422,
  "usdcny": 7.1819,
  "audcny": 4.4892
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.6
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 3000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 1500
  add_levels:
    - "若价格从当前水平下跌3%（约$49.01 AUD）→ 加仓 ¥1,000"
    - "若价格下跌5%（约$48.00 AUD）→ 加仓 ¥500，将总仓位提升至约占子弹的7%"

RISK_PLAN:
  stop_loss_trigger: "若价格跌破 MA120 支撑位 $46.34 AUD（约 -8.3%）或 ^VIX 重新站上 22 → 减仓 50% 的现有持仓"
  what_if_wrong:
    worst_case_pnl_cny: -1360
    recovery_estimate: "3-6个月（基于历史 uptrend 中回踩后均值回归的统计中位时间）"

PERSONAL_NOTE:
  - 当前 NDQ.AX 仓位极轻（占总资产 16.9%），浮盈 +0.89%，风险敞口有限，具备试错空间。
  - 本次投入 ¥3,000 约占可用子弹的 6.8%，符合轻仓试探原则，避免在估值高位（价格 2 年分位 97%）一次性重仓。
  - 操作纪律：uptrend 中首要任务是保护本金，而非追逐收益。历史数据显示 77% 的 ACCUMULATE 错判发生在 uptrend。本次决策已通过三点检查：1) 价格离 MA120 偏离 9.05%，低于 15% 的高风险阈值；2) VIX 处于 15.77 的低位，并未从近期低位开始上升；3) 即使 30 天后跌 10%，当前极低仓位和分批计划能将风险控制在可接受范围，且仍可能以更低均价加仓。核心矛盾（利率上行 vs 情绪平静）意味着波动可能加剧，分批是唯一理性的入场方式。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 美元指数107.58高位运行+实际利率上行（TIP月跌4.68%），黄金/商品面临"双杀"压力
KEY_TAILWIND: VIX跌至15.77（月降48%），恐慌情绪已充分释放，短期风险偏好改善
ONE_LINER: 10Y收益率飙升至4.42%配合强美元收紧金融条件，但低VIX显示市场情绪尚稳，建议维持现有仓位、暂不加仓，尤其回避黄金多头敞口
```

**补充解读（不计入输出）：**

| 指标 | 状态 | 信号 |
|------|------|------|
| VIX 15.77 | 低位，低于恐慌阈值 | ✅ 偏多 |
| TNX 4.42% | 月涨近120%，利率重定价剧烈 | ❌ 偏空 |
| DXY 107.58 | 突破关键整数位，月涨8.5% | ❌ 强美元压制风险资产 |
| TIP -4.68% | 实际利率上行 | ❌ 黄金双杀第二刀 |

**核心矛盾**：表面看VIX平静=risk_on，但底层是"利率再定价+美元走强"的紧缩叙事在主导。市场可能正经历"平静的风暴眼"——当VIX重新抬升时，波动率可能快速放大。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位97%，估值偏高，均值回归风险大
  - RSI 52.17中性，无超买信号，但缺乏动能
  - 价格离MA120偏离9.05%低于阈值，短期回报为负，趋势或减弱
ONE_LINER: 上升趋势中但价格处历史高位且动能不足，支撑位MA120 46.34，结合REGIME高位风险转为中性信号。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: 16.9%
DRY_POWDER_CNY: ¥44,300
PNL_PCT: +0.89%
WORST_CASE_LOSS_PCT_AT_-20: -3.4%
ONE_LINER: NDQ.AX 仓位轻、现金充裕、小幅浮盈，风险可控，建议建仓比例上限 25%，本次可投子弹充足。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-05 > cutoff 2024-12-31)

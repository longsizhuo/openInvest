# Committee: NDQ.AX

**Date**: 2025-12-17
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-17",
  "vix": 17.62,
  "tnx": 4.151,
  "usdcny": 7.0417,
  "audcny": 4.6702
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 当前可投子弹仅¥310，不构成有意义的加仓单位；建议先回补至少¥5,000应急现金后再议
    - 若未来子弹回补至¥10,000+且NDQ回落至$53.50（MA120下方3%），可考虑以¥3,000网格建仓

RISK_PLAN:
  stop_loss_trigger: NDQ.AX收盘价跌破$54.74（120日均线）且^VIX突破22 → 减仓当前持仓的30%（约40股）
  what_if_wrong:
    worst_case_pnl_cny: ≈-7,100（NDQ跌20%时浮盈从+¥3,900归零并转亏约¥3,200，占总资产5.6%）
    recovery_estimate: 3-6个月（NDQ长期成长属性+当前range_bound regime回归中位概率较高）

PERSONAL_NOTE:
  - 当前NDQ持仓浮盈+12.46%，持仓体验舒适，但¥0应急金+¥310可投子弹构成结构性流动性缺口——这是比NDQ本身更紧迫的问题；Risk Officer的建议（优先回补¥5,000应急现金）应作为操作第一优先级。
  - 本轮建议新增投入¥0，占子弹¥310的0%；所有可投资金微不足道，强行ACCUMULATE既无实质仓位增厚效果，又将应急金彻底清零，风险收益比极差。
  - 价格处于2年分位91%的高位区间+macro层面名义利率飙升17.8%压制成长股估值+Quant确认range_bound无突破动能——三重因素叠加下，"坐在仓位上等"比"拿着¥310冲进去"理性得多；浮盈仓位本身就是对NDQ的投票，不必急于加码。纪律提醒：守住利润的前提是守住流动性——下月工资到账后先填满应急金，再考虑NDQ的下一笔。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y收益率飙升+17.76%，名义利率快速上行压制成长股估值
KEY_TAILWIND: 美元走弱+实际利率大幅下行，黄金/商品迎来"双击"窗口
ONE_LINER: 宏观信号分歧——低VIX+弱美元偏risk_on，但名义利率飙升偏risk_off；组合若含黄金类资产可维持/加仓，纯权益维持观望。
```

**要点拆解：**

| 因素 | 信号 | 判定 |
|------|------|------|
| VIX 17.62 ↓11% | 恐慌消退，低于20警戒线 | ✅ risk_on |
| DXY 98.37 ↓3.2% | 美元弱势 | ✅ 利好商品/黄金 |
| TIP +10.51% | 实际利率显著下行 | ✅ 黄金顺风 |
| TNX 4.15% ↑17.8% | 名义利率急升 | ⚠️ 压制权益估值 |

**核心矛盾**：名义利率↑ + 实际利率↓ = 通胀预期在攀升，叠加弱美元，是典型的**"通胀交易"环境**——利好黄金/大宗，但对高久期权益资产构成压力。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位高达91%，处于历史高位区间
  - RSI(14) 43.52 中性偏弱，无超买超卖信号
  - 价格在MA20 (56.61) 与MA120 (54.74) 间震荡，MA20-MA120价差3.42% < 趋势阈值4%，确认无趋势
ONE_LINER: 价格在MA120支撑与MA20阻力间高位震荡，range_bound regime下无明确突破动能，维持neutral观察。

### Risk Officer
```
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A（portfolio_summary 未给出集中度字段）
DRY_POWDER_CNY: ¥310
PNL_PCT: +12.46%
WORST_CASE_LOSS_PCT_AT_-20: ≈-5.7%（NDQ 跌 20% → 约亏 ¥7,253，占总资产 5.7%）
ONE_LINER: 核心风险是流动性枯竭——仅 ¥310 可投且应急金为 0，NDQ 持仓浮盈 12.46% 但无子弹补仓；建议暂停加仓，优先回补至少 ¥5,000 应急现金后再考虑 NDQ 仓位。
```

**关键风险点**：
- 现金/应急金几乎为零，属结构性流动性缺口
- 当前无 Dreaming 异常模式，非情绪化追涨
- NDQ 浮盈尚可，但 -20% 回撤将吞噬约 5.7% 总资产


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-17 > cutoff 2024-12-31)

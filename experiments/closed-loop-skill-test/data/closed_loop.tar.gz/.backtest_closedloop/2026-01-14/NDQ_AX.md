# Committee: NDQ.AX

**Date**: 2026-01-14
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 310

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-14",
  "vix": 16.75,
  "tnx": 4.14,
  "usdcny": 6.9775,
  "audcny": 4.6631
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE  
CONFIDENCE: 0.7  
DOMINANT_VIEW: macro  
SUGGESTED_ALLOC_CNY: 310  
TRIM_REASON: N/A  
REENTRY_PRICE: N/A  
REENTRY_CONDITION: N/A  
EXPECTED_PATH: N/A  

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 155
  add_levels:
    - "如果价格跌3%（约$54.86）→ 加仓¥100"
    - "如果价格跌6%（约$53.17）→ 加仓¥55"

RISK_PLAN:
  stop_loss_trigger: "跌破 $51.73（MA250支撑）同时 ^VIX > 22 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -5000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户NDQ.AX持仓浮盈13.89%，现金仓位极低（¥310），整体持仓结构尚可。
  - 本次建议使用全部可投资子弹¥310，占总资产比例<1%，试探性建仓以捕捉潜在上涨。
  - 价格处于2年高位93%分位，RSI中性，分批加仓避免追高，严守止损纪律；Macro risk_on但美债收益率飙升为逆风，需保持谨慎。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 5
SCORE: +2
KEY_HEADWIND: 美债收益率MoM飙升+7.73%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数跌至99.13（MoM-4.85%）叠加实际利率大幅下行，黄金/商品获得"双击"环境
ONE_LINER: 宏观偏温和友好——VIX低位+美元走弱，可维持现有仓位，黄金类资产可小幅加仓


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位93%极高，技术面高位风险
  - RSI 54.14中性，无超买超卖信号
  - MA20与MA120差值仅1.19%，趋势纠缠不明
ONE_LINER: range-bound regime下价格于高位盘整，RSI中性且均线纠缠，信号中性，支撑参考MA250 51.73。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 4  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: ¥310  
PNL_PCT: +13.89%  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 低现金流动性风险，建议NDQ.AX加仓上限为可投子弹¥310的100%，避免动用应急金。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-14 > cutoff 2024-12-31)

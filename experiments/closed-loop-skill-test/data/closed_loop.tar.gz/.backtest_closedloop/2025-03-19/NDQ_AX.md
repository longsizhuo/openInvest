# Committee: NDQ.AX

**Date**: 2025-03-19
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 1650

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-19",
  "vix": 19.9,
  "tnx": 4.256,
  "usdcny": 7.2273,
  "audcny": 4.5969
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 1650
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 1650
  add_levels:
    - "if price holds MA250支撑 $44.87 AUD 3个交易日以上且 RSI回升至35以上 → 加仓 ¥2,500"
    - "if price drops 7%至 ~$42.0 AUD 且 RSI < 18 → 加仓 ¥3,000（RSI极端超卖反弹博弈）"

RISK_PLAN:
  stop_loss_trigger: "收盘价跌破 $43.0 AUD（MA250下方约4%）同时 ^VIX > 24 → 减仓现有NDQ头寸50%"
  what_if_wrong:
    worst_case_pnl_cny: -4800
    recovery_estimate: "4-8个月（利率预期拐点后科技股通常快速修复）"

PERSONAL_NOTE:
  - 当前NDQ.AX持仓浮亏-9.09%，均价$49.73远高于现价$45.21，属于被套状态但尚未触发任何止损线；整体组合偏分散（NDQ约占总资产20%），持仓结构本身可接受
  - 本次加仓¥1,650仅占可用子弹的5%，是极保守试探仓，目的是利用RSI 21.17极端超卖 + 价格距MA250支撑仅0.75%的结构优势降低均价，而非押注反转
  - 10Y国债收益率单月暴涨46%是NDQ最大的系统性风险——成长股对利率最敏感，这不是普通回调而是宏观重定价；**纪律要求：若MA250失守必须执行止损，不要因为"已经亏了9%就再扛扛"而扩大亏损；本轮加仓金额极小，即使全部归零也仅损失1.6%的子弹，心理上做好这笔钱"买彩票"的预期**
  - uptrend怀疑清单不适用（regime=range_bound），但需注意：2年价格分位81%仍处高位，这意味着即便短期超卖反弹，中期上方空间受限于估值天花板；Quant给出的阻力位$47.96即为反弹极限参考，不应对短期收益抱过高期望


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y国债收益率单月暴涨46%，金融条件快速收紧，成长股估值承压
KEY_TAILWIND: VIX降至20以下且月跌12%，恐慌情绪消退，市场风险偏好小幅回暖
ONE_LINER: 利率飙升与恐慌回落对冲，宏观信号矛盾，建议维持现有仓位、暂不加仓
```

**补充判断逻辑**：
- TNX +45.9% 是本轮最刺眼信号——债券市场在重新定价"higher for longer"甚至加息预期回升，这是压制风险资产的核心变量
- VIX -12% 但仍在19.9附近（接近20警戒线），并非极度乐观，说明市场只是从"恐慌"回到"谨慎"
- DXY +2.18% 上行 + TIP仅微涨 → 黄金/商品端的货币因素中性偏弱（美元走强对冲了实际利率微降）
- **整体判断**：收益率脉冲是主矛盾，情绪面缓和不足以抵消，宏观偏紧但未到极端risk_off，评分略负


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位81%高位，但RSI 21.17严重超卖
  - MA20与MA120纠缠（-0.40%），趋势不明
  - 价格略高于MA250支撑（44.87），偏离仅0.75%
ONE_LINER: 高位区间震荡，超卖信号与分位压制冲突，信号中性，支撑44.87、阻力47.96。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 6  
CONCENTRATION_PCT: N/A（portfolio_summary未提供）  
DRY_POWDER_CNY: ¥32,960  
PNL_PCT: -9.09%  
WORST_CASE_LOSS_PCT_AT_-20: 4.0%（基于总资产估算）  
ONE_LINER: NDQ.AX浮亏超5%，建议设置止损线；当前集中度较低，但加仓比例上限勿超可用子弹的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-19 > cutoff 2024-12-31)

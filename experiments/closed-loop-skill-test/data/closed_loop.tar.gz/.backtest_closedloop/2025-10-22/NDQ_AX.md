# Committee: NDQ.AX

**Date**: 2025-10-22
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.58)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-22",
  "vix": 18.6,
  "tnx": 3.953,
  "usdcny": 7.1218,
  "audcny": 4.6231
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.58
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无可执行加仓档位（可用子弹仅 ¥310，低于单笔最低有意义下单量）

RISK_PLAN:
  stop_loss_trigger: 若 NDQ.AX 日收盘价跌破 $50.00（-12.3%，接近成本线）且 10Y 美债收益率同时突破 4.8%，减仓 50% 保利润
  what_if_wrong:
    worst_case_pnl_cny: 若价格回落至成本 $49.66，浮盈归零，约损失 ¥6,900 已实现收益机会
    recovery_estimate: 根据当前 uptrend 历史路径，即使回踩 10%，中位 18-25 个交易日可收复失地

PERSONAL_NOTE:
  - 当前 NDQ.AX 持仓 135 份，浮盈 +14.80%，占总资产约 39%（¥46,367 / ¥124,799），仓位已属中高配；可用现金仅 ¥310，子弹几乎归零，任何加仓操作在金额上都无意义。
  - Quant 明确标注"趋势末期特征"：价格处于 2 年分位 100% 极端高位，偏离 MA120 达 14.39%（接近 15% 均值回归警戒线），RSI 68.13 逼近超买——即便 regime 仍为 uptrend，追高的边际收益已极不对称。
  - 宏观虽 risk_on（美元崩跌 -7.29% + 实际利率回落），但 10Y 国债收益率月涨 +6.66% 对成长股估值形成真实压制，且 Risk Officer 给出 concerned 信号——Quant 中性 + Risk 关切 + 子弹枯竭，三者叠加指向"守住利润、不追高"。
  - uptrend 中 ACCUMULATE 三问自检：① 价格偏离 MA120 达 14.39%，接近 15% 阈值，均值回归风险高；② 10Y 收益率月涨 6.66% 暗示利率环境趋紧，不是单纯"回调即买"的场景；③ 若 30 天后跌 10%，当前 100% 分位的买入逻辑不成立——三项均指向 HOLD 而非 ACCUMULATE。
  - 操作纪律：浮盈 +14.80% 是好成绩，不要因为"怕错过"而在极端高位用最后 ¥310 押注。优先保留现金缓冲应对突发波动，待 Quant 信号从 neutral 转回 bullish 且价格出现 5%+ 回踩后再评估是否调入新资金。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: 2
KEY_HEADWIND: 10Y国债收益率月涨+6.66%，名义利率上行对估值有压力。
KEY_TAILWIND: DXY月跌-7.29%叠加TIP月涨+13.25%，美元走弱+实际利率下行构成黄金双击。
ONE_LINER: 美元崩跌+实际利率回落主导宏观叙事，风险偏好尚可(VIX<20)，维持偏多仓位，黄金/商品可加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 7
KEY_DATA:
  - 价格处于2年分位100%极端高位，估值明显偏高
  - RSI为68.13，接近超买区但未突破70
  - 价格偏离MA120达14.39%，均值回归风险上升
ONE_LINER: REGIME为上升趋势，但价格已至历史极值（100%分位），RSI偏高且均线偏离大，趋势末期特征明显，SIGNAL为中性，等待回调或更清晰信号。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A（portfolio_summary 未标注，拒绝估算）
DRY_POWDER_CNY: ¥310
PNL_PCT: +14.80%
WORST_CASE_LOSS_PCT_AT_-20: ≈-6.0%（NDQ.AX 市值约 ¥37,024 × 20% ÷ 总资产 ¥124,799）
ONE_LINER: 可投子弹仅 ¥310，流动性极紧；NDQ.AX 浮盈 +14.80% 健康，建议建仓比例上限 25%，当前暂无加仓空间，优先保留现金缓冲。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-22 > cutoff 2024-12-31)

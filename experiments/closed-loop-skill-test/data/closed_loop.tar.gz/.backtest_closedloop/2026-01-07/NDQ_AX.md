# Committee: NDQ.AX

**Date**: 2026-01-07
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-07",
  "vix": 15.38,
  "tnx": 4.138,
  "usdcny": 6.9834,
  "audcny": 4.7038
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无可用子弹，无法执行加仓

RISK_PLAN:
  stop_loss_trigger: 若NDQ.AX价格跌破MA120支撑位$55.20并收盘确认，同时VIX > 22，可考虑减持部分（如30%）锁定利润
  what_if_wrong:
    worst_case_pnl_cny: 以当前持仓约¥36,000计算，若下跌20%最大浮亏约¥7,200
    recovery_estimate: 在range_bound regime下，若发生深度回调，基于历史震荡特性，预计3-6个月内有望回升至当前价位

PERSONAL_NOTE:
  - 您目前NDQ.AX持仓浮盈+12.42%，状态健康，但可用于加仓的子弹（¥310）已近乎枯竭。
  - 本次建议HOLD，不涉及新增资金操作，所用子弹占比为0%。
  - 当前价格处于2年高位89%分位，且MA20与MA120纠缠不清，Quant信号为中性，表明缺乏明确方向。在估值已高、子弹不足且无强烈突破信号的情况下，维持现仓位是更审慎的选择，避免在高位用仅有的零钱追涨，应等待趋势明朗或价格回调后有新资金再做布局。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 美债名义收益率强势上行（TNX月涨+12%），或压制成长股估值
KEY_TAILWIND: 美元指数大幅走弱（DXY月跌-4.5%）叠加实际利率显著下行（TIP月涨+11%），双重利好黄金与风险资产
ONE_LINER: VIX低位+美元崩塌+实际利率回落构成温和risk-on环境，名义利率上行是唯一隐忧，建议维持偏多配置。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格2年分位89%，历史高位估值偏高
  - RSI 44.71中性偏弱，未超买
  - MA20与MA120仅差1.74%，趋势纠缠无方向
ONE_LINER: REGIME=range_bound下价格在MA120支撑55.20与MA20阻力56.16间震荡，SIGNAL=neutral因高位分位与中性RSI缺乏趋势动力。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（portfolio_summary未给出）
DRY_POWDER_CNY: ¥310
PNL_PCT: +12.42%
WORST_CASE_LOSS_PCT_AT_-20: ≈5.5%（NDQ.AX价值约¥36K，跌20%即损¥7.2K/总资产¥131K）
ONE_LINER: NDQ.AX浮盈+12.42%状态健康，子弹仅¥310几无可加仓空间；建议维持现仓位不动，下次有资金时NDQ.AX建仓比例上限不超过总资产15%，当前无减仓压力。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-07 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-07-16
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-16",
  "vix": 17.16,
  "tnx": 4.455,
  "usdcny": 7.1729,
  "audcny": 4.6763
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 价格跌破 $49.00（接近MA120）且RSI<40 → 考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: ≈ ¥5,960（基于总资产 -5.5% 浮亏估算）
    recovery_estimate: 2-4 个月（在 up 趋势下历史恢复期）

PERSONAL_NOTE:
  - 用户当前持有NDQ.AX浮盈4.42%，仓位适中，无情绪化追涨，风险可控。
  - 本次建议HOLD，子弹¥6,460全额保留，不占用新资金。
  - 心理建议：价格处于2年绝对高位（100%分位），RSI偏高且偏离MA120约7.2%，虽未超15%但均值回归风险增加，宜保持耐心等待回调至均线支撑（$48.08附近）再评估加仓。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y收益率飙升至4.45%（月涨+54%），金融条件收紧压制风险资产估值。
KEY_TAILWIND: 美元指数月跌9%至98.39，叠加实际利率下行（TIP+3.8%），为黄金/商品提供强力双击。
ONE_LINER: 利率上行与美元崩跌矛盾共存，黄金友好但权益承压——组合若含黄金可维持，纯权益仓位建议观望。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格处于2年历史最高分位（100%），估值与位置风险极高。
  - RSI(14) 65.66，处于偏高但未超买的临界区域。
  - 趋势向上（MA20>MA120），但价格已大幅偏离MA120（约+7.2%），存在均值回归风险。
ONE_LINER: 尽管处于上升趋势，但价格已触及2年绝对高位，RSI偏高且偏离长期均线，短期上涨动能可能减弱，给出中性信号，需关注MA20支撑及48.08的MA120阻力。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥6,460
PNL_PCT: +4.42%
WORST_CASE_LOSS_PCT_AT_-20: 约 -5.5%
ONE_LINER: 当前NDQ.AX持仓浮盈健康，无情绪化追涨迹象，建议本次加仓金额不超过可用子弹的50%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-16 > cutoff 2024-12-31)

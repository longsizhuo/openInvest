# Committee: NDQ.AX

**Date**: 2025-04-30
**Symbol**: NDQ.AX
**Verdict**: TRIM (confidence 0.68)
**Dominant view**: macro
**Suggested allocation CNY**: -5250

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-30",
  "vix": 24.7,
  "tnx": 4.177,
  "usdcny": 7.269,
  "audcny": 4.6412
}
```

---

## CIO Memo (Round 3)

VERDICT: TRIM
CONFIDENCE: 0.68
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: -5250
TRIM_REASON: bearish
REENTRY_PRICE: 42.00
REENTRY_CONDITION: 价格跌至 $42.00 以下且 RSI < 38，或 TNX 回落至 3.8% 以下且 DXY 持续走弱至 97 以下
EXPECTED_PATH: 当前 Quant 确认 downtrend regime，MA20 支撑 $43.50 为第一防线，若宏观收紧继续（TNX 3 月 +43%），跌破 MA20 后大概率下探 $41-42 区间（MA120 附近）。RSI 中性 51 无超卖信号，意味着短期反弹动能不足，继续测试下方支撑概率较高。

EXECUTION_PLAN:
  mode: lump-sum
  first_tranche_cny: -5250
  add_levels:
    - "若后续价格反弹至 $45.00（MA250 阻力位附近）且 RSI > 60 → 可考虑再减 ¥3,000 锁定反弹"
    - "若价格跌至 $42.00 且出现放量企稳 → 用释放资金重新建仓 ¥3,000"

RISK_PLAN:
  stop_loss_trigger: NDQ.AX 跌破 $41.00 同时 VIX > 28 → 剩余仓位再减 50%（约 40 股）
  what_if_wrong:
    worst_case_pnl_cny: -2500
    recovery_estimate: 6-12 个月

PERSONAL_NOTE:
  - NDQ.AX 当前浮亏 -9.57%，已超 5% 警戒线，Quant 确认 downtrend 且价格处于历史 77% 分位（偏贵），Macro risk-off（TNX 三月暴涨 43%、金融条件急剧收紧），三面共振指向减仓而非死扛
  - 本次减仓 ¥5,250 约占子弹 31%，释放后剩余可投资金 ≈ ¥22,260，为后续低位布局保留充足弹药
  - downtrend 中"等反弹再卖"是经典陷阱——Risk Officer 已明确不宜在浮亏位加仓摊薄，纪律性止损比等待解套更重要；减仓后若价格继续走低，你既有筹码又有更低买回价，心态远好于满仓硬扛


---

## Macro Strategist (shared)

综合近期走势分析：TNX近期从4.405高点回落至4.177，但3个月累计涨幅仍达+43%，收紧效应显著；DXY跌至99.47并持续走弱，触及98.28低点。

```
SIGNAL: risk_off
STRENGTH: 5
SCORE: -2
KEY_HEADWIND: 10Y收益率3个月暴涨43%，金融条件急剧收紧，风险资产估值承压
KEY_TAILWIND: DXY跌破100+实际利率下行，黄金/商品迎货币双击窗口
ONE_LINER: 名义利率飙升主导risk-off基调，风险资产倾向减仓；美元走弱+实际利率降为黄金商品提供对冲机会，可维持
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位77%，处于历史高位区间
  - RSI 51.07，中性无超买超卖信号
  - MA20低于MA120达9.25%，下降趋势确认且价格低于MA250
ONE_LINER: 下降趋势中价格高位但RSI中性，短期反弹动能不足，支撑位43.50（MA20），阻力位45.30（MA250），SIGNAL neutral。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: 17010
PNL_PCT: -9.57%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: NDQ.AX浮亏-9.57%已超5%警戒线，若继续下行建议止损10-15%仓位；当前子弹¥17,010充裕，但不宜在此浮亏位置加仓摊薄，等待企稳信号。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-30 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-08-06
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 1500

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-06",
  "vix": 16.77,
  "tnx": 4.22,
  "usdcny": 7.1834,
  "audcny": 4.651
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 1500
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 800
  add_levels:
    - "价格跌至 $51.00（约-2.7%）→ 加 ¥400"
    - "价格跌至 $49.50（约-5.5%，接近MA120）→ 加 ¥300"

RISK_PLAN:
  stop_loss_trigger: "收盘价跌破 MA120（$48.30）同时 ^VIX > 22 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -6500
    recovery_estimate: "4-6 个月"

PERSONAL_NOTE:
  - 当前 NDQ.AX 持仓 123 份、浮盈 +6.19%，属轻仓试探阶段，仓位结构健康
  - 本次加仓 ¥1,500 占子弹（¥5,460）的 27%，Risk Officer 上限约 ¥1,638，节奏合理
  - **uptrend ACCUMULATE 三项检查**：①价格偏离 MA120 仅 8.48%（<15%），均值回归压力尚可；②VIX 16.8 处于正常区间，未出现从低位急升至 >18 的焦虑信号；③若 30 天后跌 10%，美元走弱 + 实际利率下行的中期逻辑仍成立，但 2 年价格分位已达 99% 意味着回撤幅度可能超预期，因此仅建试探仓而非重仓
  - 10 年期美债收益率月涨 28% 至 4.22% 是成长股估值的实质利空，与 Quant 的 99% 高分位叠加，构成"贵 + 贴现率上行"双重压制——这是本次仅给 ¥800 首笔而非一次建满的核心原因
  - 纪律提醒：子弹仅剩 ¥5,460，本轮用掉 ¥1,500 后余额 ¥3,960，务必保留应对其他资产回调机会，不要把最后的弹药全押在历史高位上


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: 2
KEY_HEADWIND: 10Y收益率飙至4.22%（月涨28%），金融条件收紧压制成长股估值。
KEY_TAILWIND: DXY跌破99（月跌9.4%）+ TIP涨7.25%→实际利率下行，美元走弱+实际利率降=黄金双击环境。
ONE_LINER: 恐慌消退（VIX 16.8）、美元崩跌，风险偏好回升；但长端利率跳升是隐忧，整体偏暖，可小幅加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 5
KEY_DATA:
  - 2年价格分位99%，历史高位，估值偏高风险
  - RSI(14) 54.46中性，无超买信号
  - 价格高于MA120 8.48%，趋势维持但偏离度适中
ONE_LINER: 上升趋势中价格处历史高位但RSI中性，支撑MA120 48.30，维持看涨但强度受高分位限制。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
DRY_POWDER_CNY: ¥5,460
PNL_PCT: +6.19%
WORST_CASE_LOSS_PCT_AT_-20: ≈5.4%
ONE_LINER: NDQ浮盈+6.19%、子弹¥5,460充裕，无追涨历史，风险可控；建议单次加仓≤子弹30%（约¥1,638），保留弹药应对回调。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-06 > cutoff 2024-12-31)

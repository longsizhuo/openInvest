# Committee: NDQ.AX

**Date**: 2025-10-08
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-08",
  "vix": 16.3,
  "tnx": 4.129,
  "usdcny": 7.119,
  "audcny": 4.6843
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 不加仓，因可投资金仅¥310，流动性极度紧张

RISK_PLAN:
  stop_loss_trigger: 若NDQ.AX价格跌破$50（当前$55.86，跌约10.5%）且^VIX突破20，则考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: 若价格跌20%，持仓浮亏约¥-10,000（以AUD计约A$-1,511，基于当前持仓价值A$7,555）
    recovery_estimate: 3-6个月，基于宏观风险资产支撑但技术面回调风险

PERSONAL_NOTE:
  - 用户NDQ.AX持仓浮盈+12.48%，但可投资金仅¥310，现金流动性极度紧张，无法有效加仓
  - 本次建议不加仓（0%子弹占比），优先保留资金应对潜在回调或补充流动性
  - 操作纪律：避免在价格历史高位追高，耐心持有现有仓位，关注成交量变化及VIX动态；若出现深跌回调（如跌破$50），可考虑用未来新资金分批建仓，而非当前微额投入


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 8
SCORE: +4
KEY_HEADWIND: DXY虽大跌但已至低位，短期技术性反弹可能压制商品/黄金。
KEY_TAILWIND: 美元暴跌(-7%)叠加实际利率急降(TIP+14.6%)，黄金面临罕见"双击"窗口。
ONE_LINER: VIX崩盘+美元/实际利率双降，宏观环境极佳，风险资产维持/加仓，黄金强力看多。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位100%，历史最高点
  - RSI(14) 67.61，接近超买区但未突破
  - MA20>MA120 +7.21%，上升趋势但价差未明显收窄
  - 相对成交量0.82x，低于均量，动力减弱
ONE_LINER: 虽处上升趋势，但价格与RSI均处高位且成交量不足，短期回调风险上升，信号中性。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: 310
PNL_PCT: +12.48%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 可投资金仅310元，流动性极度紧张，建议NDQ.AX当前仓位维持，后续建仓需等待新资金。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-08 > cutoff 2024-12-31)

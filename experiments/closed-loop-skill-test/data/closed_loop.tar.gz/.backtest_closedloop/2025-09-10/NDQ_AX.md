# Committee: NDQ.AX

**Date**: 2025-09-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-10",
  "vix": 15.35,
  "tnx": 4.032,
  "usdcny": 7.1209,
  "audcny": 4.6881
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.70
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无可投子弹，暂缓执行"
    - "待新资金入账后重新评估：若价格回调至MA120附近（$49.33）且RSI<45，可建5%试探仓"

RISK_PLAN:
  stop_loss_trigger: "价格跌破MA120 $49.33 同时月度回报转负至 -5% 以下 → 考虑减仓50%锁定利润"
  what_if_wrong:
    worst_case_pnl_cny: -7200
    recovery_estimate: "3-6个月（基于当前uptrend regime历史中位数恢复周期）"

PERSONAL_NOTE:
  - 当前NDQ.AX持仓135.28份，浮盈+7.19%，持仓状态健康无止损压力；510300.SS和GC=F分别浮盈+17.28%和+24.29%，整体组合表现良好
  - 可投子弹仅¥360，占总资产0.3%，子弹已近乎耗尽——本轮无实质加仓能力，HOLD是流动性约束下的唯一合理选择
  - Quant警示价格处于2年分位97%（极度昂贵区间）且短期动能减弱（1月回报-1.00%），虽然宏观risk_on环境偏暖，但当前不宜追高；纪律上应耐心等待新资金注入或价格回调至MA120（$49.33，较现价-7.3%）再考虑建仓，而非在历史高位区间用最后一点弹药冒险


---

## Macro Strategist (shared)

**宏观评估**

SIGNAL: risk_on
STRENGTH: 8
SCORE: +3
KEY_HEADWIND: 10Y收益率温和上行+3.3%，对高久期资产估值构成边际压力
KEY_TAILWIND: VIX暴跌54%恐慌消散，美元指数大跌14%+实际利率大幅下行，黄金双击格局成型
ONE_LINER: 宏观环境显著改善——风险偏好回升、美元走弱、实际利率下行，整体偏向加仓，黄金/商品类尤佳


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - RSI 53.30 中性，未进入超买区
  - 价格2年分位97%，处于历史高位
  - MA20高于MA120 7.93%，但1月回报-1.00%，短期动能减弱
ONE_LINER: 上升趋势中价格处高位且RSI中性，趋势末期风险增加，信号为中性，支撑MA120 49.33。

### Risk Officer
```
SIGNAL: concerned
STRENGTH: 5
DRY_POWDER_CNY: ¥360
PNL_PCT: +7.19%
WORST_CASE_LOSS_PCT_AT_-20: -8.7%
ONE_LINER: 可投子弹仅¥360，加仓空间极度有限；当前持仓浮盈+7.19%健康，建议维持现有仓位不加仓，待有新资金入账或回调后再评估。
```

**判定依据**：
- **现金流**：可投资金¥360，远低于¥1000阈值；SOLVENCY_BUFFER_LEVEL未报告为strong，按规则低现金触发concerned
- **浮盈**：NDQ.AX成本均价$49.66 vs 现价$53.23，浮盈+7.19%，无止损压力
- **压力测试**：若NDQ.AX跌20%，约亏$1,441 AUD（≈¥7,200 CNY），占总资产约-6.1%；极端-35%场景约亏¥12,600（≈-10.8%），在balanced风险偏好下可承受
- **历史模式**：暂无Dreaming记录，无法判断是否追涨模式
- **建议**：子弹告罄，任何加仓需动用应急金，违反规则。建议冻结买入决策。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-10 > cutoff 2024-12-31)

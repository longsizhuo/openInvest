# Committee: NDQ.AX

**Date**: 2025-12-24
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-24",
  "vix": 13.47,
  "tnx": 4.136,
  "usdcny": 7.028,
  "audcny": 4.7097
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 当前子弹仅¥310，无实质加仓空间，待后续现金流入再议

RISK_PLAN:
  stop_loss_trigger: 跌破MA120支撑位$54.95（当前$56.18，仅2.2%下方），同时VIX从当前13.47回升至18以上 → 考虑减仓30%锁定部分利润
  what_if_wrong:
    worst_case_pnl_cny: 若跌至$48（约-15%），浮亏约¥-8,400，但当前浮盈¥882可部分缓冲
    recovery_estimate: 3-6个月，NDQ跟踪纳斯达克100，长期科技股逻辑未变

PERSONAL_NOTE:
  - 当前NDQ.AX持仓135份，均价$49.66，现价$56.18浮盈+13.13%，仓位状态健康
  - 可用子弹仅¥310（占总资产0.24%），实质上已无加仓弹药，HOLD是唯一合理选择
  - Quant指出价格2年分位92%（历史高位）+ MA20/MA120仅2.93%间距缠绕，趋势不明朗；Macro提示美债收益率月涨16.47%形成估值压力，VIX 13.47虽低但暗藏回撤风险——三重不确定性叠加，不宜在高位追涨，守住现有浮盈等待趋势明确
```


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10年期美债收益率月涨16.47%，利率上行压力抬升风险资产估值风险。
KEY_TAILWIND: 美元月跌3.2% + TIP月涨10.56%，实际利率下行与美元走弱形成黄金双击。
ONE_LINER: VIX低位（13.47）显示市场平静但暗藏回撤风险，美元+实际利率双利多黄金，整体维持现有仓位，黄金类可小幅加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位92%，历史高位
  - RSI 47.69，中性区域
  - MA20与MA120纠缠（spread 2.93%），趋势不明
ONE_LINER: 价格高位但RSI中性，处于区间震荡，SIGNAL neutral，支撑MA120 54.95，阻力需观察能否突破当前分位。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 5  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: ¥310  
PNL_PCT: +13.13%  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 现金流动性不足，建议任何加仓不超过子弹的10%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-24 > cutoff 2024-12-31)

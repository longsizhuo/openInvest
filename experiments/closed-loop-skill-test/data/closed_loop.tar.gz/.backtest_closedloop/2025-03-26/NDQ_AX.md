# Committee: NDQ.AX

**Date**: 2025-03-26
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-26",
  "vix": 18.33,
  "tnx": 4.338,
  "usdcny": 7.2569,
  "audcny": 4.5769
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂不加仓，等待宏观信号改善或价格进一步回调至$44以下再评估"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX跌破$42.63（约-10%）且DXY持续走强突破107 → 考虑减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -3550
    recovery_estimate: "4-8个月（需DXY回落+TNX企稳配合）"

PERSONAL_NOTE:
  - 当前持有NDQ.AX约104份，浮亏-4.07%（约-$211 AUD），仓位约占总资产25%，属于中等持仓规模。Macro发出明确risk_off信号（强度6），TNX月涨51.5%+DXY走强，金融条件急速收紧对美股成长股ETF形成直接压力。Quant显示2年价格分位87%估值明显偏高，价格已跌破MA120（$48.14）失守关键支撑。风险officer信号温和（ok），但不足以对冲宏观收紧信号。综合三方分歧，宏观主导，采取防御性持有策略。
  - uptrend怀疑清单检查：①价格已低于MA120（$47.37 vs $48.14），不存在向上偏离问题；②VIX从近期高位回落至18.3，恐慌消退但DXY+TNX仍在走强，市场焦虑由利率端传导；③若30天后NDQ跌10%至约$42.63，现有浮亏扩大至-14%，叠加宏观risk_off环境，加仓理由不成立。结论：不满足ACCUMULATE条件。
  - 建仓纪律：当前NDQ.AX仓位约25%且已浮亏，Macro环境risk_off不支持加仓。若后续价格跌至$44以下且DXY见顶回落、或VIX重新飙升触发恐慌性抛售出现估值洼地，再考虑小额加仓。短期内以观望为主，等待宏观信号（DXY/TNX）出现拐点。
```


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 6
SCORE: -3
KEY_HEADWIND: TNX月涨51.5%+DXY走强+实际利率上行，金融条件急速收紧，黄金承压双杀
KEY_TAILWIND: VIX跌至18.3恐慌快速消退，市场已适应高利率环境未现流动性危机
ONE_LINER: 债市剧烈调整主导宏观基调，建议减仓风险资产，黄金在美元与实际利率双压下暂避


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年价格分位87%显示估值偏高
  - RSI 48.70中性，动能不足
  - 价格低于MA120 (48.14)阻力位
ONE_LINER: 区间震荡格局，价格高位但缺乏动能，受MA120阻力，维持中性。

### Risk Officer
SIGNAL: ok  
STRENGTH: 1  
CONCENTRATION_PCT: N/A（portfolio_summary未提供集中度字段）  
DRY_POWDER_CNY: ¥31,310  
PNL_PCT: -4.07%  
WORST_CASE_LOSS_PCT_AT_-20: N/A（无法计算，缺少资产价值占比数据）  
ONE_LINER: 当前子弹充足且浮亏温和，建议加仓NDQ.AX比例不超过子弹的30%，无需减仓。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-26 > cutoff 2024-12-31)

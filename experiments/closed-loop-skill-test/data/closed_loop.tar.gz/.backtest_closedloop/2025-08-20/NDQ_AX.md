# Committee: NDQ.AX

**Date**: 2025-08-20
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.80)
**Dominant view**: macro
**Suggested allocation CNY**: 1500

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-20",
  "vix": 15.69,
  "tnx": 4.296,
  "usdcny": 7.1819,
  "audcny": 4.6354
}
```

---

## CIO Memo (Round 3)

```
VERDICT: ACCUMULATE
CONFIDENCE: 0.8
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 1500
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 800
  add_levels:
    - “if price drops 5% to ~¥50.57 → add ¥400”
    - “if price drops 10% to ~¥47.90 → add ¥300”

RISK_PLAN:
  stop_loss_trigger: “NDQ.AX价格跌破MA120支撑$48.54且VIX > 22 → 减仓30%”
  what_if_wrong:
    worst_case_pnl_cny: -1000
    recovery_estimate: “3-6个月”

PERSONAL_NOTE:
  - “您目前NDQ.AX持仓约28.5%，处于合理区间，且浮盈+7.55%，无近期止损压力。”
  - “本次建议加仓¥1,500，约占您仅剩现金子弹（¥1,860）的80%，操作后将几乎耗尽可用现金。”
  - “在强risk-on宏观（Macro）与牛市趋势（Quant）下，小幅试探是合理的，但价格分位98%的极高估值意味着必须分批、纪律性执行，严守支撑位止损。”
  - “uptrend中ACCUMULATE检查：1）价格偏离120日均线+9.66%，低于15%警戒线，均值回归风险可控；2）VIX状态未提供，假设稳定；3）即使30天后跌10%，本次仅为¥1,500的小试探仓，损失有限，且长期趋势支撑逻辑，因此理由仍成立。”
```


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 10Y收益率飙升+15.86%，名义利率上行压制久期资产估值
KEY_TAILWIND: 美元暴跌-13.92% + 实际利率大幅回落，对黄金及风险资产形成双击利好
ONE_LINER: 美元崩跌+恐慌消退构成强risk-on环境，风险资产可适度加仓，但需警惕利率反弹


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 2年价格分位98%，处于历史高位，提示估值风险
  - RSI 55.22中性偏多，未超买，趋势动能尚存
  - MA20高于MA120 +9.28%，偏离度9.66%低于15%，均值回归风险适中
ONE_LINER: uptrend中SIGNAL bullish，因MA和RSI支持，但价格分位98%高位需谨慎，支撑MA120 48.54，阻力待观察。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: ~28.5%（根据总资产¥111,895减去其他持仓推算，AUD/CNY汇率未给定存在偏差）
DRY_POWDER_CNY: ¥1,860
PNL_PCT: +7.55%
WORST_CASE_LOSS_PCT_AT_-20: ~5.7%（NDQ.AX跌20%→组合浮亏约¥6,384）
ONE_LINER: NDQ.AX浮盈+7.55%，集中度约29%处合理区间；子弹仅¥1,860，建议本次建仓≤¥1,500（子弹80%），保留部分流动性缓冲。
```

**风险要点**：
- **无情绪化追涨信号**：Dreaming 暂无历史行为模式，7天内多次买入记录未见
- **现金偏紧但不危急**：¥1,860 > ¥1,000 门槛，加仓空间有限但流动性未触红线
- **浮盈健康**：+7.55% 正向，无止损压力
- **极端压力**：若 NDQ.AX 跌 -35%，组合约承受 -10% 冲击，对 Balanced 用户属可接受范围


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-20 > cutoff 2024-12-31)

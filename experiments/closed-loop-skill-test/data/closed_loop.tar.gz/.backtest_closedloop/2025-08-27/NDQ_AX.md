# Committee: NDQ.AX

**Date**: 2025-08-27
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-27",
  "vix": 14.85,
  "tnx": 4.238,
  "usdcny": 7.152,
  "audcny": 4.6458
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前无实质可投子弹（¥360），无执行空间"

RISK_PLAN:
  stop_loss_trigger: "价格跌破MA20支撑$53.25且VIX突破20 → 减仓30%约40份；若跌破MA120约$48.70 → 清仓"
  what_if_wrong:
    worst_case_pnl_cny: "约¥6,800（-20%极端情景下对应总资产-2.0%，Risk Officer测算）"
    recovery_estimate: "2-4个月（uptrend形态未破前提下）"

PERSONAL_NOTE:
  - "用户持有NDQ.AX 135份，均价$49.66，浮盈+7.61%，仓位约占总资产30%，状态健康但无多余弹药。"
  - "可用子弹仅¥360，占总资产0.3%，即使看好也无法执行有意义的加仓，本轮建议实质为'守仓不动'。"
  - "价格处于2年99%分位极端高位（估值确性事实），10Y收益率单月飙升13%至4.24%对科技成长股估值形成直接压制（Macro核心逆风），Quant RSI仅56但价格偏离MA120达9.62%存在均值回归压力。三名分析师均未给出看多信号，维持观望是最优解。若未来回调至$50附近（MA20附近）且子弹补足，再考虑ACCUMULATE。"


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y国债收益率单月飙升13%至4.24%，名义利率上行压制成长股估值
KEY_TAILWIND: 美元指数暴跌12%至98.23+实际利率同步下行，黄金/商品获"双击"利好
ONE_LINER: 美元崩跌+实际利率走低构成罕见宽松窗口，但VIX跌至15以下暗示市场过度自满——维持现有仓位，黄金类资产可加仓，风险资产暂不追高
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位99%，处于历史极高位置，估值压力显著
  - RSI 56.57 中性，未超买但上涨动能与高位不匹配
  - 价格偏离MA120达9.62%，存在均值回归风险
ONE_LINER: 尽管REGIME为uptrend，但价格处于历史99%分位的极端高位，RSI动能不足，短期面临强均值回归压力，适合中性观察，支撑MA20@53.25，阻力为历史高位。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 4  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: 360  
PNL_PCT: +7.61%  
WORST_CASE_LOSS_PCT_AT_-20: -2.0%  
ONE_LINER: 可用子弹极低，建议暂不加仓，维持现有仓位。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-27 > cutoff 2024-12-31)

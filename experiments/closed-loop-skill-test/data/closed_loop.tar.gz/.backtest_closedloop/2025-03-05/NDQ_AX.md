# Committee: NDQ.AX

**Date**: 2025-03-05
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-05",
  "vix": 21.93,
  "tnx": 4.265,
  "usdcny": 7.2651,
  "audcny": 4.5523
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂不加仓，等待宏观信号改善"
    - "若 VIX 回落至 18 以下且 DXY 转弱，可在 MA120（~¥47.69 AUD）附近试探加 ¥3,000-5,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 MA120 支撑 ¥47.69 AUD 同时 TNX 继续上行突破 4.5% → 减仓 30%（约 26 份）"
  what_if_wrong:
    worst_case_pnl_cny: "若跌至 ¥45 AUD 水平，当前持仓额外浮亏约 ¥1,200 CNY（含已有 -3.75% 合计约 ¥2,900 CNY）"
    recovery_estimate: "宏观逆风（美债收益率飙升+美元走强）若持续，解套周期约 3-6 个月；若 Q4 降息预期回升，可缩短至 1-2 个月"

PERSONAL_NOTE:
  - 用户当前持有 NDQ.AX 88 份，浮亏 -3.75%（约 -$165 AUD），仓位规模适中，不构成减仓压力，但也不具备加仓紧迫性
  - 本次建议仓位变动为零，子弹 ¥38,300 全部保留，等待宏观环境明朗化
  - **uptrend 中为何不 ACCUMULATE 而选 HOLD**：(1) 价格离 MA120 仅偏离 1.24%，均值回归风险确实低——但这是支撑"不减仓"而非"该加仓"的理由；(2) VIX 21.93 已处恐慌区且美债收益率月涨 63% 极端异常，这不是"回调买入"信号而是系统性风险升温；(3) 若 30 天后跌 10%，Macro risk_off 叠加美元走强的逻辑只会更强，当前 ACCUMULATE 的前提——"趋势延续"——在宏观逆风下脆弱。Quant 给 neutral（非 bullish）本身就是对追多的警告。纪律建议：宁可少赚一轮，不要在宏观收紧期逆势加仓；设好 MA120 止损线，若跌破则果断减仓而非死扛


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -3
KEY_HEADWIND: 美债收益率月涨63%叠加美元走强6%，金融条件急剧收紧，风险资产承压
KEY_TAILWIND: TIP微涨表明实际利率未继续上行，衰退恐慌尚未扩散
ONE_LINER: 收益率飙升主导宏观叙事，美元走强压制成金价，整体偏向减仓观望
```

**补充说明**（供参考，不计入核心判断）：

| 因子 | 状态 | 影响 |
|------|------|------|
| TNX 4.26% | 月涨+63% 极端 | 🔴 压制估值 |
| VIX 21.93 | >20 恐慌区 | 🟡 偏高但非恐慌 |
| DXY 105.74 | 月涨+6% | 🔴 黄金/商品利空 |
| TIP +0.11% | 实际利率微降 | 🟢 仅微弱对冲 |

**货币因素判断**（若组合含黄金）：DXY强势上行是**主要逆风**，TIP微涨的实际利率利好被完全压制 → 黄金短期面临"美元双杀"格局。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位88%，处于2年历史高位
  - RSI 33.53，中性偏弱，未超买
  - 价格离MA120偏离仅1.24%，均值回归风险低
ONE_LINER: REGIME为上升趋势，但高位分位与低RSI矛盾，维持neutral，支撑MA120 47.69，阻力MA20 50.31。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥38,300
PNL_PCT: -3.75%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: NDQ.AX 现浮亏-3.75%，但可投子弹充足，当前无流动性风险，建议单资产建仓不超过总可投资金的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-05 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-06-25
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-25",
  "vix": 16.76,
  "tnx": 4.293,
  "usdcny": 7.1713,
  "audcny": 4.6578
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - “暂不加仓，维持现有持仓”

RISK_PLAN:
  stop_loss_trigger: “股价跌破$48.00（接近MA120支撑）且^VIX突破25 → 减仓50%”
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: “6-12个月”

PERSONAL_NOTE:
  - 当前NDQ.AX持仓仅占总资产约36%，处于中性区间，有浮盈+2.28%，状态健康。
  - 本次建议0元加仓，保持0%子弹消耗，为后续机会保留全部火力。
  - **核心纪律建议：当前必须选择观望。** 原因有二：1）**估值确定性事实**显示价格处于2年分位94%的极端高位，加仓风险收益比极差；2）**市场情绪表盘**触发`INDEP_DEFENSE_FLAG: on`，这是一个独立于宏观regime的快速崩盘哨兵，意味着即便趋势看起来不差，市场已进入恐慌状态。在价格高位叠加市场恐慌的共振下，任何加仓都是不理智的。等待价格回踩至MA120（约$48）或VIX显著回落至20以下，再评估是否重启网格加仓。


---

## Macro Strategist (shared)

根据提供的宏观数据直接评估：

---

**SIGNAL:** neutral
**STRENGTH:** 5
**SCORE:** +1

**KEY_HEADWIND:** 10Y收益率暴涨60%至4.29%，利率快速攀升压制风险资产估值，衰退担忧隐现。

**KEY_TAILWIND:** 美元指数大跌7.4%至97.68 + 实际利率下行（TIP+2.27%），构成黄金/商品的"双击"格局。

**ONE_LINER:** 利率飙升与VIX低迷形成矛盾信号，但美元走弱+实际利率下行支撑商品类资产；股票端因TNX冲击偏谨慎，黄金端偏乐观，整体维持、商品小仓可加。

---

**补充说明：**
- TNX月涨60%属异常剧烈，需警惕是否为财政/通胀预期恶化信号
- VIX仍在16.76偏舒适区，市场尚未定价利率冲击——若VIX回升至20+，risk_off信号将强化
- 当前环境对**黄金友好**（弱美元+低实际利率），对**高估值股票不友好**（利率上行）


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位94%处于历史高位，上涨空间受限
  - RSI 68.11接近超买区但未突破70，动能放缓
  - MA20与MA120仅差2.76%呈纠缠状态，趋势强度不足
ONE_LINER: 价格在区间高位且指标冲突，REGIME为range_bound时SIGNAL选择neutral，阻力关注前高，支撑看MA120（47.98）。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
DRY_POWDER_CNY: 8960
PNL_PCT: +2.28%
WORST_CASE_LOSS_PCT_AT_-20: <1%
ONE_LINER: 当前持仓浮盈健康，子弹充足，未见情绪化追涨，可适度加仓但建议上限为可投子弹的10%（约896元）。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-25 > cutoff 2024-12-31)

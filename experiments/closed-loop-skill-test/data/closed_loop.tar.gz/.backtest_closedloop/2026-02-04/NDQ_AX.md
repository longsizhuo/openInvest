# Committee: NDQ.AX

**Date**: 2026-02-04
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-04",
  "vix": 18.64,
  "tnx": 4.275,
  "usdcny": 6.9377,
  "audcny": 4.8713
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.70
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: NDQ.AX价格跌破 $50.00 (约MA250下方) 且 ^VIX > 25 → 评估减仓20%
  what_if_wrong:
    worst_case_pnl_cny: -6955 (假设从当前价格下跌20%，约亏损$1449 AUD)
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 用户NDQ.AX持仓占比约25.8%且已实现+6.8%浮盈，但可投子弹已耗尽（¥0）。
  - 本次建议在可投子弹中占比为0%（因无可用资金），维持现有仓位。
  - 估值偏高（处于2年分位77%高位）且市场缺乏明确方向，无资金状态下持币观望是纪律表现，应避免为加仓而挪用应急金或过度杠杆。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y美债收益率单月飙升近9%，名义利率上行压制风险资产估值。
KEY_TAILWIND: 美元指数跌至97.6(-5.8%)叠加实际利率大幅下行，为黄金/商品提供"双击"窗口。
ONE_LINER: 混合信号——VIX回落+美元崩跌对冲了利率上行压力，整体中性偏暖，维持现有仓位不加不减。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格处于2年分位77%高位，估值偏高
  - RSI(14) 30.46 处于超卖区，但趋势为空头
  - 价格逼近250日均线（51.96）关键支撑，偏离仅2.19%
ONE_LINER: 在range-bound格局中，价格高位回落至关键支撑（MA250=51.96）并伴随RSI超卖，但高位分位限制了上行空间，多空力量僵持，呈中性震荡格局。

### Risk Officer
SIGNAL: concerned
STRENGTH: 4
DRY_POWDER_CNY: ¥0
PNL_PCT: +6.80%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 可投子弹耗尽，无法加仓，建议维持现有仓位。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-04 > cutoff 2024-12-31)

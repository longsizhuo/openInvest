# Committee: NDQ.AX

**Date**: 2025-06-18
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: risk
**Suggested allocation CNY**: 1500

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-18",
  "vix": 20.14,
  "tnx": 4.397,
  "usdcny": 7.1845,
  "audcny": 4.6548
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 1500
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 1500
  add_levels:
    - "if price drops 3% (≈$47.84) → add ¥1,200"
    - "if price drops 6% (≈$46.36, near MA250支撑 ¥46.17) → add ¥1,500"

RISK_PLAN:
  stop_loss_trigger: "跌破 MA250 支撑 ¥46.17（约 -6.4%）且 VIX > 22 → 暂停所有加仓，评估是否减仓"
  what_if_wrong:
    worst_case_pnl_cny: -750
    recovery_estimate: "2-4 个月（区间震荡格局下中位数回撤修复时间）"

PERSONAL_NOTE:
  - NDQ.AX 当前持仓极轻（108份，浮盈仅+0.12%≈$6.30 AUD），仓位几乎可忽略，属于试探阶段。
  - 本次建仓金额 ¥1,500 仅占可用子弹 ¥10,460 的 14.3%，属于低水位试探，不会造成流动性压力。
  - 三方信号均呈中性偏谨慎（Quant neutral、Macro neutral、Risk ok），没有一方强烈看多，因此不做一次性重仓。价格处于 2 年高位 88% 分位 + Quant 指出趋势动能不足（MA20/MA120 仅差 1.86%），上方阻力重重；但同时 RSI 59 未超买、无追涨行为、子弹充裕，小批量网格建仓是纪律性操作。Macro 的"类滞胀前兆"格局意味着权益仓位不宜激进，但也不至于完全空仓——黄金持仓（GC=F 浮盈+16.33%）已对冲部分宏观尾部风险，组合整体风险可控。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y国债收益率飙至4.40%（MoM +58%），名义利率快速上行压制风险资产估值。
KEY_TAILWIND: 美元指数跌至98.91（MoM -7.7%）+ TIP上涨3.3%，实际利率下行构成黄金双击环境。
ONE_LINER: 利率风暴与美元崩跌并存，风险资产维持偏观望；若持仓含黄金/商品，当前宏观偏向利好，可适度持有。
```

**补充逻辑**：名义利率暴涨但实际利率却在下降（TIP涨），说明市场正在定价**通胀预期大幅上升**——这通常与关税冲击、财政赤字担忧或供应链风险相关。VIX虽回落至20但仍处警戒区间，恐慌尚未完全消退。整体宏观呈现"类滞胀前兆"格局，不宜激进加仓权益，但黄金/商品类资产的货币条件（弱美元+实际利率降）正在改善。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格处于2年高位分位88%，估值偏高，上涨空间受限。
  - RSI 59.30 中性偏强，未进入超买区。
  - 价格高于MA250 (46.17) 约6.8%，但MA20与MA120仅差1.86%，趋势动能不足。
ONE_LINER: 处于高位震荡格局，价格分位88%与中性RSI表明上行阻力重重，区间上沿或在前期高点附近，MA250 (46.17) 为下方关键支撑。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥10,460
PNL_PCT: +0.12%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: NDQ.AX 浮盈仅+0.12%，未见追涨模式，子弹充足，可小幅建仓但不超过可用现金的15%。
```

**风险要点**：
- **子弹充裕**：¥10,460 可投资金，暂无流动性压力
- **成本安全**：均价 $49.26 vs 现价 $49.32，几乎平价，无止损压力
- **无追涨行为**：Dreaming 未发现情绪化买入历史，近期无重复加仓记录
- **集中度/止损**：portfolio_summary 未提供 NDQ.AX 的持仓占比及止损位，标记 N/A

**建议**：当前状态健康，可考虑小批量建仓（≤¥1,500），避免一次性重仓推高集中度。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-18 > cutoff 2024-12-31)

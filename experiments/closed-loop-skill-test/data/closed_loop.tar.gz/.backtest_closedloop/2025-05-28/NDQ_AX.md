# Committee: NDQ.AX

**Date**: 2025-05-28
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-28",
  "vix": 19.31,
  "tnx": 4.477,
  "usdcny": 7.2037,
  "audcny": 4.6442
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.7
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 跌破关键支撑位45.82（MA250）且RSI<40 → 考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: -1660 (基于现价跌至支撑位估算)
    recovery_estimate: 1-3个月 (基于range_bound regime下的震荡修复)

PERSONAL_NOTE:
  - 用户NDQ.AX仓位浮亏仅-0.55%，整体资产配置中该仓位估算占比约24%，处于中性偏高位置，但无集中度压力。
  - 本次建议不加仓，占可投资金0%，等待市场信号更清晰。
  - 当前价格处于2年分位88%高位且MA纠缠，避免追高，纪律性持有现有仓位，关注支撑位45.82的防守情况。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y收益率暴涨至4.48%（月涨50%），紧缩预期升温压制风险资产估值。
KEY_TAILWIND: VIX暴跌33%至19.31恐慌消退，叠加美元走弱+实际利率下行，黄金类资产双击窗口开启。
ONE_LINER: 情绪偏暖但债市隐忧未消，维持仓位观望，黄金/商品可小幅加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位88%高位，但未触发超买（RSI 65.21）
  - MA20 (47.36) 低于 MA120 (48.09)，趋势不明确
  - 成交量低于均值（RVOL 0.86x），动能减弱
ONE_LINER: 价格在高位区间震荡，MA纠缠，支撑45.82（MA250），阻力48.09（MA120），REGIME为range_bound，信号中性。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥13,310
PNL_PCT: -0.55%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 该资产当前浮亏极小，可投资金充足，无集中度数据，风险可控；建议本次加仓后，该资产总仓位不超过总资产的20%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-28 > cutoff 2024-12-31)

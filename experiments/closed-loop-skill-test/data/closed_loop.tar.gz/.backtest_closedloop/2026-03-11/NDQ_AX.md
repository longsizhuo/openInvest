# Committee: NDQ.AX

**Date**: 2026-03-11
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-11",
  "vix": 24.23,
  "tnx": 4.208,
  "usdcny": 6.8765,
  "audcny": 4.895
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.5
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 若价格跌破 MA250 支撑 ($52.24 AUD) 同时 ^VIX 持续 > 25 → 减仓 20%
  what_if_wrong:
    worst_case_pnl_cny: 按当前持仓计算，NDQ.AX 若从现价下跌10%，浮亏约 -¥3,500 CNY
    recovery_estimate: 在当前下行趋势及宏观压力下，修复时间可能延长至6-9个月

PERSONAL_NOTE:
  - 用户当前已完全投资，现金子弹为¥0，无新增资金可用，这大幅限制了操作灵活性。
  - 本次建议不涉及新增资金投入（占比0%），核心任务是管理现有仓位风险。
  - 操作纪律建议：当前宏观环境（risk_off，VIX飙升）与技术面（下行趋势，价格跌破MA250）均不支持加仓。由于无现金，首要任务是守住现有利润，严格执行止损纪律，避免因市场恐慌而被动扩大亏损。耐心等待宏观信号转向或技术面出现明确企稳信号。
```


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: VIX飙升至24+且10Y收益率月涨22%，金融条件收紧、风险偏好骤降
KEY_TAILWIND: DXY跌破100叠加实际利率大幅回落，形成黄金/商品的"双击"格局
ONE_LINER: 股债承压环境明确，黄金/商品货币因素转强；整体偏防御，非避险资产维持或减仓，黄金类可适度持有
```

---

**补充逻辑**：

| 维度 | 判断 | 依据 |
|------|------|------|
| 利率 | ⚠️ 鹰 | TNX 4.21% 月涨22%，长端利率上行凶猛 |
| 恐慌 | 🔴 高 | VIX 24.23 月涨36%，已进入"恐惧"区间 |
| 美元 | ✅ 弱 | DXY 99.23 月跌2.8%，跌破关键心理关口 |
| 实际利率 | ✅ 降 | TIP月涨9.7%，实际利率快速回落 |

**核心矛盾**：宏观流动性收紧（利率+VIX双升）但货币因素（弱美元+低实际利率）极度利好黄金。这是典型的"避险+通胀预期"组合——市场在定价"滞胀"风险。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位67%，未达bearish阈值70%
  - RSI(14) 43.29，处于中性区间，无超买超卖
  - 价格跌破MA250(-1.58%)，但成交量低于均值(RVOL 0.75x)
ONE_LINER: 在下行趋势中，技术指标显示中性：价格分位未高且RSI无极端，趋势弱势但未触发bearish信号，阻力位55.29（MA120），支撑位52.24（MA250）。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥0
PNL_PCT: +3.40%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 子弹为0，无法加仓，当前NDQ.AX持仓浮盈稳定，建议维持现仓位。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-11 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-05-07
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.35)
**Dominant view**: macro
**Suggested allocation CNY**: 700

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-07",
  "vix": 23.55,
  "tnx": 4.275,
  "usdcny": 7.2163,
  "audcny": 4.6952
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.35
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 700
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 700
  add_levels:
    - "if NDQ.AX drops 5% from current A$45.22 to ~A$42.96 → add ¥700"
    - "if NDQ.AX drops 10% from current A$45.22 to ~A$40.70 → add ¥1,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 累计浮亏达 -15%（均价$49.39下约$41.98）或 VIX 突破 30 → 停止加仓并评估清仓"
  what_if_wrong:
    worst_case_pnl_cny: -320
    recovery_estimate: "4-6 个月，需等待美联储政策转鸽或科技股盈利超预期"

PERSONAL_NOTE:
  - Quant Worker 报告不可用，技术面缺乏信号，confidence 受限；NDQ.AX 当前 -8.44% 浮亏已超警戒线但未触及 -15% 硬止损
  - 本次建仓 ¥700 占子弹 5%，属于最小试探仓，保留 ¥13,310 弹药等待 Quant 信号回归或价格进一步下探
  - uptrend 三大检查：①无120日均线偏离数据但 NASDAQ100 估值已较高，名义利率飙升环境下高估值资产承压；②VIX 23.55 处于"恐惧区"但已回落10%，并非从低位急升；③若30天后跌10%，持仓浮亏将达-18%，触及止损线——当前逻辑仍成立但需严守止损纪律，绝不加码到让亏损威胁整体组合稳定


---

## Macro Strategist (shared)

**Macro Assessment:**

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y收益率暴涨+40%至4.28%，名义利率快速收紧压制风险资产估值
KEY_TAILWIND: 美元指数跌破100且TIP上涨，实际利率下行+弱美元构成双击利好黄金
ONE_LINER: 宏观信号矛盾——弱美元+实际利率下行利好黄金，但名义利率飙升压制风险偏好；建议维持现有仓位，等待收益率见顶确认后再加仓
```

---

**核心逻辑拆解：**

| 指标 | 状态 | 宏观含义 |
|------|------|----------|
| TNX 4.28% (+40% MoM) | 🔴 暴涨 | 金融条件急剧收紧，高估值资产承压 |
| VIX 23.55 (-10% MoM) | 🟡 偏高但回落 | 恐慌情绪在消退，但仍在"恐惧区" |
| DXY 99.61 (-4.4% MoM) | 🟢 弱势 | 美元走弱=全球流动性改善 |
| TIP +2.44% MoM | 🟢 上涨 | 实际利率下行=黄金核心顺风 |

**关键矛盾：** 名义利率飙升 vs 实际利率下行 → 通胀预期在攀升。若通胀粘性被证实，美联储难以降息，名义利率维持高位将持续压制风险资产。黄金受益于"通胀对冲+弱美元"双击，但需警惕利率拐点。


---

## Round 1 — Independent Briefs


### Quant Analyst
{
  "action": "analyze_multi_timeframe",
  "action_input": {
    "symbol": "NDQ.AX"
  }
}

### Risk Officer
SIGNAL: concerned
STRENGTH: 4
DRY_POWDER_CNY: ¥14,010
PNL_PCT: -8.44%
WORST_CASE_LOSS_PCT_AT_-20: ≈4.3%
ONE_LINER: NDQ.AX浮亏-8.44%已超-5%警戒线，建议设止损位-15%；若加仓建议≤子弹30%（约¥4,200），保持分散。

**风险分析**：
- **浮亏评估**：NDQ.AX当前亏损-8.44%（≈$-437 AUD），已进入止损关注区间，但尚未达-15%硬止损线
- **子弹充裕**：¥14,010可投现金充足，不影响流动性
- **历史模式**：Dreaming暂无数据，无追涨情绪化记录
- **压力测试**：若NDQ.AX再跌20%，基于其约22%仓位占比，整体组合损失约4.3%，在Balanced风险偏好可承受范围内
- **建议**：持仓观察为主，设-15%止损；若反弹加仓，单次不超过子弹的30%


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-07 > cutoff 2024-12-31)

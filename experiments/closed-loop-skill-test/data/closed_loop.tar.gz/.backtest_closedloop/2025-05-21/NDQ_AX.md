# Committee: NDQ.AX

**Date**: 2025-05-21
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-21",
  "vix": 20.87,
  "tnx": 4.596,
  "usdcny": 7.2194,
  "audcny": 4.6386
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若价格有效跌破$46（约120日均线区域）同时^VIX > 22 → 考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: -2500
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 当前NDQ.AX持仓小亏（-1.47%），仓位占比适中，整体资产配置平衡。
  - 本次建议为维持现状（HOLD），不新增任何子弹，等待更明确的技术或宏观信号。
  - 价格处于2年历史高位（87%分位），但动能不足（RSI 65，量缩），在利率风暴尾声与恐慌缓释期，应保持耐心，避免在震荡区间内追涨杀跌。


---

## Macro Strategist (shared)

**宏观快照分析：**

利率端信号最为剧烈——10Y收益率飙升至4.60%、月涨47%，为近期最大冲击源，暗示期限溢价重定价或财政/通胀担忧升温。但VIX从高位回落至20.87，恐慌情绪正在消化。美元跌破100且实际利率下行，对黄金/商品形成罕见的"双击"组合。

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y收益率暴涨至4.60%（月涨47%），融资成本飙升压制久期资产
KEY_TAILWIND: 美元跌破100+实际利率下行，黄金/商品获货币面双击支撑
ONE_LINER: 利率风暴猛烈但恐慌已缓释，维持现有仓位，勿追涨杀跌
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格处于2年87%分位，历史高位区域，追高风险大
  - RSI 65接近超买区，但未突破70，动量中性偏强
  - 成交量萎缩（RVOL 0.65x），价格与MA20/MA120纠缠，无明确趋势
ONE_LINER: REGIME为区间震荡，价格在历史高位（87%分位）且量能不足，技术指标显示上涨动能减弱，故维持中性观察。

### Risk Officer
SIGNAL: ok  
STRENGTH: 3  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: ¥13,310  
PNL_PCT: -1.47%  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 当前风险可控，建议建仓比例上限25%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-21 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-11-19
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-19",
  "vix": 23.66,
  "tnx": 4.133,
  "usdcny": 7.1075,
  "audcny": 4.626
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.70
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 当前子弹仅 ¥310，不满足任何有意义的加仓金额，无执行计划

RISK_PLAN:
  stop_loss_trigger: 日线收盘跌破 MA120 ($53.59) 且 VIX 维持 > 25 → 考虑减仓 20% 约 27 份锁定利润
  what_if_wrong:
    worst_case_pnl_cny: 若从现价回落至 MA120 ($53.59)，现有 135 份浮亏约 -$263 AUD（≈ -¥1,250 CNY），当前浮盈 $794 AUD 缩水至 $531
    recovery_estimate: 2-4 个月（中长期趋势仍 bullish，MA120/MA200 均上行提供支撑）

PERSONAL_NOTE:
  - 当前持有 NDQ.AX 135 份，均价 $49.66，浮盈 +11.82%（约 ¥3,750 CNY），持仓状态健康；总资产 ¥124,265 中现金仅 ¥310，子弹几乎为零，无空间做任何加仓操作
  - 本次建议占子弹比例 0%——不是因为 NDQ 不好，而是物理上没有弹药；¥310 即使取 10% 仅 ¥31，连一股都买不到，不值得交易
  - 短期 RSI 38.7 已进入超卖区、价格低于 MA20/MA50，但 MA120 ($53.59) 和 MA200 ($51.34) 仍在下方托底且上行——这是典型的"短期回调、中期趋势未破"格局，不要因为几天的下跌恐慌割肉；反过来说，VIX 23.66 偏高 + Macro 中性偏谨慎，也不是追加的时候。当前最优策略就是坐稳，等子弹恢复（新增资金或减持其他标的释放现金）后再评估是否在 $53.59 附近接回


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率急升+VIX攀升至23.66，金融条件收紧压制风险偏好
KEY_TAILWIND: 美元走弱(-3.79%)叠加实际利率大幅下行(TIP+12%)，为黄金/商品提供"双击"环境
ONE_LINER: 债市与汇率信号相悖，整体中性偏谨慎，建议维持现有仓位，黄金类可择机小幅加仓


---

## Round 1 — Independent Briefs


### Quant Analyst
```json
{
  "symbol": "NDQ.AX",
  "analysis": {
    "current_price": 55.53,
    "multi_timeframe_data": {
      "daily": {
        "rsi_14": 38.71,
        "ma_20": 57.47,
        "ma_50": 56.12,
        "ma_120": 53.59,
        "ma_200": 51.34,
        "atr_14": 1.08,
        "volatility": 0.15
      },
      "weekly": {
        "rsi_14": 45.23,
        "ma_20": 56.89,
        "ma_50": 55.67,
        "ma_120": 52.45,
        "ma_200": 50.23,
        "atr_14": 1.45,
        "volatility": 0.12
      },
      "monthly": {
        "rsi_14": 52.34,
        "ma_20": 56.12,
        "ma_50": 54.89,
        "ma_120": 51.23,
        "ma_200": 49.12,
        "atr_14": 2.12,
        "volatility": 0.10
      }
    },
    "key_levels": {
      "support": [53.59, 50.73, 49.12],
      "resistance": [57.47, 58.90, 60.00]
    },
    "trend_analysis": {
      "short_term": "bearish",
      "medium_term": "bullish",
      "long_term": "bullish"
    }
  }
}
```

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥310
PNL_PCT: +11.82%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 现金流动性紧张，建议建仓比例上限为可用子弹的10%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-19 > cutoff 2024-12-31)

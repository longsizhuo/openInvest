# Committee: GC=F

**Date**: 2025-11-19
**Symbol**: GC=F
**Verdict**: HOLD (confidence 0.62)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-19",
  "vix": 23.66,
  "tnx": 4.133,
  "usdcny": 7.1075,
  "audcny": 4.626
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.62
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 可用子弹仅¥310，客观无法执行加仓
    - 若未来补充子弹≥¥5000，可在价格回踩¥3,800（120日均线附近）时考虑ACCUMULATE

RISK_PLAN:
  stop_loss_trigger: 价格跌破¥3,800（120日均线3620.82上方保护带）且周线RSI下穿40 → 考虑减仓至≤25%仓位
  what_if_wrong:
    worst_case_pnl_cny: 若从现价回撤15%，浮盈缩水约¥6,400，仍保持正收益
    recovery_estimate: 基于2年RSI 81超买区间，深度回调后恢复期约3-6个月

PERSONAL_NOTE:
  - 用户GC=F持仓浮盈+39.10%，已达¥12,043，占总资产约9.7%，集中度34.5%处于中性区间上限附近——当前仓位健康但弹药枯竭
  - 本次建议在子弹中占比：0%（子弹仅¥310，不具备操作意义）
  - 持币观望的原因并非看空黄金，而是"无弹药可打"+"价格处于2年分位97%极高位"的双重约束；Quant数据120日均线偏离+12.6%接近15%均值回归临界点，当前追高性价比极差——守住浮盈等待回调，比在山顶加仓更符合纪律


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率急升+VIX攀升至23.66，金融条件收紧压制风险偏好
KEY_TAILWIND: 美元走弱(-3.79%)叠加实际利率大幅下行(TIP+12%)，为黄金/商品提供"双击"环境
ONE_LINER: 债市与汇率信号相悖，整体中性偏谨慎，建议维持现有仓位，黄金类可择机小幅加仓


---

## Round 1 — Independent Briefs


### Quant Analyst
{
  "symbol": "GC=F",
  "timeframes": {
    "1d": {
      "rsi_14_wilder": 53.44,
      "price_ma_20": 4049.58,
      "price_ma_50": 3973.19,
      "price_ma_120": 3620.82,
      "price_ma_250": 3271.6,
      "price_percentile_1y": 95.51,
      "price_percentile_2y": 97.22,
      "atr_pct": 1.88
    },
    "1w": {
      "rsi_14_wilder": 49.63,
      "price_ma_20": 4085.43,
      "price_ma_50": 3927.06,
      "price_ma_120": 3552.81,
      "price_ma_250": 3256.25,
      "price_percentile_1y": 94.87,
      "price_percentile_2y": 96.54,
      "atr_pct": 4.54
    },
    "1m": {
      "rsi_14_wilder": 55.21,
      "price_ma_20": 4021.03,
      "price_ma_50": 3896.51,
      "price_ma_120": 3503.73,
      "price_ma_250": 3224.09,
      "price_percentile_1y": 96.13,
      "price_percentile_2y": 97.79,
      "atr_pct": 6.97
    },
    "3m": {
      "rsi_14_wilder": 62.73,
      "price_ma_20": 3972.41,
      "price_ma_50": 3844.39,
      "price_ma_120": 3436.85,
      "price_ma_250": 3175.85,
      "price_percentile_1y": 98.11,
      "price_percentile_2y": 99.06,
      "atr_pct": 10.25
    },
    "6m": {
      "rsi_14_wilder": 70.25,
      "price_ma_20": 3832.61,
      "price_ma_50": 3705.66,
      "price_ma_120": 3343.78,
      "price_ma_250": 3104.71,
      "price_percentile_1y": 99.35,
      "price_percentile_2y": 99.67,
      "atr_pct": 14.53
    },
    "1y": {
      "rsi_14_wilder": 76.53,
      "price_ma_20": 3550.02,
      "price_ma_50": 3456.87,
      "price_ma_120": 3126.34,
      "price_ma_250": 2937.68,
      "price_percentile_1y": 99.82,
      "price_percentile_2y": 99.91,
      "atr_pct": 17.86
    },
    "2y": {
      "rsi_14_wilder": 81.22,
      "price_ma_20": 3198.59,
      "price_ma_50": 3092.14,
      "price_ma_120": 2811.23,
      "price_ma_250": 2611.86,
      "price_percentile_1y": 99.91,
      "price_percentile_2y": 99.96,
      "atr_pct": 21.34
    }
  }
}

### Risk Officer
SIGNAL: concerned
STRENGTH: 6
CONCENTRATION_PCT: 34.5%
DRY_POWDER_CNY: ¥310
PNL_PCT: +39.10%
WORST_CASE_LOSS_PCT_AT_-20: -6.9%
ONE_LINER: 黄金浮盈丰厚但集中度已达上限附近，可用子弹仅¥310；若为加仓决策则不可执行（无弹药），若为减仓则属合理获利了结——建议GC=F仓位维持或减至≤30%总资产，腾出现金补弹药。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-19 > cutoff 2024-12-31)

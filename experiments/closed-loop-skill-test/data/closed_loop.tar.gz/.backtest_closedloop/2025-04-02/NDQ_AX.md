# Committee: NDQ.AX

**Date**: 2025-04-02
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-02",
  "vix": 21.51,
  "tnx": 4.196,
  "usdcny": 7.2697,
  "audcny": 4.5721
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 价格跌破44.50（MA250下方约1%）或^VIX突破22同时NDQ.AX价格低于46.00 → 减仓20%（约20份）
  what_if_wrong:
    worst_case_pnl_cny: -4700
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 当前NDQ.AX持仓浮亏-8.06%，已跌破20日均线，处于Quant确认的下跌趋势中。
  - 本次建议为不新增资金，完全使用现有仓位应对。
  - 操作纪律：坚持预设的止损纪律，避免在下跌趋势中因“摊薄成本”的心理而过早加仓，等待RSI进入超卖区（<30）或价格触及明确支撑（如45.08）后再评估。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率单月暴涨近37%，金融条件显著收紧，风险资产估值承压
KEY_TAILWIND: VIX从高位回落31%，恐慌情绪明显退潮；实际利率下行对黄金构成支撑
ONE_LINER: VIX回落缓解恐慌但收益率飙升压制估值，宏观信号矛盾，建议整体维持仓位不追高


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - 价格2年分位80%，估值偏高  
  - RSI(14)=37.83，中性偏弱未超卖  
  - MA20=46.08低于MA120=48.23，下跌趋势确认  
ONE_LINER: 在下跌趋势中，价格高位但RSI未超卖，支撑MA250=45.08、阻力MA120=48.23，信号中性。

### Risk Officer
SIGNAL: concerned  
STRENGTH: 6  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: ¥31,310  
PNL_PCT: -8.06%  
WORST_CASE_LOSS_PCT_AT_-20: 4.31%  
ONE_LINER: 浮亏-8.06%，建议减仓20%或设置止损线以控制风险。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-02 > cutoff 2024-12-31)

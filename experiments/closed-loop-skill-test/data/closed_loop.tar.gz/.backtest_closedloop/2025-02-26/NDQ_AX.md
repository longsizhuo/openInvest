# Committee: NDQ.AX

**Date**: 2025-02-26
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-26",
  "vix": 19.1,
  "tnx": 4.249,
  "usdcny": 7.2476,
  "audcny": 4.6032
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若NDQ.AX回踩$44.50附近（MA120支撑带）且10Y收益率回落至3.8%以下 → 可用10%子弹加仓约¥3,830"
    - "若RSI跌至25以下且宏观信号由risk_off转neutral → 再加5%子弹约¥1,915"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX跌破$43.00（约-12.8%）或10Y收益率突破4.5%且DXY站上108 → 减仓当前持仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -4000
    recovery_estimate: "3-6个月，取决于美联储政策转向与美债收益率见顶时点"

PERSONAL_NOTE:
  - "NDQ.AX浮亏仅-1.70%，仓位占总资产约20%，属于轻仓状态，无紧急减仓压力"
  - "本次子弹¥38,300全额留存不加仓，核心原因：Macro risk_off强度8是过去数年罕见的紧缩信号——10Y收益率单月飙升80%对成长股（NDQ=纳指100）估值构成系统性压缩，这不是'回调买入'的环境"
  - "Quant信号中性、RSI 35.93接近超卖确实暗示短期技术反弹可能，但在宏观强紧缩背景下，技术反弹高度有限且随时可能被新一轮抛售打断；若30天后再跌10%，在收益率持续上行的假设下ACCUMULATE理由不成立"
  - "MA120偏离仅4.08%，均值回归风险可控，趋势结构未破——这正是选择HOLD而非TRIM的理由：不追加、不割肉、等宏观拐点"
  - "纪律提示：下一次加仓窗口不是'价格跌了就行'，而是需要看到10Y收益率趋势性回落（低于4%）或VIX突破25后回落——宏观环境改善才是真正的入场信号"


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 8
SCORE: -3
KEY_HEADWIND: 10Y收益率单月飙升80%至4.25%叠加美元指数飙至106，金融条件急剧收紧
KEY_TAILWIND: VIX仍处19附近未破恐慌阈值，短期无系统性流动性危机
ONE_LINER: 美债收益率暴力抬升+强美元双杀组合，全面减仓防御，尤其规避久期资产与商品多头
```

---

**判断逻辑**：

| 因子 | 状态 | 影响 |
|------|------|------|
| TNX +80% MoM | ⚠️ 极端紧缩信号 | 估值压缩，risk-off 核心驱动 |
| DXY 106.42 +8.25% | ⚠️ 强势美元 | 黄金/商品双杀（HEADWIND） |
| TIP -1.97% (实际利率上行) | ⚠️ 黄金双杀第二刀 | 实际利率升+美元强=黄金最差环境 |
| VIX 19.1 | 🟡 中性偏紧 | 未恐慌但已不舒适 |

**结论**：收益率月涨80%是过去数年罕见的紧缩力度，叠加美元走强，宏观环境明确偏防御。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:
  - 价格2年分位89%，处于历史高位，估值偏高
  - RSI(14) 35.93接近超卖区，短期动能偏弱
  - MA120偏离度4.08%低于15%阈值，均值回归风险可控  
ONE_LINER: 上升趋势中价格高位回调且RSI超卖，短期支撑在MA120（47.37），阻力在近期高点，信号为中性因分位过高与趋势衰竭迹象混合。

### Risk Officer
SIGNAL: ok
STRENGTH: 4
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: 38300
PNL_PCT: -1.70%
WORST_CASE_LOSS_PCT_AT_-20: ≈1.2%
ONE_LINER: 资产浮亏轻微，子弹充足，当前无明显追涨风险，建议维持适度配置。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-26 > cutoff 2024-12-31)

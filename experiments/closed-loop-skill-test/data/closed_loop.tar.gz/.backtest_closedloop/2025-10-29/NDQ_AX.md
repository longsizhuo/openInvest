# Committee: NDQ.AX

**Date**: 2025-10-29
**Symbol**: NDQ.AX
**Verdict**: TRIM (confidence 0.70)
**Dominant view**: risk
**Suggested allocation CNY**: -1500

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-29",
  "vix": 16.92,
  "tnx": 4.058,
  "usdcny": 7.0988,
  "audcny": 4.6731
}
```

---

## CIO Memo (Round 3)

VERDICT: TRIM
CONFIDENCE: 0.7
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: -1500
TRIM_REASON: bearish
REENTRY_PRICE: 52.50
REENTRY_CONDITION: 价格跌至 52.50 AUD 且 RSI<40 或 VIX 回落至 <20
EXPECTED_PATH: 基于 Quant 技术分析，价格大幅偏离 120 日均线，均值回归风险高，预期在上升趋势中大概率回踩支撑位 MA120（52.49 AUD）附近，为买回提供更好价位。

EXECUTION_PLAN:
  mode: lump-sum
  first_tranche_cny: -1500
  add_levels: N/A

RISK_PLAN:
  stop_loss_trigger: 价格若未回调反向上突破 60.00 AUD 且 RSI 仍>80，则重新评估是否需补充持仓。
  what_if_wrong:
    worst_case_pnl_cny: -500 (若减仓后价格直接上涨，错失部分潜在利润)
    recovery_estimate: 1-3 个月 (若价格回调至目标位买回，可降低持仓成本)

PERSONAL_NOTE:
  - 用户 NDQ.AX 持仓浮盈 17.40%，但可投现金仅 310 元，流动性已极度紧张，任何回调或意外支出都将面临无米之炊的困境。
  - 本次建议减仓 1500 元，旨在强制锁定部分利润并优先补充现金弹药，减仓金额约占 NDQ.AX 持仓市值的 5%。
  - 操作纪律优先：当前首要任务是修复资产负债表（补充现金），而非追求最后一个铜板。纪律是战胜波动的最后防线。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率月涨15%，利率上行压力制约风险资产估值
KEY_TAILWIND: 美元指数月跌5.8%+实际利率下行，黄金/商品双击环境明确
ONE_LINER: 大宗商品配置窗口打开，风险资产维持观望
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 8
KEY_DATA:
  - RSI 73.49 超买，进入危险区
  - 价格分位 100% 历史最高，估值偏高
  - 价格离MA120偏离度16.42% 高，均值回归风险高
ONE_LINER: 上升趋势中但技术指标超买严重，价格创两年新高且大幅偏离MA120，bearish信号，支撑位MA120 52.49。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: 310
PNL_PCT: +17.40%
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 现金流动性极低，且无历史行为数据，建议暂停加仓，优先补充现金至合理水平。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-29 > cutoff 2024-12-31)

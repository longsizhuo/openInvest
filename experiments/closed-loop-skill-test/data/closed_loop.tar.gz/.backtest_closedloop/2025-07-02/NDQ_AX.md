# Committee: NDQ.AX

**Date**: 2025-07-02
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 2000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-02",
  "vix": 16.64,
  "tnx": 4.293,
  "usdcny": 7.1645,
  "audcny": 4.7146
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 2000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 1000
  add_levels:
    - "若价格跌至 $49.50（约-2%）→ 加仓 ¥500"
    - "若价格跌至 $48.00（约-5%）→ 加仓 ¥500"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 $47.00 且 ^VIX > 20 → 减仓当前仓位的 30%"
  what_if_wrong:
    worst_case_pnl_cny: -400
    recovery_estimate: "2-4 个月"

PERSONAL_NOTE:
  - 当前 NDQ.AX 仓位浮盈 +2.58%，资产配置相对分散，但估值处于2年分位94%偏高区间，需警惕高位震荡风险。
  - 本次加仓金额 ¥2,000 占可投子弹的 23.6%，属试探性小仓，为后续分批留足空间。
  - 操作纪律：宏观中性且 Quant 观望下，避免一次性重仓；设置好止损条件，若价格跌破关键支撑则果断执行，防止小亏变大亏。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: 1
KEY_HEADWIND: TNX 三个月飙升60%至4.29%，名义利率压力仍在，估值承压
KEY_TAILWIND: DXY跌至96.78三个月新低+TIP上行2.73%，实际利率下行+美元走弱双击黄金
ONE_LINER: 恐慌消退（VIX 16.6）、美元持续走弱利好商品；但名义利率高企限制全面risk_on，建议维持现有仓位、黄金/商品类可小幅加仓
```

**补充说明**：近10日TNX在4.23-4.40区间企稳略有回落，DXY连创新低（98.9→96.8），VIX已从20+回落至16.6——市场从"恐慌定价"转向"温和risk-on"。对组合中黄金/商品类资产而言，**DXY弱势+实际利率下行**是明确双击窗口；名义利率虽高但趋势已转平，不再是核心压制。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 4  
KEY_DATA:  
  - 价格2年分位94%，估值偏高  
  - RSI 64.37，中性偏高未超买  
  - MA20与MA120仅差3.6%，趋势纠缠  
ONE_LINER: 价格高位震荡，RSI中性，在区间震荡REGIME下无明确方向，建议中性观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥8,460
PNL_PCT: +2.58%
WORST_CASE_LOSS_PCT_AT_-20: 5.09%
ONE_LINER: 风险较低，建议NDQ.AX加仓后仓位不超过总资产的30%，使用可用子弹的50%以内。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-02 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-11-05
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-05",
  "vix": 18.01,
  "tnx": 4.157,
  "usdcny": 7.1295,
  "audcny": 4.6236
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "（当前现金 ¥310 无法执行任何操作）若后续有资金到账 + 价格回踩至 $54.0（支撑区间上沿）→ 可加 ¥3,000 试探仓"
    - "若价格进一步跌至 $52.89（Quant 支撑位）+ RSI < 45 → 可加 ¥5,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 $52.89（Quant 支撑位）同时 ^VIX > 22 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: "约 -¥7,490（NDQ.AX 市值约 ¥37,460 × -20%）"
    recovery_estimate: "3-6 个月（基于上升趋势历史修复速度）"

PERSONAL_NOTE:
  - 当前 NDQ.AX 持仓 135.28 份，浮盈 +15.93%，持仓状态健康；但现金仅 ¥310 几乎归零，弹药耗尽是本次裁决的硬约束
  - 本次建议新增投入 ¥0，占可投子弹 0%——不是不想加，是没钱加
  - 纪律建议：Quant + Macro 都看多但价格处于 2 年分位 99%（历史极值），追高风险大；当前策略是「守住仓位等回调 + 等新资金」，而非在高位借钱加仓。设好 $52.89 止损线，耐心等待
  - [uptrend ACCUMULATE 检查] ①价格离 MA120 偏离 8.85% < 15%，均值回归风险可控 ②VIX 18.01 未从低位急升，无恐慌信号 ③即使 30 天后跌 10%，上升趋势 + Macro risk_on 逻辑仍成立——但 Cash=¥310 使得任何加仓操作物理上不可执行，本条检查结果为「有条件 ACCUMULATE 但无弹药」


---

## Macro Strategist (shared)

**Macro 快照已获取，综合判断如下：**

---

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y收益率4.16%且月涨19%，名义利率飙升压制久期资产估值
KEY_TAILWIND: 美元指数月跌4.69%至100.2，叠加实际利率下行，流动性环境显著改善
ONE_LINER: VIX回落+美元走弱+实际利率下行构成"三箭齐发"的risk-on格局，名义利率上行暂居次席——整体偏向小幅加仓，但警惕美债收益率二次冲高风险。
```

---

**简析：**
- 🟢 **VIX 18.01**：恐慌消退，低于20警戒线，市场风险偏好回升
- 🟢 **DXY 100.2（-4.69%）**：美元显著走弱，利好全球资产与大宗商品
- 🟢 **TIP +9.90%**：实际利率大幅回落，为黄金/商品提供强支撑
- 🟡 **TNX 4.16%（+19%）**：名义利率飙升是主要隐含风险，但目前被美元弱势对冲

**黄金/商品视角**：DXY走弱 + 实际利率下行 = **黄金双击格局**，货币因素强烈利好。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: bullish  
STRENGTH: 5  
KEY_DATA:  
  - 价格2年分位99%，历史高位但趋势未破坏  
  - RSI 59.25中性偏强，未进入超买区  
  - 价格离MA120偏离度8.85%，均值回归风险低  
ONE_LINER: 上升趋势中RSI健康，支撑52.89阻力58.0，SIGNAL bullish但分位高位需谨慎。

### Risk Officer
SIGNAL: concerned
STRENGTH: 7/10
CONCENTRATION_PCT: N/A（集中度 lens 已关闭）
DRY_POWDER_CNY: ¥310
PNL_PCT: +15.93%
WORST_CASE_LOSS_PCT_AT_-20: -6%（NDQ.AX 市值约 ¥37,460，跌20%损失约 ¥7,490 / 总资产 ¥124,874）
ONE_LINER: 现金仅 ¥310 几乎归零，无力加仓；NDQ.AX 浮盈 +15.93% 状态健康，建议暂不操作，待后续资金到账再议，当前持仓上限维持现状不增。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-05 > cutoff 2024-12-31)

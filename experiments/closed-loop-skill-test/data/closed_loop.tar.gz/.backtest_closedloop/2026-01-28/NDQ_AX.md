# Committee: NDQ.AX

**Date**: 2026-01-28
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-28",
  "vix": 16.35,
  "tnx": 4.251,
  "usdcny": 6.9545,
  "audcny": 4.8646
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若价格跌破关键支撑51.90（MA250），同时 ^VIX > 22，则建议减仓20%以锁定部分利润并控制回撤。
  what_if_wrong:
    worst_case_pnl_cny: -2200
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 用户当前NDQ.AX持仓浮盈+10.62%，但现金子弹为零，无任何新增投资能力。
  - 本次建议新增配置为0元，占总可投资金比例0%。
  - 心理与纪律建议：价格处于两年高位（84%分位），均值回归压力客观存在，当前不是追高时机。应保持耐心，等待价格回调至更合理区间或未来有现金流入时再评估。避免在高位因情绪驱动而挪用其他资产仓位。


---

## Macro Strategist (shared)

```yaml
SIGNAL: risk_on
STRENGTH: 6
SCORE: 3
KEY_HEADWIND: 10年期美债收益率升至4.25%，压制估值。
KEY_TAILWIND: 美元指数单月暴跌7.6%，大幅缓解全球流动性压力。
ONE_LINER: 美元弱势主导，宏观环境支持风险偏好回升，建议逢低加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格处于两年历史分位84%高位，有均值回归压力
  - RSI 38.47中性偏弱，未现超卖或超买
  - MA20与MA120纠缠，趋势不明确
ONE_LINER: 当前处于高位区间震荡，REGIME为range_bound，SIGNAL neutral；价格若回撤，关键支撑在MA250附近51.90。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: ¥0
PNL_PCT: +10.62%
WORST_CASE_LOSS_PCT_AT_-20: N/A

**ONE_LINER:** 可投子弹为零，NDQ.AX 浮盈+10.62%，无追涨记录，当前无加仓能力；建议保持现有仓位，待现金回补后再评估，暂无减仓压力。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-28 > cutoff 2024-12-31)

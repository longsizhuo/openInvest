# Committee: NDQ.AX

**Date**: 2025-07-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-09",
  "vix": 15.94,
  "tnx": 4.342,
  "usdcny": 7.1738,
  "audcny": 4.6809
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD  
CONFIDENCE: 0.6  
DOMINANT_VIEW: macro  
SUGGESTED_ALLOC_CNY: 0  
TRIM_REASON: N/A  
REENTRY_PRICE: N/A  
REENTRY_CONDITION: N/A  
EXPECTED_PATH: N/A  

EXECUTION_PLAN:  
  mode: none  
  first_tranche_cny: 0  
  add_levels: N/A  

RISK_PLAN:  
  stop_loss_trigger: "NDQ.AX价格跌破¥48.06（MA120）且^VIX > 22 → 减仓30%"  
  what_if_wrong:  
    worst_case_pnl_cny: ≈¥5,900（若NDQ持仓跌20%，基于当前持仓约¥29,457）  
    recovery_estimate: "若趋势延续，预计3-6个月解套"  

PERSONAL_NOTE:  
  - 用户NDQ持仓浮盈+3.65%，配置占比约27%，处于合理区间，无集中度压力。  
  - 本次建议分配0%子弹（¥0），因价格历史高位（分位98%），RSI 66.28接近超买，且成交量萎缩显示上涨动能不足，加仓风险收益比不佳。  
  - 操作纪律：在uptrend中，价格偏离MA120仅6.44%（<15%），均值回归风险可控，但量价背离（成交量0.51倍均量）提示上涨不可持续；若30天后跌10%，当前ACCUMULATE理由不成立，因此HOLD优于追涨。建议耐心等待价格回调至MA120（¥48.06）附近或RSI回落至50以下再评估加仓。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 十年期美债收益率飙升至4.34%，紧缩环境压制风险资产估值。
KEY_TAILWIND: 美元指数走弱至97.47且实际利率下行，为黄金与大宗商品提供双重支撑。
ONE_LINER: 宏观环境呈现矛盾，高利率压制估值但弱美元支撑商品，建议维持现有配置。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位98%，估值处于历史高位，追涨风险极高
  - RSI(14) 66.28接近超买，成交量萎缩至0.51倍均量，上涨动能不足
  - 趋势指标：价格离MA120偏离度6.44%，MA20-MA120价差4.46%，需警惕趋势衰竭
ONE_LINER: 尽管REGIME为上升趋势，但价格分位、RSI及量价背离显示上行动能衰减，维持neutral，关注MA120（48.06）支撑有效性。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（portfolio_summary 未提供该字段）
DRY_POWDER_CNY: ¥6,460
PNL_PCT: +3.65%
WORST_CASE_LOSS_PCT_AT_-20: ≈5.5%（NDQ 持仓约¥29,457，总资产¥107,559）
ONE_LINER: 持仓浮盈、子弹充裕、无情绪化追涨迹象，NDQ 配置约 27% 处合理区间，建议单次加仓 ≤ 可投子弹 10%（¥646）。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-09 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-09-24
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-24",
  "vix": 16.18,
  "tnx": 4.147,
  "usdcny": 7.1116,
  "audcny": 4.6918
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.7
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: N/A

RISK_PLAN:
  stop_loss_trigger: 如果价格跌破 $50.00 (接近MA120) 或 ^VIX 升至 22 以上 → 重新评估减仓
  what_if_wrong:
    worst_case_pnl_cny: -6890
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 用户当前NDQ.AX持仓浮盈+10.27%，总资产分布分散，整体无止损压力。
  - 子弹仅¥360已近枯竭，本次建议不加仓，保持现有仓位占比。
  - 价格处于2年历史100%分位高位，均值回归风险高，建议避免追高，保持纪律等待更好机会。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 名义利率温和上行(TNX 4.15%, MoM+3.29%)对风险资产估值构成边际压力
KEY_TAILWIND: 美元大幅走弱(DXY -11.57%) + 实际利率显著下行(TIP +13.93%)，黄金/商品获双击利好
ONE_LINER: VIX跌至16+美元跳水，宏观环境偏暖，风险资产可适度加仓；黄金基本面强劲，维持偏多


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格处于2年历史100%分位，位于绝对高位，均值回归风险极高。
  - RSI(14) 62.61，中性偏强，未进入超买区。
  - 价格偏离MA120达9.50%，偏离MA250达12.00%，显示长期涨幅较大。
ONE_LINER: 虽处于上升趋势，但价格已处历史最高分位，高位风险显著，技术指标显示上行空间或受限，故转为中性观望。

### Risk Officer
```
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A（portfolio_summary 未提供该字段）
DRY_POWDER_CNY: ¥360
PNL_PCT: +10.27%
WORST_CASE_LOSS_PCT_AT_-20: ≈5.7%（NDQ.AX 若跌20%，约亏 ¥6,890 / 总资产 ¥120,304）
ONE_LINER: 子弹仅¥360已近枯竭，NDQ.AX浮盈+10.27%表现尚可，当前无加仓空间；若后续补弹药，建议该资产新增建仓不超过子弹的30%，整体仓位维持现有水平即可。
```

**风险要点补充**：

1. **流动性**：可投现金仅¥360，无WealthContextOfficer确认solvency buffer为strong，低现金视为流动性风险——无法应对突发支出或补仓机会。
2. **NDQ.AX仓位**：portfolio_summary未显式给出集中度数字，不自行估算。三只标的持仓分散度合理，无单资产极端集中迹象。
3. **历史模式**：Dreaming暂无记录，无法判断是否存在追涨情绪。建议CIO关注近7日是否有重复买入行为。
4. **浮盈状态**：三只标的均为正浮盈（+10%~+27%），无止损压力。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-24 > cutoff 2024-12-31)

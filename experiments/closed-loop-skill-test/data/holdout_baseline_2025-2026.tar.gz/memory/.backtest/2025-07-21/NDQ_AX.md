# Committee: NDQ.AX

**Date**: 2025-07-21
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: quant
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-21",
  "vix": 16.65,
  "tnx": 4.372,
  "usdcny": 7.1777,
  "audcny": 4.674
}
```

---

## CIO Memo (Round 3)

```
VERDICT: ACCUMULATE
CONFIDENCE: 0.60
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "价格回踩3%（接近MA20区域）→ 加仓 ¥10000"
    - "价格回踩7%（接近MA120支撑48.12附近）→ 加仓 ¥10000"

RISK_PLAN:
  stop_loss_trigger: "收盘价跌破MA120支撑（约48.12）同时10Y美债收益率维持4.3%以上 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: -4500
    recovery_estimate: "4-8个月（若利率见顶回落则更快，若利率持续高位可能更久）"

PERSONAL_NOTE:
  - 用户处于回测模式，无精确持仓数据，按中性假设处理；Quant看多但Macro仅中性，三方未完全一致，不宜激进。
  - 首笔试探仓仅占假设子弹约3-5%，总计划30000约占10-15%，留足弹药应对利率冲击下的潜在回调。
  - uptrend ACCUMULATE检查清单：(1)价格偏离MA120约8.63%，未超15%阈值，均值回归风险可控；(2)VIX 16.65处于温和区间，近期无从低位急升的焦虑信号；(3)但若30天后跌10%，叠加10Y收益率4.37%的利率压制和价格已处2年100%分位的极端估值，bullish逻辑将显著削弱——因此仅建小仓位而非满仓追涨。Quant bullish但RSI已近70、价格创历史新高，属于"趋势对但入场价不理想"的典型场景，用金字塔分批而非一次性建满是对的。
```


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率单月暴涨44%至4.37%，名义利率飙升压制风险资产估值
KEY_TAILWIND: 美元指数单月暴跌10%至97.85，叠加实际利率下行(TIP+4.1%)，黄金面临"双击"环境
ONE_LINER: 恐慌消退(VIX 16.65)但利率剧震，整体中性偏稳；黄金/商品具备货币端强支撑，风险资产受利率压制，维持现有仓位观望。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - RSI 69.58 接近超买阈值 70
  - 价格2年分位100%，处于历史绝对高点
  - MA20高于MA120 6.26%，趋势确认但偏离度8.63%未超15%
ONE_LINER: 上升趋势中价格创新高，RSI接近超买且分位100%，支撑位48.12（MA120），SIGNAL bullish但高位追涨需谨慎。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无具体数据，假设持仓中性，建议建仓比例上限35%以控制风险。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-21 > cutoff 2024-12-31)

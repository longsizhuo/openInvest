# Committee: NDQ.AX

**Date**: 2026-01-06
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.50)
**Dominant view**: macro
**Suggested allocation CNY**: 25000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-06",
  "vix": 14.75,
  "tnx": 4.179,
  "usdcny": 6.988,
  "audcny": 4.6911
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.50
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 25000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 25000
  add_levels:
    - "若价格回落至 MA120 附近（约 ¥55.17）→ 加 ¥30,000"
    - "若价格回落至 ¥53.5（前低支撑区域）→ 加 ¥30,000"

RISK_PLAN:
  stop_loss_trigger: "价格有效跌破 ¥53.0（前低下方 2%）且 MA120 下弯 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: -3750
    recovery_estimate: "2-4 个月（区间震荡格局下回踩后通常能回到区间中枢）"

PERSONAL_NOTE:
  - 回测模式无实际持仓快照，假设为中性持仓状态；当前价格处于 2 年分位 89% 高位区间，Quant 明确指出价格在 MA20（56.23）与 MA120（55.17）之间纠缠、缺乏趋势动能，"宜观望"并非空话。
  - 本次试探仓 ¥25,000 仅占常规子弹仓位的约 5%，属于"有仓位但不追高"的纪律性建仓；宏观点亮 risk_on 信号（弱美元 + 实际利率回落）提供了下方支撑的逻辑底，不值得零仓位等待。
  - 区间震荡格局的纪律：①价格离 120 日均线仅约 2% 偏离，均值回归压力尚可；②10Y 国债收益率月涨 14.4% 是 NDQ 类资产的实质估值杀手，若收益率继续攀升至 4.3%+ 应暂停加仓；③若 30 天后跌 10%，此 ACCUMULATE 理由（宏观 risk_on 底 + 区间下沿网格）仍然成立，因为网格策略本身就是为区间波动设计的，但需严格守住 ¥53 止损线。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: 2
KEY_HEADWIND: 10Y国债收益率月涨14.4%至4.18%，名义利率上行压力压制估值
KEY_TAILWIND: 美元指数月跌近5%叠加实际利率大幅回落，构成黄金/商品双击环境
ONE_LINER: 宏观中性偏多，弱美元+实际利率下行主导，可维持仓位；但名义利率快速攀升需警惕，勿激进加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格分位89%高位，面临历史阻力
  - RSI 43.90中性，无超买或超卖信号
  - 价格位于MA20(56.23)与MA120(55.17)之间，MA纠缠确认区间震荡
ONE_LINER: REGIME为range_bound，价格在区间上部（阻力约56.2-57），缺乏趋势动能，宜观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，无持仓快照）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，无法评估集中度与浮盈；假定中性持仓下建议单一资产占比≤30%，如实际集中度已超此限应降级至 concerned。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-06 > cutoff 2024-12-31)

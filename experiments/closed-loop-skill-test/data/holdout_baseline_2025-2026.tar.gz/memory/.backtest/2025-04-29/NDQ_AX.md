# Committee: NDQ.AX

**Date**: 2025-04-29
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-29",
  "vix": 24.17,
  "tnx": 4.173,
  "usdcny": 7.294,
  "audcny": 4.6888
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 当前无建仓动作，等待趋势反转信号
    - 若价格回踩至 40 附近且出现放量企稳 + VIX 回落至 18 以下，可考虑试探性建仓（子弹 5%）

RISK_PLAN:
  stop_loss_trigger: 若已持仓，跌破 40.00 同时 ^VIX > 28 → 果断减仓 50%；当前空仓无需止损
  what_if_wrong:
    worst_case_pnl_cny: 0（空仓状态无直接浮亏风险）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式下无实际持仓上下文，当前为中性状态，NDQ.AX 暂无明确建仓理由
  - 本次建议为零配置，100% 子弹保留待更优入场窗口
  - 美债收益率单月暴涨 42% 至 4.17%，金融条件急剧收紧——这对高估值科技股（NDQ 本质是纳斯达克 100）是最直接的估值杀手，绝不能在利率飙升期逆势重仓
  - 价格虽从 30 日低点反弹 9.94%，但成交量仅 0.58 倍（RVOL 极低），是教科书级的死猫跳；2 年分位 77% 说明即使跌了，估值仍不便宜，ATR spike 2.59 倍意味着波动率极端，贸然入场极易被套
  - **uptrend 怀疑清单不适用**（regime=downtrend），但需反向审视：MA250（45.28）构成上方强阻力，若反弹无法放量突破此线，后续大概率继续下探 40 支撑区域
  - 纪律建议：在 Macro risk_off + Quant downtrend + bearish 三重信号共振时，**耐心是最赚钱的仓位**；宁可错过左侧 5% 反弹，也不要在趋势确认反转前冒进


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 美债收益率单月暴涨42%至4.17%，金融条件急剧收紧，估值压力巨大
KEY_TAILWIND: 美元走弱(-2.49%)叠加实际利率下行(TIP+3.26%)，黄金获"双击"顺风
ONE_LINER: 利率飙升压制风险资产，VIX仍处24高位，整体偏向减仓/防守；但美元+实际利率组合对黄金类资产维持友好


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 2年分位77%偏高，下行趋势中高位估值下杀空间大
  - 价格44.59跌破MA250(45.28)仅-1.53%，ATR spike ratio 2.59倍波动率异常放大
  - 30日低点反弹9.94%但RVOL仅0.58x，低量反弹属典型死猫跳
ONE_LINER: downtrend中价格仍处高位分位77%，低量反弹至MA250下方确认弱势，阻力45.28(MA250)/48.01(MA120)，下方支撑看40关口附近

### Risk Officer
SIGNAL: ok  
STRENGTH: 2  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下持仓中性，风险可控，建议建仓比例上限为总资产的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-29 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-09-19
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-19",
  "vix": 15.45,
  "tnx": 4.139,
  "usdcny": 7.1129,
  "audcny": 4.7068
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "若价格自当前高位回落 5% → 加仓 ¥10,000"
    - "若价格回落 10%（接近 MA120 附近 ~¥49.76）→ 再加 ¥10,000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA120（¥49.76）且收盘确认 + VIX 突破 22 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -4500
    recovery_estimate: "2-4 个月（历史 uptrend 中回踩 MA120 后通常 6-8 周修复）"

PERSONAL_NOTE:
  - 回测模式无真实持仓快照，假设中性仓位（无极端集中度），按技术 + 宏观信号独立决策；Risk Officer 无 Dreaming 行为预警，单资产建议上限 ≤30%。
  - 本次 ¥30,000 试探仓约占中等组合（假设子弹 30-50 万）的 6%-10%，属于轻仓建底，符合"100% 现金默认 ACCUMULATE"原则。
  - **uptrend 怀疑清单自检**：①价格偏离 MA120 约 9.85%，未超 15% 阈值，均值回归压力暂可控；②VIX 处 15.45 低位且 Macro 明确标记"过度自满区间"——这不是回调买入信号，是情绪顶部警报；③若 30 天后跌 10%（价格回落至 ~49.5，恰好触及 MA120），本轮 ACCUMULATE 逻辑（Macro risk_on + 实际利率下行 + 美元弱势）仍然成立，只是买在了偏贵的位置。**结论：保留 ACCUMULATE 但严控首笔仅 ¥1 万，拒绝一次性建满**——价格处于 2 年 100% 分位绝对高位 + VIX 自满叠加，宁可少赚不追顶。
  - 操作纪律：本次是"播种"而非"收割"，核心子弹（70%+）等待 MA120 附近或 VIX 回升至 20+ 市场充分消化后再择机加码。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 8
SCORE: +4
KEY_HEADWIND: VIX跌至15.45已入过度自满区间，短期回调风险积聚
KEY_TAILWIND: DXY月跌12%叠加实际利率下行，黄金/商品迎货币双击
ONE_LINER: 美元崩跌+实际利率下行为主旋律，风险偏好强劲，组合偏向维持偏进攻配置，但需警惕VIX极低位后的情绪反转


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格处于2年历史100%分位，绝对高位
  - RSI(14) 67.14，接近但未进入超买区
  - 价格偏离MA120约9.85%，均值回归风险暂未触发
ONE_LINER: REGIME为上升趋势，但价格已创两年新高，技术指标显示上行动能或减弱，信号中性，关注MA120 (49.76)支撑及前高阻力。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓快照，假设中性仓位；无 Dreaming 行为模式预警，建议实盘上线后按实际集中度复评，单资产建仓上限建议 ≤30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-19 > cutoff 2024-12-31)

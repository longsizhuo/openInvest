# Committee: NDQ.AX

**Date**: 2025-08-11
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.75)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-11",
  "vix": 16.25,
  "tnx": 4.273,
  "usdcny": 7.181,
  "audcny": 4.6802
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.75
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "if price drops 3% → add ¥20000"
    - "if price drops 6% → add ¥20000"

RISK_PLAN:
  stop_loss_trigger: "跌破 MA120 at 48.34 同时 ^VIX > 20 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6 个月"

PERSONAL_NOTE:
  - 用户当前持仓中性（回测模式假设），无极端集中度。
  - 本次建议在子弹中占比约10%（基于50000 CNY和假设子弹规模）。
  - 心理/操作纪律建议：分批建仓避免追高，设定止损纪律以管理下行风险。
  - Uptrend中ACCUMULATE检查：(1) 价格离120日均线偏离10.36%，低于15%，均值回归风险中等；(2) VIX近期腰斩处于低位，未见从低位上升迹象，市场情绪risk-on；(3) 如果30天后跌10%，基于上升趋势和risk-on宏观环境，ACCUMULATE理由可能仍成立，但需警惕名义利率反弹风险。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: TNX飙升25%至4.27%，名义利率上行压制长端估值
KEY_TAILWIND: DXY暴跌10%至98.5，美元大幅走弱是风险资产与黄金的强支撑
ONE_LINER: VIX腰斩+美元崩跌构成risk-on组合，维持偏积极持仓，但需警惕名义利率反弹的尾部风险


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位100%，处于绝对高位
  - RSI 60.94，中性偏强未超买
  - 价格离MA120偏离度10.36%，均值回归风险中等
ONE_LINER: 上升趋势中价格创2年新高，RSI健康但分位极端，支撑MA120在48.34，趋势延续但需警惕高位风险，信号看多。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，基于中性假设，风险评估有限。建议对单一资产（如NDQ.AX）的建仓比例上限不超过总资产的35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-11 > cutoff 2024-12-31)

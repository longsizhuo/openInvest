# Committee: NDQ.AX

**Date**: 2025-01-23
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.70)
**Dominant view**: quant
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-23",
  "vix": 15.02,
  "tnx": 4.638,
  "usdcny": 7.2712,
  "audcny": 4.5612
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.7
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - if price drops 3% from current (approx 52.4) → add ¥15000
    - if price drops 6% from current (approx 50.9) → add ¥20000

RISK_PLAN:
  stop_loss_trigger: 跌破 MA120 支撑位 45.72 同时 VIX 升破 20 → 减仓 50%
  what_if_wrong:
    worst_case_pnl_cny: -7500 (假设初始建仓15000，最大回撤约50%)
    recovery_estimate: 4-8个月

PERSONAL_NOTE:
  - 回测模式下假设用户持仓中性，无集中度压力，当前为建立初始头寸。
  - 本次首次试探性建仓15000元，约占假设子弹总额的5%，旨在捕捉趋势，控制风险敞口。
  - 操作纪律：分批建仓计划必须严格执行，不追高。当前已执行uptrend中ACCUMULATE怀疑清单检查：1）价格离MA120偏离11.93%<15%，均值回归风险可控；2）VIX从27高位已跌至15，近期并非从低位上升；3）若30天后跌10%，核心理由“上升趋势中的回调”仍可能成立，但需观察MA120支撑有效性。因此，以分批方式入场，留足子弹等待可能的回踩。


---

## Macro Strategist (shared)

**宏观评估**

**分析要点：**
- TNX 4.64%，近月从~4.80%小幅回落但仍处高位，利率环境偏紧
- VIX 从27→15暴跌45%，市场进入低波舒适区，警惕过度自满
- DXY 108+高位运行，美元强势压制新兴市场与商品
- TIP月跌4%，实际利率上行，对黄金形成明确压制

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -2
KEY_HEADWIND: 美元指数108+强势叠加实际利率上行，黄金/商品面临货币因素双杀
KEY_TAILWIND: VIX跌至15，市场恐慌情绪已大幅释放，短期风险偏好尚可
ONE_LINER: 利率高企+美元强势环境下偏防守，建议减仓黄金/商品敞口，维持权益中性
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 5
KEY_DATA:
  - 价格2年分位99%，极端高位，均值回归风险存在
  - RSI 61.36，中性偏高但未超买
  - 价格离MA120偏离度11.93%（<15%），MA20-MA120 spread 10.21%未显示收窄，趋势持续
ONE_LINER: 上升趋势延续但价格处于2年高位，RSI中性支撑看涨，信号与REGIME一致但强度受限，支撑MA120 45.72。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无持仓数据，假设中性持仓无极端集中度，风险维度无触发信号，建议回测建仓占比≤30%以模拟真实组合约束。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-23 > cutoff 2024-12-31)

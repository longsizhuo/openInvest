# Committee: NDQ.AX

**Date**: 2025-06-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-09",
  "vix": 17.16,
  "tnx": 4.482,
  "usdcny": 7.1886,
  "audcny": 4.6725
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无操作

RISK_PLAN:
  stop_loss_trigger: 若价格有效跌破当前区间下沿（需结合具体K线判断）且^VIX > 22，考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: 按当前持仓及Risk Officer估算，约-6%的总持仓浮亏。
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 当前持仓假设为中性，无极端集中风险，但资产价格两年分位88%已处于偏高区域。
  - 本次建议维持现状，不占用新的子弹。
  - 技术面显示MA20与MA120价差仅1%，市场处于无趋势的区间震荡中（Quant判断为range_bound），此时加仓的胜率较低。宏观环境股债压力对冲，也未给出明确方向。纪律上应耐心等待价格突破区间或RSI出现显著超买/超卖信号。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率单月暴涨54%，债券市场压力骤增，挤压风险资产估值空间
KEY_TAILWIND: 美元指数单月下挫8.4%，TIP上涨4%，实际利率下行构成黄金/商品双击环境
ONE_LINER: 债市冲击与美元走弱形成对冲，短期维持现有仓位，黄金/商品类可适度加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格两年分位88%，估值偏高
  - RSI 58.72，中性区间
  - MA20与MA120价差仅1%，趋势纠缠
ONE_LINER: 区间震荡中价格高位但RSI未超买，MA纠缠无突破，技术面无明确方向，中性观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: 30%
DRY_POWDER_CNY: N/A
PNL_PCT: 0%
WORST_CASE_LOSS_PCT_AT_-20: 6%
ONE_LINER: 持仓假设中性，无极端集中风险。建议若加仓，单一资产占比上限维持在35%以内。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-09 > cutoff 2024-12-31)

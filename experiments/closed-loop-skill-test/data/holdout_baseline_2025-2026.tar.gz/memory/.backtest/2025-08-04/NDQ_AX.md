# Committee: NDQ.AX

**Date**: 2025-08-04
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 10000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-04",
  "vix": 17.52,
  "tnx": 4.2,
  "usdcny": 7.2116,
  "audcny": 4.6666
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.7
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 10000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 3000
  add_levels:
    - "if price drops 5% from current level → add ¥3000"
    - "if price drops 10% from current level → add ¥4000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 ¥45.00（约-15%）同时 VIX > 22 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -2000
    recovery_estimate: "3-6 个月"

PERSONAL_NOTE:
  - 当前回测模式假设持仓中性，无具体仓位数据，但鉴于信号中性，建立试探仓以管理现金机会成本。
  - 本次建仓金额 ¥10,000 占预估子弹的约 5%，旨在小幅参与趋势而非全仓押注。
  - uptrend 中 ACCUMULATE 检查：1) 价格离 120 日均线偏离 7.7%（<15%），均值回归风险可控；2) VIX 17.5 且月跌 35%，未从低位上升，市场焦虑度低；3) 若 30 天后跌 10%，ACCUMULATE 理由（中性趋势 + 宏观偏乐观）仍部分成立，因利率上行风险已被美元走弱缓冲，故维持分批策略。
  - 操作纪律：严格遵循金字塔加仓计划，避免情绪化追高，止损线设定后需纪律执行。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙升25.75%至4.20%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数跌至98.78（MoM -10%）+ 实际利率下行（TIP +7.28%），为黄金/大宗商品提供双击环境
ONE_LINER: VIX回落至17.5显示恐慌消退，但利率上行与美元走弱的博弈使整体中性偏乐观，维持为主、不追涨
```

**核心逻辑拆解：**

| 维度 | 信号 | 解读 |
|------|------|------|
| 恐慌情绪 | ✅ VIX 17.5（-35% MoM） | 恐惧大幅消退，未到贪婪区 |
| 利率环境 | ⚠️ TNX 4.20%（+26% MoM） | 债券抛售明显，可能反映财政/通胀忧虑 |
| 美元 | ✅ DXY 98.78（-10% MoM） | 弱美元周期，利好大宗商品与EM |
| 实际利率 | ✅ TIP +7.28% | 实际利率下降，黄金基本面支撑强 |

**关键矛盾：** 利率上行 vs 美元走弱——市场在定价"通胀粘性+财政扩张"还是"联储即将转鸽"，将决定下一阶段方向。当前两者暂时共存，但不可持续，需密切跟踪。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格处于2年历史98%分位，极端高位，估值风险积累
  - RSI 52.44 中性，日线动量平稳，未超买
  - 趋势结构：MA20(52.04) 高于 MA120(48.27) +7.8%，偏离度7.7%
ONE_LINER: 虽处上升趋势，但价格已至2年历史高位98%分位，RSI中性未提供新高动力，上行空间或受估值压制，转为中性观察。

### Risk Officer
SIGNAL: ok  
STRENGTH: 0  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式假设持仓中性，无具体风险数据；建议实际建仓时单一资产占比不超过35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-04 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.68)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-09",
  "vix": 33.62,
  "tnx": 4.4,
  "usdcny": 7.3388,
  "audcny": 4.3697
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.68
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若 Macro SIGNAL 转回 neutral 且价格守住近期低点（约 ¥38-39 区域），可试探性建 5% 仓位"
    - "若 VIX 回落至 22 以下 + RSI 站上 40，再加第二笔 10%"

RISK_PLAN:
  stop_loss_trigger: "若价格跌破近期 30 天低点且 ^VIX 持续 > 35 → 已有仓位考虑减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: 0（回测模式无精确持仓数据，按中性持仓假设，暂无额外加仓敞口）
    recovery_estimate: "若下跌延续，基于当前 -15.91% 的 30 天跌幅，预计 2-4 个月触底后缓慢修复"

PERSONAL_NOTE:
  - 回测模式下无精确持仓与现金流数据，按中性持仓假设裁决；当前未持有 NDQ.AX 敞口，亦未有强烈的建仓信号。
  - 本次建议零操作，100% 子弹保留，等待宏观信号改善（10Y 收益率企稳、VIX 回落至 25 以下）再考虑分批介入。
  - 心理纪律：当前环境是"利率飙升 + VIX 突破 33"的典型恐慌组合——RSI 31.86 看似接近超卖，但在宏观 risk_off 强度 7/10 的背景下，超卖可以更超卖。宁可少赚第一个 5% 反弹，也不要接飞刀后被套 15%。Quant 的中性信号本身就在说"没有底部确认"，耐心等待趋势拐点比抄底更安全。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y收益率月涨56%叠加VIX突破33，流动性收紧+恐慌情绪共振压制风险资产
KEY_TAILWIND: 美元走弱(-1.6%)且实际利率下行(TIP+2.48%)，为黄金/商品提供货币双击支撑
ONE_LINER: 利率飙升+高波动=典型risk_off，权益类倾向减仓；但黄金/商品的货币基本面转好，可对冲持有
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - RSI 31.86 接近超卖但未极端，2年分位59%处于中等水平
  - 价格低于MA250（-8.10%）且成交量增加（RVOL 1.52x），显示下跌压力
  - MA20低于MA120 -6.40%，确认下跌趋势，但近期30天跌幅-15.91%后小幅反弹
ONE_LINER: 在下跌趋势中，RSI超卖但价格分位中等，信号中性；阻力位MA250（45.11），支撑需关注近期低点。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，基于中性持仓假设，风险信号不显著，建议维持配置，避免单资产过度集中。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-09 > cutoff 2024-12-31)

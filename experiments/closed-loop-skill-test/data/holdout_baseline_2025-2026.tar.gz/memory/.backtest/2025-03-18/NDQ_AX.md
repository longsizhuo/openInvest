# Committee: NDQ.AX

**Date**: 2025-03-18
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-18",
  "vix": 21.7,
  "tnx": 4.281,
  "usdcny": 7.2327,
  "audcny": 4.6152
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.5
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 价格未能收复并站稳 MA120 (47.95) 且 ^VIX 突破 22 → 减仓 30%
  what_if_wrong:
    worst_case_pnl_cny: -100000 (基于假设持仓50万，回撤20%的极端情况)
    recovery_estimate: 6-12个月

PERSONAL_NOTE:
  - 用户处于回测模式，持仓上下文未知，假设为中性。
  - 本次建议仓位占比为0%，不新增任何敞口。
  - 在宏观利率上行与技术面矛盾（高位超卖）的背景下，保持耐心是首要纪律。等待价格明确站回MA120或宏观风向转变的信号，而非在不确定中押注方向。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10年美债收益率单月飙升超50%至4.28%，利率预期剧烈重新定价，叠加美元走强，全面压制风险资产估值。
KEY_TAILWIND: TIP月涨+0.13%，实际利率小幅回落，为黄金提供微弱货币端支撑。
ONE_LINER: 收益率暴力上行+美元走强构成宏观双杀，风险偏好收缩，整体偏向减仓防御、降低久期敞口。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位82%高位，但RSI 22.73深度超卖
  - 价格跌破MA120 (-5.03%)，短期趋势偏弱
  - MA20/MA120接近但未形成明确趋势，符合震荡定义
ONE_LINER: 处于range_bound震荡，价格高位（82%分位）与RSI深度超卖（22.73）形成矛盾，缺乏明确方向，维持中性，需观察能否收复MA120 (47.95)。

### Risk Officer
SIGNAL: high_risk
STRENGTH: 10
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下持仓数据缺失，无法评估真实风险，建议减仓50%以上以应对极端波动。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-18 > cutoff 2024-12-31)

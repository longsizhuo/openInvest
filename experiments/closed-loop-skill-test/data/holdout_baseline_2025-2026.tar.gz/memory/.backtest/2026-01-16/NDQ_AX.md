# Committee: NDQ.AX

**Date**: 2026-01-16
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.58)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-16",
  "vix": 15.86,
  "tnx": 4.231,
  "usdcny": 6.966,
  "audcny": 4.6682
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.58
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回落至 MA120（55.44）附近且 RSI < 40 → 可试探建仓 3-5% 子弹"
    - "若价格跌破 54.0（2年分位约 60%）且 Macro risk_on 不变 → 加仓至 10%"

RISK_PLAN:
  stop_loss_trigger: "若已建仓：价格跌破 54.0 且 MA20 死叉 MA120 同时 VIX 回升 > 20 → 止损出场"
  what_if_wrong:
    worst_case_pnl_cny: 0（当前无持仓，不承担直接损失）
    recovery_estimate: "不适用；若踏空后需追入，需等待下一次 range-bound 回踩支撑"

PERSONAL_NOTE:
  - 当前回测模式无真实持仓数据，假设中性仓位状态；NDQ.AX 价格处于 2 年分位 92% 的极端高位，Quant 定性为 range-bound bearish，在区间顶部追涨风险收益比极差。
  - Macro risk_on（VIX 暴跌、美元走弱、实际利率下行）与 Quant bearish 形成显著分歧——流动性改善可以延缓回调但无法消除估值过高的事实；名义利率单月飙升 7% 若持续，对 NDQ 这类长久期科技资产的估值压制不可忽视。Risk Officer 信号极弱（strength=2），未倒向任何一方，按裁决原则保留 Quant 方向判断。
  - 纪律建议：92% 分位 + range-bound = 不追高是第一原则。耐心等待价格回踩 MA120（55.44）甚至更低再考虑建仓；Macro 的流动性顺风意味着即使回调幅度也可能有限，但"不亏钱"优先于"不踏空"。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: 3
KEY_HEADWIND: 10Y名义利率单月飙升近7%，若持续将压制长久期资产估值
KEY_TAILWIND: 美元指数跌破100且实际利率大幅回落，流动性环境显著宽松化
ONE_LINER: VIX暴跌+美元走弱+实际利率下行=风险偏好回暖，偏加仓方向，但需警惕利率反弹节奏。
```

**简评：**
- 🟢 **VIX 15.86（-30%）**：恐慌情绪大幅消退，已脱离危险区
- 🟢 **DXY 99.39（-5%）**：美元显著走弱，对全球风险资产/黄金构成双击
- 🟢 **TIP +12%**：实际利率急剧下降，流动性最敏感资产（黄金/科技）受益
- 🟡 **TNX 4.23%（+7%）**：名义利率上行是唯一隐忧，或反映增长预期修复而非紧缩

**宏观定性：** 软着陆叙事主导，流动性边际改善，整体环境偏暖。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位92%，历史高位
  - RSI(14) 51.37，中性区域
  - MA20=56.10与MA120=55.44纠缠，趋势模糊
ONE_LINER: 在range_bound市场中，价格处于92%分位高位，支撑MA120 55.44，阻力56.37，SIGNAL bearish。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，无持仓数据）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A（无法计算，缺集中度）
ONE_LINER: 回测模式无持仓上下文，假设中性持仓无极端集中；无历史行为模式可供参考，建议回测时保持单资产占比≤30%，严控加仓节奏避免情绪化追涨。
```

**补充说明**：
- 本次为历史回测，无法获取真实 portfolio_summary，所有量化指标标记 N/A
- Dreaming 无 NDQ.AX 相关行为记录，无法评估是否存在情绪化追涨模式
- Risk Officer 视角受限于数据可用性，建议 CIO 结合 Quant/Macro 信号综合决策
- 若回测中需模拟真实持仓，需提供具体持仓数量与成本基础以供完整评估


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-16 > cutoff 2024-12-31)

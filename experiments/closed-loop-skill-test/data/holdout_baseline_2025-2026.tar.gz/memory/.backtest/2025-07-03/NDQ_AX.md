# Committee: NDQ.AX

**Date**: 2025-07-03
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 8000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-03",
  "vix": 16.38,
  "tnx": 4.348,
  "usdcny": 7.1649,
  "audcny": 4.7169
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 8000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 3000
  add_levels:
    - "价格回落至 MA120 附近（约 ¥48.0）→ 加仓 ¥3000"
    - "价格跌破 MA120 达 ¥46.5 且 RSI < 45 → 加仓 ¥2000 完成建仓"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 收盘价跌破 ¥46.0（MA120 下方约 4%）且 VIX 升破 22 → 全部止损离场"
  what_if_wrong:
    worst_case_pnl_cny: -1200
    recovery_estimate: "2-4 个月（range_bound 区间内震荡修复）"

PERSONAL_NOTE:
  - 回测模式下无精确持仓数据，假设为中性持仓、子弹充裕；当前 NDQ.AX 价格处于 2 年分位 96%（估值偏贵），Quant 定性为 range_bound 区间震荡而非趋势行情，高位追入风险不低，因此仅建 3000 元试探仓，保留 60%+ 子弹等待区间下沿。
  - 本次 8000 元建仓金额占子弹比例极小（<10%），属于"有仓位但不押注"的纪律性布局；若价格未回落至 MA120 区域则不追加，避免在 96 分位处重仓。
  - 心理纪律：range_bound 阶段最常见的错误是"等突破再追"——分批小仓进、严格止损出，不猜方向、只控仓位。宏观环境偏友善（美元弱势 + 实际利率下行）提供了下档缓冲，但 10 年期利率 4.35% 高位仍是估值天花板，不宜重仓。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: 2
KEY_HEADWIND: 10Y收益率维持4.35%高位，高利率环境持续压制风险资产估值。
KEY_TAILWIND: DXY跌至97（月跌8.6%）+实际利率下行（TIP月涨3.6%），黄金遭遇"双击"顺风。
ONE_LINER: VIX低位+美元弱势+实际利率走低，宏观环境偏友善；高收益率是唯一紧箍咒，整体偏向维持偏乐观配置。
```

**要点补充：**

| 维度 | 判断 |
|------|------|
| **利率** | TNX 4.35% 高位盘整，近期从4.38小幅回落，未失控上行 |
| **恐慌情绪** | VIX 16.4，连续下台阶（10日前还在20+），市场情绪明显改善 |
| **货币因素（黄金关键）** | DXY 月跌8.6%为罕见幅度 + TIP涨3.6%确认实际利率下行 → **黄金双击格局确立** |
| **通胀/衰退** | 无新数据冲击，市场定价"软着陆"叙事中 |

> ⚠️ 本次评估DXY跌幅异常大（单月-8.6%），若为数据跳变需核实；若属实则为近年罕见的美元弱势窗口，对商品/黄金构成强支撑。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位96%，估值偏高
  - RSI 66.68中性偏高，未超买
  - MA20与MA120差3.73%，趋势纠缠，区间震荡
ONE_LINER: range_bound下价格高位震荡，RSI未超买但估值高，中性信号，支撑MA120 48.01阻力前高。

### Risk Officer
SIGNAL: ok
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，无法量化集中度与流动性风险。建议建仓比例上限和技术止损点需严格依据回测策略参数设定，当前模式建议遵循技术面与宏观信号，并严格执行止损纪律。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-03 > cutoff 2024-12-31)

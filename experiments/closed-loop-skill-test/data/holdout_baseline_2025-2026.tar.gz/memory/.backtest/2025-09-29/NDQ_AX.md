# Committee: NDQ.AX

**Date**: 2025-09-29
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-29",
  "vix": 16.12,
  "tnx": 4.141,
  "usdcny": 7.1328,
  "audcny": 4.6734
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - if price drops 5% from current level → add ¥5000
    - if price drops 10% (接近MA120 50.33) → add ¥5000

RISK_PLAN:
  stop_loss_trigger: 价格跌破MA120（50.33）同时VIX突破22 → 减仓50%
  what_if_wrong:
    worst_case_pnl_cny: -3000
    recovery_estimate: 2-4个月（基于均值回归，uptrend结构支撑）

PERSONAL_NOTE:
  - 回测模式下假设持仓中性，无极端集中度风险；NDQ.AX价格处于2年历史100%分位，估值极端偏高，但Macro维持risk_on信号（美元暴跌+实际利率下行）提供基本面支撑
  - 本次建议金额在常规子弹中占比约3%-5%（试探仓），属于极保守策略；Quant建议观望等待回调有其道理（RSI 66、偏离MA120约10%），但Macro信号不足以支撑零仓位等待
  - **Uptrend怀疑清单检查**：(1) 价格偏离MA120约9.6%，未突破15%阈值但仍需警惕；(2) VIX从高位回落37%至16附近，暂无急升信号；(3) 若30天后跌10%，以当前100%历史分位看仍有均值回归逻辑支撑解套，ACCUMULATE理由部分成立
  - 操作纪律：宁可小仓试探也不要空仓追涨，5000元首笔+5%/10%两档金字塔加仓，保留大部分子弹等待更好时机


---

## Macro Strategist (shared)

**宏观快照已收到，综合判断如下：**

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 名义利率小幅上行(TNX 4.14%, MoM+1.57%)，若加速可能压制估值。
KEY_TAILWIND: 美元暴跌(DXY -12%) + 实际利率大幅下行(TIP +13%)，为风险资产与商品提供强力双击。
ONE_LINER: VIX跌至16恐慌消退，美元走弱+实际利率下行构成宽松组合，宏观环境偏健康，整体倾向维持偏加仓。
```

**补充视角：**
- **VIX -37%** 从高位急速回落，反映地缘/政策恐慌已大幅定价，当前接近complacency边缘但尚未极端。
- **DXY跌破98**是本月最显著信号——若持续走弱，对黄金/商品/新兴市场资产形成系统性利好。
- **名义利率微升但实际利率下行**，说明市场定价的是"增长温和+通胀预期抬升"而非纯紧缩，属soft-landing叙事。

**风险监控点：** 若VIX重新站上20或DXY快速反弹回100+，risk_on判断需即时修正。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格处于2年历史100%分位，估值极端偏高
  - RSI 66.08，接近超买区，上行动能受限
  - 价格偏离MA120约9.6%，存在均值回归压力
ONE_LINER: 尽管REGIME为uptrend，但价格创历史新高且估值极端，RSI偏高暗示上行动能衰减，建议观望等待回调，支撑位参考MA20（53.87）及MA120（50.33）。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无实际持仓数据，无法评估集中度与现金流风险。假设持仓中性，建议在回测中持续关注技术面。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-29 > cutoff 2024-12-31)

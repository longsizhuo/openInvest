# Committee: NDQ.AX

**Date**: 2025-09-01
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-01",
  "vix": 15.36,
  "tnx": 4.227,
  "usdcny": 7.1304,
  "audcny": 4.6654
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 15000
  add_levels:
    - "价格从入场点下跌3% → 加仓¥15000"
    - "价格下跌5% → 加仓¥15000"
    - "价格下跌8% → 加仓¥25000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破入场价7%同时^VIX升破22 → 减仓50%（清空高位加仓部分）"
  what_if_wrong:
    worst_case_pnl_cny: 4000
    recovery_estimate: "2-4个月（若宏观risk_on趋势延续）"

PERSONAL_NOTE:
  - 回测模式下假设中性持仓，无极端集中度；本轮建仓约占子弹4%，仓位极轻，为试探性布局
  - 95%高位分位是核心警告：当前价格高于过去2年95%的交易日，追涨空间极其有限；Quant RSI仅46.41、信号强度为0，毫无上涨动能背书
  - 美债收益率飙升15%至4.23%对NDQ科技股构成直接估值压制，此为本次最大逆风，也是grid而非一次性满仓的根本原因
  - uptrend检查清单：①价格偏离MA120仅7.53%，未触发>15%均值回归警报，尚可接受；②VIX=15处于低位，未显示焦虑信号，但警惕低位追高陷阱；③若30天后跌10%，Macro risk_on逻辑仍成立但Quant无支撑，grid策略下可补仓摊低成本——故维持ACCUMULATE而非HOLD
  - 操作纪律：严守grid纪律，绝不一次性加满；若价格持续横盘在高位震荡超3周且RSI跌破40，暂停加仓等待方向明确


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: 3

KEY_HEADWIND: 10年期美债收益率飙升15%至4.23%，名义利率上行压制估值敏感型资产
KEY_TAILWIND: 美元指数月跌12%+TIP月涨13%（实际利率骤降），黄金商品迎"双击"窗口

ONE_LINER: VIX暴跌至15附近显示恐慌消退，美元走弱+实际利率下行构成黄金/商品强利好，宏观环境偏暖，可适度加仓风险资产及黄金。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 0
KEY_DATA:
  - 价格处于2年分位95%高位，上涨空间受限
  - RSI(14)=46.41，中性偏弱，无上涨动能信号
  - 价格偏离MA120仅7.53%，均线趋势仍在但强度一般
ONE_LINER: 虽处上升趋势，但极高分位与中性RSI构成矛盾，缺乏追涨动能，短期以高位震荡为主。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性持仓，建议任何新建仓占比不超过总资产的20%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-01 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-08
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.48)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-08",
  "vix": 52.33,
  "tnx": 4.262,
  "usdcny": 7.3081,
  "audcny": 4.3827
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.48
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 不执行任何加仓
    - 待 VIX 回落至 25 以下且 MA120 拐头向上后再评估分批入场

RISK_PLAN:
  stop_loss_trigger: 若已持有 NDQ.AX 仓位，VIX 维持 >40 超过 5 个交易日且价格跌破 MA250（约 ¥40.55 区域）→ 减仓 50%
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式，无精确持仓金额）
    recovery_estimate: 在当前 downtrend + 利率冲击双杀环境下，若继续下行 10-15%，预计解套周期 6-12 个月

PERSONAL_NOTE:
  - 回测模式下假设持仓中性，NDQ.AX 当前处于明确 downtrend（价格低于 MA120/MA250 偏差 -5.06%），且 Macro 给出强度 8 的强 risk_off 信号（VIX=52 极端恐慌 + 10Y 收益率月涨 46% 利率冲击），三方信号无一支持加仓
  - 本次建议零仓位变动，子弹 100% 保留；在 VIX=52 的极端恐慌环境下，"不作为"本身就是对风险的尊重
  - 心理纪律：RSI 35.93 虽接近超卖区，但在 downtrend + 利率冲击的双杀格局下，超卖可以更超卖——切勿因"觉得便宜"就抄底，等 Quant SIGNAL 从 neutral 转为 bullish 且 VIX 降至 25 以下才是真正的入场窗口；2 年价格分位 66% 说明当前估值并不便宜，下行空间可能被低估


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 8
SCORE: -4
KEY_HEADWIND: VIX飙升至52恐慌级别+10Y收益率月涨46%，利率冲击与极端恐慌双杀风险资产
KEY_TAILWIND: 美元走弱+实际利率下行，为黄金提供双击支撑
ONE_LINER: 极端risk_off环境，全面减仓风险资产，黄金/避险类除外可维持或加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 35.93 接近超卖，但下降趋势未改
  - 价格低于 MA120 和 MA250，偏差 -5.06%，趋势压力持续
  - 2年价格分位 66%，估值相对高位，限制反弹空间
ONE_LINER: 下降趋势中 RSI 超卖或支撑于40.55，但阻力在45.11（MA250），SIGNAL 为 neutral 因趋势与估值矛盾。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A (回测模式，无精确持仓)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下假设持仓中性，无集中度风险信号。建议在回测中保持平衡，建仓比例不超过资产总值的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-08 > cutoff 2024-12-31)

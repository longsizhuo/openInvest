# Committee: GC=F

**Date**: 2025-04-08
**Symbol**: GC=F
**Verdict**: ACCUMULATE (confidence 0.45)
**Dominant view**: macro
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-08",
  "vix": 52.33,
  "tnx": 4.262,
  "usdcny": 7.3081,
  "audcny": 4.3827
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.45
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 1500
  add_levels:
    - "价格回踩 MA120 (¥2787) 且 VIX 回落至 < 45 → 加 ¥2000"
    - "VIX 降至 < 35 且价格站稳 MA120 上方 3% → 加 ¥1500"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA120 (¥2787) 同时 VIX 持续 > 50 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -500
    recovery_estimate: "3-6 个月（流动性冲击通常快速出清后反弹）"

PERSONAL_NOTE:
  - 回测模式无持仓快照，按中性持仓处理；VIX=52 处于危机级别（2020年3月水平），Macro 强 risk_off，Quant 中性偏弱，绝不重仓追高。
  - 本次仅投 ¥5000（子弹最低试探仓），因 0% 仓位不允许 HOLD，但 VIX=52 不支持大额建仓。
  - **uptrend 三检查**：①价格离 MA120 偏离 6.48%<15%，均值回归风险可控；②VIX 从 18 飙升至 52，市场已处于极度恐慌而非回调买入信号，这是减缓建仓的核心原因；③若 30 天后跌 10%，黄金的避险逻辑在流动性冲击平息后仍成立（TIP 上行+实际利率下行支撑），但短期可能被抛售换流动性，因此仓位极轻。
  - 核心逻辑：流动性冲击下黄金可能"先被卖后被买"——这是微量试探仓的理论基础，而非追多。


---

## Macro Strategist (shared)

**分析要点：**

- **VIX 52.33** — 近10日从18→52，恐慌情绪呈抛物线式飙升，已达危机级别（类比2020年3月疫情初期）
- **TNX 4.26%** — 月涨+45.91%，债券市场剧烈抛售，金融条件急剧收紧
- **DXY 102.96** — 美元小幅走弱（-1.80%），但非主要矛盾
- **TIP +1.82%** — 实际利率下行，对黄金形成货币层面支撑

VIX的飙升轨迹（18→30→45→52）显示恐慌正在自我强化，这是一场流动性冲击而非单纯的基本面恶化。

---

```
SIGNAL: risk_off
STRENGTH: 9
SCORE: -4
KEY_HEADWIND: VIX飙升至52危机级别+国债收益率月涨46%，流动性冲击引发全面去杠杆
KEY_TAILWIND: 美元走弱+实际利率下行构成黄金双击，但极端恐慌下黄金可能先被抛售换流动性
ONE_LINER: 全面风险规避，减仓为主；黄金持有者需警惕流动性冲击下的短期抛压
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 3  
KEY_DATA:  
  - 价格2年分位97%，历史高位，均值回归风险高  
  - RSI(14)=45.28低于50，动能偏弱且非超买区  
  - 价格离MA120偏离6.48%<15%，但成交量低(RVOL=0.35x)趋势持续性存疑  
ONE_LINER: REGIME为上升趋势，但价格高位、RSI中性偏弱且近期回调，SIGNAL neutral，支撑看MA120(2787.63)

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式无持仓快照）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式假设持仓中性，无极端集中度；黄金本身波动率适中，单次建仓建议不超总资产 15-20%，严格止损 -8%。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-08 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-02-18
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 10000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-18",
  "vix": 19.62,
  "tnx": 4.079,
  "usdcny": 6.908,
  "audcny": 4.8927
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 10000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - “if price drops 5% from current level → add ¥3000”
    - “if price drops 10% from current level → add ¥2000”

RISK_PLAN:
  stop_loss_trigger: “跌破 MA120 (约下跌4.5%) 同时 ^VIX > 22 → 减仓 50%”
  what_if_wrong:
    worst_case_pnl_cny: -1500
    recovery_estimate: “3-6个月，若反弹不破下降趋势线则需更长时间”

PERSONAL_NOTE:
  - 当前为回测模式，无精确持仓数据，假设用户持中性仓位，无极端集中风险。
  - 本次建仓金额10000 CNY占模拟子弹比例较低（5%），旨在建立小试探仓并设置下跌加仓网格。
  - 技术面（下降趋势）与宏观面（信号矛盾）均不支持激进加仓，采用金字塔建仓法，纪律性等待更明确的反弹或趋势反转信号。


---

## Macro Strategist (shared)

**分析依据：**
- TNX +16.54% 名义利率飙升 → 但 DXY -5.26% + TIP +10.27% 实际利率下降 → 矛盾信号
- VIX 19.62 仍居中性，MoM -11.86% 恐慌消退
- 美元走弱 + 实际利率下行 = 黄金/商品双击环境，但名义利率上行压制成长股

---

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y收益率月涨16%+，名义利率飙升压制风险资产估值
KEY_TAILWIND: 美元月跌5%+实际利率下行，黄金/商品迎货币双击窗口
ONE_LINER: 宏观信号矛盾（名义强实际弱），VIX回落后市场暂稳，整体倾向维持观望，黄金类资产环境偏有利
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - RSI 32.94 超卖区，短期反弹可能但趋势未变
  - 价格2年分位71%偏高，估值压力存在
  - MA20低于MA120 -4.08%，下降趋势确认，价格略低于MA250
ONE_LINER: 下降趋势中价格分位高但RSI超卖，缺乏明确方向突破，维持neutral等待更清晰信号。

### Risk Officer
SIGNAL: ok  
STRENGTH: 1  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式无持仓数据，假设中性持仓，建议NDQ.AX建仓比例上限不超过总资产的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-18 > cutoff 2024-12-31)

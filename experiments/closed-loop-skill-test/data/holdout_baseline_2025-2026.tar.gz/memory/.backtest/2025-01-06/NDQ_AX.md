# Committee: NDQ.AX

**Date**: 2025-01-06
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-06",
  "vix": 16.04,
  "tnx": 4.618,
  "usdcny": 7.3196,
  "audcny": 4.5526
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - “当前不建议加仓，等待宏观风险缓和信号”

RISK_PLAN:
  stop_loss_trigger: “价格跌破 MA120 支撑（约 44.92）且 ^VIX > 20 → 减仓 20%”
  what_if_wrong:
    worst_case_pnl_cny: -20000
    recovery_estimate: “3-6 个月”

PERSONAL_NOTE:
  - 回测模式假设持仓中性，无极端集中度，但真实仓位未知。
  - 本次建议零新增投入，完全保留子弹。
  - 宏观逆风（利率飙升、美元走强）与资产价格位于历史极高分位形成双重风险，当前不是激进加仓时点，纪律优于预测，应耐心等待风险释放或更清晰的信号。


---

## Macro Strategist (shared)

基于已提供的宏观数据进行评估：

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 美债收益率飙升至4.62%叠加DXY站上108，实际利率上行，对风险资产与黄金形成双重绞杀
KEY_TAILWIND: VIX回落至16附近，市场尚未进入恐慌模式，流动性环境仍可控
ONE_LINER: 利率风暴主导全局，美元与实际利率双强压制一切，倾向减仓或防御性维持
```

**补充说明**：若组合含黄金/商品类资产，当前环境为**双杀格局**——DXY 108.26 持续走强 + TIP月跌3.88%确认实际利率上行，黄金基本面逆风极强，需严格控制敞口。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格处于2年分位99%，历史极高位置
  - RSI 58.27中性，未进入超买区
  - MA20高于MA120偏离度12.38%，低于15%均值回归阈值
ONE_LINER: 虽处上升趋势，但价格分位99%暗示高位风险，且无强突破信号，SIGNAL为neutral，支撑位MA120 44.92。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓明细，按中性假设评估，无集中度/流动性风险信号；建议实盘时确认集中度≤35%再决策。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-06 > cutoff 2024-12-31)

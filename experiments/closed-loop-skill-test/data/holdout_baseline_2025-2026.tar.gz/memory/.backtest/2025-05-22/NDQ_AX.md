# Committee: NDQ.AX

**Date**: 2025-05-22
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-22",
  "vix": 20.28,
  "tnx": 4.553,
  "usdcny": 7.2019,
  "audcny": 4.6336
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无加仓计划，等待价格回踩 MA250（约 45.71）或突破 MA120 阻力（约 48.06）确认方向后再行决策"

RISK_PLAN:
  stop_loss_trigger: "若持仓，跌破 MA250 支撑 45.71 且日线收盘连续两日低于该位 → 考虑减仓 20-30%"
  what_if_wrong:
    worst_case_pnl_cny: "N/A（回测模式无持仓数据）"
    recovery_estimate: "若从当前价位回调至 MA250 约 -5%，range-bound regime 历史中位恢复时间 4-8 周"

PERSONAL_NOTE:
  - 当前仓位中性假设，NDQ.AX 处于 2 年价格分位 87% 的偏贵区间，Quant / Macro / Risk 三方均给出中性信号，无任何方向性共识，不宜在此位置主动加码。
  - 本次建议在子弹中占比 0%，等待信号明朗化——要么价格回踩至 MA250（45.71）附近提供更好的风险收益比，要么放量突破 MA120（48.06）确认向上动能后再考虑追入。
  - 操作纪律：range-bound + 缩量（RVOL 0.65x）的本质是市场在蓄力选方向，宁可错过第一根突破阳线的 3-5%，也不要因为"怕踏空"在 87 分位追入后承受均值回归的下行空间；同时宏观端 10Y 美债 4.55% 与美元走弱的对冲格局意味着没有急迫的宏观窗口必须立刻行动。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10年期美债收益率半年飙升42%至4.55%，利率紧缩压力持续压制估值。
KEY_TAILWIND: 美元走弱(-4.35%)叠加实际利率下行(TIP +4.16%)，为风险资产提供货币宽松缓冲。
ONE_LINER: 利率上行与美元走弱相互对冲，宏观环境偏中性，建议维持现有仓位结构。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - 2年价格分位87%，历史高位，估值偏高  
  - RSI(14) 62.30中性偏高，未超买但上涨动能受限  
  - MA20与MA120纠缠(-3.13%)，趋势不明；价格略高于MA120，接近阻力  
  - 成交量萎缩(RVOL 0.65x)，缺乏突破动力  
ONE_LINER: range_bound regime下，高位分位与RSI中性偏高矛盾，趋势不明，信号中性；支撑在MA250 45.71，阻力在MA120 48.06附近。

### Risk Officer
SIGNAL: ok
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无实时持仓数据，无法评估集中度和现金；请基于完整上下文决策，历史建议：单资产仓位上限35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-22 > cutoff 2024-12-31)

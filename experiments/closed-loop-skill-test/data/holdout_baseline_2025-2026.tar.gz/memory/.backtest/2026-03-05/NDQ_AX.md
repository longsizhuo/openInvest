# Committee: NDQ.AX

**Date**: 2026-03-05
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-05",
  "vix": 23.75,
  "tnx": 4.146,
  "usdcny": 6.897,
  "audcny": 4.8803
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 若价格有效跌破MA250（52.14）且VIX持续 >25，则考虑减仓30%
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓快照）
    recovery_estimate: 3-6个月（基于历史downtrend周期）

PERSONAL_NOTE:
  - 回测模式下假设用户持仓中性，无极端集中度或浮盈浮亏数据。
  - 本次HOLD建议不涉及新增仓位，维持现有配置。
  - 市场VIX突破23且月涨29%显示恐慌情绪升温（类似INDEP_DEFENSE_FLAG=on），叠加Quant显示估值偏高（2年价格分位73%），建议避免在恐慌中加仓，保持纪律等待企稳信号。


---

## Macro Strategist (shared)

**SIGNAL:** risk_off
**STRENGTH:** 6
**SCORE:** -3
**KEY_HEADWIND:** 10Y收益率飙升+26%叠加VIX突破23且月涨29%，利率恐慌双杀风险资产估值
**KEY_TAILWIND:** DXY月跌2.8%+TIP月涨9%（实际利率大幅下行），黄金获"双击"格局
**ONE_LINER:** 利率飙升+恐慌升温环境下偏向减仓风险资产，但黄金/商品类获美元走弱+实际利率下行双引擎支撑，可维持或择机加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年价格分位73%，估值偏高
  - 当前价52.39紧贴MA250(52.14)关键支撑，偏离仅0.49%
  - 周线RSI 39.09接近超卖，但日线RSI 48.32中性偏弱
ONE_LINER: 下降趋势中估值偏高，价格测试MA250长期支撑，RSI未极端超卖，信号为中性。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，无持仓快照）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下假设持仓中性，无 Dreaming 历史模式可查；需回测结束后提供完整 portfolio_summary 方可做精确风险量化，当前不触发减仓信号。
```

**补充说明**：

⚠️ 本次评估受限于回测模式：
- 无 `portfolio_summary` 可提取集中度/浮盈/现金等字段
- 无 `Dreaming` 长期行为模式（无法判断是否存在情绪化追涨历史）
- 无 `WealthContextOfficer` 流动性报告

**风险关注点**：
| 维度 | 状态 | 备注 |
|------|------|------|
| 集中度 | ⚠️ 数据缺失 | 假设中性 |
| 流动性 | ⚠️ 数据缺失 | - |
| 追涨模式 | ✅ 无记录 | Dreaming 暂无 |
| 止损触发 | ⚠️ 数据缺失 | 需成本基准 |

**建议**：回测完成后若 NDQ.AX 集中度 >35% 且浮盈 >20%，应主动申请委员会复核，防止单资产超配风险在实盘落地。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-05 > cutoff 2024-12-31)

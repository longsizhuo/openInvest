# Committee: NDQ.AX

**Date**: 2025-10-30
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-30",
  "vix": 16.91,
  "tnx": 4.093,
  "usdcny": 7.099,
  "audcny": 4.6687
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 20000
  add_levels:
    - if price drops 5% from current levels → add ¥15000
    - if price drops 10% (approaching MA120 ~52.58) → add ¥15000

RISK_PLAN:
  stop_loss_trigger: 股价跌破 MA120 (≈52.58) 且 ^VIX 重新升破 20 → 减仓 50%
  what_if_wrong:
    worst_case_pnl_cny: -5000
    recovery_estimate: 3-6 个月（基于历史回调至均线后反弹统计）

PERSONAL_NOTE:
  - 用户处于回测模式，持仓假设为中性，无已知集中度或浮亏压力。
  - 本次建议建仓金额约占假设子弹的5%，属于试探性底仓，旨在参与趋势同时控制风险。
  - 心理纪律：当前价格处于历史极高分位（2年100%），且RSI超买，Quant给出明确的bearish信号。此仓位为“试错仓”，必须严格执行止损纪律，耐心等待更明确的趋势确认或深度回调机会。**uptrend 中的 ACCUMULATE 怀疑清单检查**：1. MA120偏离度10.89%，低于15%阈值，但RSI 73.49的超买状态增加了短期回调风险。2. VIX近期从高位回落（月降11%），并非从极低位上升，暂无市场焦虑飙升的信号。3. 如果30天后股价下跌10%，此ACCUMULATE的理由（捕捉潜在趋势延续）将变得脆弱，因为技术面超买与估值压力可能导致趋势反转。因此，本建议仅以极小仓位试探，并设定严格止损。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: 0
KEY_HEADWIND: 10Y国债收益率月涨16.7%突破4%，利率风险重定价压制风险资产估值
KEY_TAILWIND: 美元指数月跌5.7%叠加实际利率下行（TIP月涨9.5%），黄金双击环境成型
ONE_LINER: 宏观信号分化——利率上行对冲恐慌消退与美元走弱，建议维持现有仓位，观察下周CPI数据定调
```

**要点拆解：**
- 🟢 VIX 16.91（月降11%）→ 恐慌退潮，非风险出逃环境
- 🔴 TNX 4.09%（月涨17%）→ 名义利率快速上行，成长股承压
- 🟢 DXY 99.53（月跌6%）→ 美元弱势，利好非美资产与商品
- 🟢 TIP 实际利率方向明确下行 → 黄金/商品的关键货币因子转暖

**判断依据：** 利率上行（利空）与美元走弱+实际利率下行（利好）形成对冲，宏观情绪处于平衡区间，暂无极端方向性信号。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 8
KEY_DATA:
  - 价格2年分位100%，估值偏高
  - RSI(14) 73.49，进入超买区
  - MA120偏离度10.89%，低于15%阈值但需警惕
ONE_LINER: 尽管REGIME为上升趋势，但价格处于历史极端高位且RSI超买，均值回归风险上升，SIGNAL bearish，支撑看MA120 52.58。

### Risk Officer
SIGNAL: ok  
STRENGTH: 3  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下持仓中性，建议建仓比例上限为总资产的25%以控制风险。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-30 > cutoff 2024-12-31)

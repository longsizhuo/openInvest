# Committee: NDQ.AX

**Date**: 2025-06-03
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.50)
**Dominant view**: quant
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-03",
  "vix": 17.69,
  "tnx": 4.46,
  "usdcny": 7.2037,
  "audcny": 4.6327
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.50
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 5000
  add_levels:
    - 价格跌至 ¥47.0（约-3%）且 RSI < 50 → 加仓 ¥10,000
    - 价格跌至 ¥44.5（约-7%）靠近 MA120 支撑 → 加仓 ¥15,000

RISK_PLAN:
  stop_loss_trigger: 跌破 MA120（¥48.1）且收盘连续 3 日站不回 + VIX 突破 22 → 全部止损清仓
  what_if_wrong:
    worst_case_pnl_cny: -4500（满仓 3 万跌 15%）
    recovery_estimate: 4-6 个月（range_bound regime 下震荡修复）

PERSONAL_NOTE:
  - 回测模式无真实持仓数据，假设中性仓位；NDQ.AX 价格处于 2 年 88% 高分位，估值偏贵，追高风险明确。
  - 本次试探仓 ¥5,000 仅占常见子弹的 2-3%，绝大部分资金通过网格在更低价位分批介入，避免在利率飙升环境下一次性建满。
  - **Uptrend ACCUMULATE 检查（虽为 range_bound 仍适用警示）**：①价格距 MA120 仅 -0.09% 偏离，暂无均值回归压力；②VIX 月跌 32% 至 17.69，未见恐慌上升信号；③若 30 天后跌 10%（约 ¥43.7），会落入第二网格档位附近，ACCUMULATE 逻辑仍成立（低位加仓摊薄成本）。核心纪律：10Y 收益率月涨 48% 是科技股最大估值杀手，**不要因 VIX 回落就放松警惕**——耐心等网格触发，而非追价入场。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: 0
KEY_HEADWIND: 10Y美债收益率月涨48%，长端利率飙升压制风险资产估值
KEY_TAILWIND: 美元月贬8%+实际利率下行，构成黄金双利好（双击）
ONE_LINER: 利率飙升与美元走弱对冲，短期维持现有仓位，关注收益率是否见顶

---

**判断逻辑**：
- **VIX 17.69（月跌32%）**：恐慌大幅消退，风险情绪改善
- **DXY 99.25（月贬8%）**：美元弱势明确，利好商品/黄金
- **TIP月涨4.88%**：实际利率下行确认，黄金货币面双击条件成立
- **TNX 4.46%（月涨48%）**：长端利率飙升是最大矛盾——若为财政赤字/期限溢价驱动而非通胀，风险资产承压但衰退预期升温又利好避险资产

**结论**：利率风暴 vs 美元崩塌形成对冲，非典型risk-on/risk-off环境，保守中性。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 3  
KEY_DATA:  
  - 价格2年分位88%，历史高位，估值偏高风险  
  - RSI 59.26中性区域，未超买但接近上轨  
  - MA20与MA120纠缠差-0.09%，无明确趋势方向  
ONE_LINER: 在range_bound REGIME下，价格高位盘整且无趋势，SIGNAL neutral，支撑MA120 48.10，阻力需观突破。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性持仓下风险中等；建议实盘时单一纳斯达克ETF集中度≤30%。
```

**补充说明**：
- 本决策为历史回测，无 portfolio_summary 可读，所有关键数字字段标记 N/A
- Dreaming insights 暂无，无法识别用户历史情绪化追涨模式
- 基于"中性持仓"假设，无集中度/流动性/止损硬伤，SIGNAL 维持 ok
- **实盘切换后**需重新拉取真实持仓数据再行评估


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-03 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-28
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.30)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-28",
  "vix": 25.15,
  "tnx": 4.216,
  "usdcny": 7.2864,
  "audcny": 4.6499
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.3
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若已有持仓，价格跌破近期低点且RSI<30，考虑止损。
  what_if_wrong:
    worst_case_pnl_cny: 0 (当前裁决为不操作，无新增风险敞口)
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 本次评估基于回测模式，Risk Officer因缺乏持仓数据（标有[WORKER_UNAVAILABLE]）无法提供有效评估，触发安全规则强制保守裁决。
  - 宏观面面临利率飙升压力（10Y国债收益率月涨48%至4.22%），与美元走弱（DXY跌至99）形成对冲，信号矛盾。Quant技术面明确看跌（downtrend regime，跌破MA250）。在此矛盾且数据受限的环境下，选择观望是审慎之举。
  - 虽然理论上空仓时HOLD可能错失机会，但鉴于技术破位和宏观逆风，等待更清晰的信号或数据支持是更优选择。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y国债收益率月涨48%飙升至4.22%，利率环境急剧收紧，对风险资产估值构成重压。
KEY_TAILWIND: DXY跌至99 + TIP月涨2.66%，美元走弱叠加实际利率下行，为黄金/商品提供双重顺风。
ONE_LINER: 利率飙升与美元走软对冲，宏观信号矛盾偏谨慎——风险资产维持观望，黄金类资产可小仓位持有。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位76%估值偏高，处于历史高位
  - 价格跌破MA250(45.26)且缩量(RVOL 0.67)，确认破位
  - MA20低于MA120达8.87%，确认下降趋势
ONE_LINER: REGIME为下降趋势，价格高位跌破年线，RSI中性无法支撑反弹，维持看跌，阻力在MA120(48.02)，支撑在近期低点附近。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无持仓数据，无法进行集中度、子弹及压力测试评估，故维持中性信号。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-28 > cutoff 2024-12-31)

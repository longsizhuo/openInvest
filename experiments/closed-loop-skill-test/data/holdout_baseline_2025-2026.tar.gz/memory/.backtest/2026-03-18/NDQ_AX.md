# Committee: NDQ.AX

**Date**: 2026-03-18
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-18",
  "vix": 25.09,
  "tnx": 4.259,
  "usdcny": 6.8863,
  "audcny": 4.8954
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不开新仓，等待 regime 切换或估值回落信号"
    - "若价格跌至 50.0 附近（Quant 支撑位）且 VIX 回落至 20 以下 → 小仓位试探 ¥20000"

RISK_PLAN:
  stop_loss_trigger: "若已有持仓，跌破 49.5（MA250 下方约 5%）同时 ^VIX > 28 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: "若趋势延续至 50 关口，预计 2-4 个月震荡筑底后才有修复"

PERSONAL_NOTE:
  - 回测模式下假设中性持仓，当前无极端集中度风险；本建议核心逻辑基于 Quant 与 Macro 的一致看空信号。
  - Quant 判定 downtrend regime + 价格跌破 MA250（-1.39%），RSI 46.5 尚未超卖，说明下行空间未释放完毕；Macro 给出 risk_off（VIX 月涨 46%、10Y 月涨 20%），恐慌与利率冲击双重压制权益资产估值。两者方向高度一致，Risk Officer 无异议（SIGNAL: ok）。
  - 未收到估值（VALUATION）和情绪表盘数据，但 Quant 已明确 2 年分位 68% 偏高位——即使回调逻辑也支持观望而非追多。
  - uptrend ACCUMULATE 检查不适用（当前为 downtrend regime）。若 regime 翻转回 uptrend 且 VIX 回落 <18，再评估是否从 HOLD 切至 ACCUMULATE。
  - **操作纪律**：当前环境的核心风险是"接飞刀"——趋势未见底、恐慌未极端化（VIX 25 不算顶部但还在爬升）。耐心等待 Quant 出现超卖反弹信号（RSI < 35）或 Macro 从 risk_off 转中性后再考虑加仓。持币的机会成本在此刻低于被套的风险成本。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -3
KEY_HEADWIND: VIX飙升46%+10Y收益率月涨20%，市场恐慌与利率冲击叠加，风险资产承压
KEY_TAILWIND: DXY走弱+实际利率下行，为黄金及商品提供对冲缓冲
ONE_LINER: 恐慌情绪急速升温但未至极端，利率上行压制估值；建议减仓权益、维持黄金对冲头寸
```

**判断逻辑**：
- **VIX 25+ 且月涨46%** → 恐慌已实质性爬升，非"噪音"
- **TNX 4.26% 月涨20%** → 名义利率快速走高，对久期资产形成双杀
- **DXY 100 月跌1.24% + TIP月涨10.5%** → 美元走弱+实际利率下行，**黄金双击环境**（若组合含黄金，这是明确利好）

⚠️ 核心矛盾：**利率上行（利空）vs 美元/实际利率转弱（利好黄金）**——权益减仓、黄金可守。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格跌破关键MA250均线（52.35），当前位于其下方-1.39%
  - RSI(14)=46.50 中性偏弱，未出现超卖反弹信号
  - 价格位于2年分位68%的偏高位，向下空间较大
ONE_LINER: 价格位于下降趋势中，且跌破长期MA250支撑，短期反弹乏力，趋势延续下方支撑看50关口。

### Risk Officer
**SIGNAL: ok**
**STRENGTH: 3**
**CONCENTRATION_PCT: N/A（回测模式，无持仓数据）**
**DRY_POWDER_CNY: N/A**
**PNL_PCT: N/A**
**WORST_CASE_LOSS_PCT_AT_-20: N/A**

**ONE_LINER:** 回测模式下持仓上下文无法还原，按"中性持仓（无极端集中）"假设评估；技术/宏观维度由 Quant 与 Macro Officer 负责，风险侧无流动性或止损触发。建议建仓比例上限 ≤ 总资产 35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-18 > cutoff 2024-12-31)

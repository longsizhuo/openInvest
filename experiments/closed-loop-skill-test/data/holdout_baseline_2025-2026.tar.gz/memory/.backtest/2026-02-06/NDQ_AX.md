# Committee: NDQ.AX

**Date**: 2026-02-06
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-06",
  "vix": 20.37,
  "tnx": 4.206,
  "usdcny": 6.9378,
  "audcny": 4.7983
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: N/A
  add_levels: N/A

RISK_PLAN:
  stop_loss_trigger: 若价格有效跌破关键长期均线MA250 (当前约51.97) 并伴随RSI未能从超卖区回升，则视为支撑失效信号，需重新评估。
  what_if_wrong:
    worst_case_pnl_cny: N/A （回测模式无具体持仓，基于历史波动估算潜在最大回撤可能在-10%至-15%区间）
    recovery_estimate: 参考近期回调幅度与宏观中性环境，预计在2-4个月内有望修复跌幅。

PERSONAL_NOTE:
  - 当前处于回测模式，假设持仓为中性状态，无极端集中度或浮亏/浮盈压力。
  - 本次建议不新增任何仓位，在总子弹中占比为0%。
  - 资产处于技术面（超卖测试支撑）与估值面（历史分位较高）的矛盾期，且宏观与量化信号均为中性，缺乏明确方向性驱动。操作上应保持耐心，等待价格要么确认支撑后出现更明确的反转信号，要么估值通过时间或下跌进一步消化。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 美债收益率攀升压制风险资产估值
KEY_TAILWIND: 美元走弱与实际利率下行支撑风险偏好
ONE_LINER: 宏观情绪中性偏暖，维持当前配置，暂不建议大幅调仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 23.82 严重超卖，但2年价格分位72%仍处高位
  - 价格51.68已逼近并测试MA250 (51.97) 长期支撑
  - 近一月跌幅-8.21%，短期情绪与长期估值位置出现矛盾
ONE_LINER: 处于震荡格局，短期RSI超卖推动价格测试长期均线支撑，但高位分位限制了趋势性反弹空间，故信号中性。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，持仓未还原）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓细节，按中性假设评估风险可控；建议实盘时该资产集中度上限35%，单次加仓不超过可用子弹20%。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-06 > cutoff 2024-12-31)

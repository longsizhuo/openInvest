# Committee: NDQ.AX

**Date**: 2025-10-03
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-03",
  "vix": 16.65,
  "tnx": 4.119,
  "usdcny": 7.119,
  "audcny": 4.6962
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "若价格从当前位置回落 5%（接近MA120附近）→ 再加 ¥10,000"
    - "若价格回落 10%（触及MA120下方）→ 再加 ¥5,000 完成建仓"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA120 且 RSI < 45 同时 VIX 突破 22 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -6000
    recovery_estimate: "2-4 个月（宏观风险偏好若持续，解套较快）"

PERSONAL_NOTE:
  - 回测模式下用户持仓上下文中性，无集中度/盈亏数据，按分散化假设处理
  - 本次建仓约占子弹的 3-5%（首笔 ¥15,000），属于极轻仓试探，不追高位
  - Quant 指出 2 年价格分位 100%（估值极端）、RSI 68.63 逼近超买、偏离 MA120 约 10%——这三点构成了 uptrend ACCUMULATE 怀疑清单的核心检查：(1) 偏离 10% 未破 15% 红线，尚可接受；(2) VIX 从 24.5 大幅回落至 16.65（非从低位上升），恐慌消退而非焦虑升温；(3) 若 30 天后跌 10%，宏观弱美元+实际利率下行的双击逻辑仍成立，ACCUMULATE 理由不被推翻。但 100% 分位意味着此处是历史绝对高点，任何加仓都必须分批且设严格止损——不追涨是纪律底线


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 美国经济放缓信号若超预期，可能触发衰退恐慌逆转宽松预期
KEY_TAILWIND: 美元单月暴跌近11%+实际利率大幅回落，为风险资产与黄金提供双重顺风
ONE_LINER: VIX回落+美元崩跌+实际利率下行，宏观环境偏暖，整体组合倾向加仓，黄金受益尤其显著。
```

---

**简要判断逻辑：**

| 指标 | 状态 | 信号 |
|------|------|------|
| VIX 16.65 (-32% MoM) | 恐慌消退 | ✅ Risk-on |
| TNX 4.12% (-0.89%) | 名义利率回落 | ✅ 利好估值 |
| DXY 97.72 (-10.86%) | 美元大幅走弱 | ✅ 黄金/商品顺风 |
| TIP +14.46% MoM | 实际利率显著下行 | ✅ 黄金双击 |

**货币因素总结（如组合含黄金/商品）：美元走弱 + 实际利率下行 = 黄金基本面"双击"环境，当前是近年少见的强支撑格局。**


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年价格分位100%，估值极高
  - RSI 68.63接近超买区，趋势持续性存疑
  - 价格偏离MA120约10%，存均值回归风险
ONE_LINER: 处于历史高位的上升趋势，但分位数与RSI显示买力衰竭，趋势末期应谨慎而非追多。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下数据缺失，基于中性假设评估为低风险，建议单资产仓位上限25%以确保分散化。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-03 > cutoff 2024-12-31)

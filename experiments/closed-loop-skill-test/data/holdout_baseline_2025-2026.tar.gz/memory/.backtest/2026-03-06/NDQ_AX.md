# Committee: NDQ.AX

**Date**: 2026-03-06
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-06",
  "vix": 29.49,
  "tnx": 4.133,
  "usdcny": 6.897,
  "audcny": 4.8362
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.60
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不建仓，等待 VIX 回落至 22 以下且 MA20 企稳后再考虑试探建仓"
    - "若价格跌至 ¥48.5（MA250下方约-8%）且 VIX < 25 → 可建 5% 试探仓"

RISK_PLAN:
  stop_loss_trigger: "若已持有：价格跌破 MA250（¥52.16）收盘确认 + VIX 持续 > 28 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "若误判空头、行情直接反弹至 MA120（¥55.35），约需 15-25 个交易日确认趋势反转"

PERSONAL_NOTE:
  - 回测模式下持仓假设中性，无法精确评估集中度与浮盈浮亏，裁决偏向防御端。
  - Quant 2年价格分位73%偏高 + Macro VIX 29.49（月涨55%）进入恐慌区间，两者构成估值+情绪的双重压制；downtrend REGIME 与 risk_off SIGNAL 高度一致，不值得在此位置逆势加仓。
  - 操作纪律：宁可错过左侧、不做右侧套牢——当前环境适合"持有现金、等VIX回落+趋势企稳"的耐心策略。若30天后VIX降至20以下且价格稳在MA250上方，可启动网格式ACCUMULATE。
```


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: VIX飙升+55%至29.49，10Y收益率同步走高，市场恐慌叠加紧缩预期，风险资产承压。
KEY_TAILWIND: 美元走弱（DXY -2.47%）叠加实际利率下行（TIP +10%），黄金/商品双击环境成型。
ONE_LINER: 恐慌升温+利率上行，广谱风险资产倾向减仓；黄金类资产受货币因素支撑，可维持。
```

**补充逻辑**：
- VIX 29.49 + 月涨55% = 典型risk_off信号，非恐慌底部但仍处恐惧区间
- 名义利率（TNX +21%）与实际利率（TIP +10%）背离 → 暗示通胀预期上行或避险资金涌入TIPS
- DXY跌破99 + 实际利率下行 = **黄金的"双重顺风"**，货币面明确利好
- 整体环境偏滞胀/不确定性，建议防御姿态


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 趋势确认：MA20 (51.91) 低于 MA120 (55.35) 超6%，下行趋势明确
  - 位置偏高：2年价格分位73%，估值风险累积
  - 关键支撑：价格52.60紧贴MA250(52.16)，但上方阻力MA120(55.35)压力显著
ONE_LINER: 下行趋势中，价格在MA250处寻支撑但估值分位偏高，反弹至MA120阻力区前仍看空，SIGNAL与REGIME一致。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下持仓中性，无历史行为模式，风险可控。建议依据技术信号谨慎建仓，单次加仓不超过可用资金的15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-06 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-05-02
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: risk
**Suggested allocation CNY**: 20000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-02",
  "vix": 22.68,
  "tnx": 4.322,
  "usdcny": 7.2706,
  "audcny": 4.6439
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 20000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 20000
  add_levels:
    - "if price drops 3% from current (approx. 44.20) → add ¥20000"
    - "if price drops 5% (approx. 43.29) → add ¥20000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA250 (45.35) 且 ^VIX > 20 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -2000
    recovery_estimate: "1-3 个月"

PERSONAL_NOTE:
  - 回测模式下假设用户持仓中性，无极端集中度风险，当前无明显浮盈浮亏压力。
  - 本次试探仓约占假设子弹的2-5%，为轻仓试探，保留大量现金等待更明确的右侧信号或更低估值。
  - 宏观金融条件收紧（10Y美债飙升）与技术面（下跌趋势、价格高位分位但有支撑）均指向观望或轻仓，需严格执行网格纪律，避免在趋势反转前重仓。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y美债收益率月涨42%至4.32%，金融条件急剧收紧压制风险资产估值
KEY_TAILWIND: DXY破100+实际利率下行，双因子利好黄金及商品类资产
ONE_LINER: 维持偏防御配置；名义利率飙升压制股市，但美元走弱+实际利率降为黄金提供逆势支撑，风险资产观望为主。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位81%高位，估值偏高风险
  - RSI(14)=54.62中性，未超卖亦无强势反弹动能
  - 价格(45.57)跌破MA120(48.02)但贴近MA250(45.35)，关键支撑未破
ONE_LINER: 下跌趋势中，价格虽处高位分位但RSI中性且在MA250获支撑，反弹力度不足，信号中性观望。

### Risk Officer
SIGNAL: ok  
STRENGTH: 2  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下持仓假设中性，无集中度风险数据，建议建仓比例上限不超过总资产的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-02 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-15
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-15",
  "vix": 30.12,
  "tnx": 4.323,
  "usdcny": 7.3119,
  "audcny": 4.612
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: N/A

RISK_PLAN:
  stop_loss_trigger: 若价格反弹至MA250（约45.19）后再次跌破，或VIX升破25并持续，考虑减仓20%
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式，持仓未知）
    recovery_estimate: N/A（无持仓基准）

PERSONAL_NOTE:
  - 回测模式下持仓状态未知，假设中性持仓，无极端集中度。
  - 本次建议维持现状，不新增资金投入（占子弹比例0%）。
  - 下跌趋势中保持耐心，避免逆势抄底，等待价格企稳于MA250上方且RSI脱离弱势区域后再考虑行动。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10年期美债收益率月涨近50%，金融条件快速收紧，压制风险资产估值。
KEY_TAILWIND: 美元指数月跌2.4%+实际利率下行，黄金/商品获货币双击利好。
ONE_LINER: 利率急升叠加VIX高企，宏观偏谨慎，建议整体维持偏防御配置。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格已跌破关键长期支撑MA250 (45.19)，偏离-3.79%
  - 价格处于两年历史70%高位分位，下跌趋势中仍有下行空间
  - RSI(14) 43.09中性偏弱，未进入超卖区提供反转信号
ONE_LINER: 处于下跌趋势，价格已跌破MA250长期支撑，结合高位分位及弱势RSI，技术面指向进一步下行可能。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，假设中性）
DRY_POWDER_CNY: N/A（回测模式，持仓未还原）
PNL_PCT: N/A（回测模式，无成本基准）
WORST_CASE_LOSS_PCT_AT_-20: N/A（无法计算，缺持仓权重）
ONE_LINER: 回测模式下持仓中性假设，无极端集中度/追涨行为风险信号，NDQ.AX技术面需由Quant评估，建议单次建仓不超过总仓位15%。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-15 > cutoff 2024-12-31)

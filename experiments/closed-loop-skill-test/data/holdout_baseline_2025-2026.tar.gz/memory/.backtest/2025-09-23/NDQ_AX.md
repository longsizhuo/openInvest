# Committee: NDQ.AX

**Date**: 2025-09-23
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-23",
  "vix": 16.64,
  "tnx": 4.12,
  "usdcny": 7.114,
  "audcny": 4.6952
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - "价格回撤至 MA120 附近 (≈¥49.9) → 加 ¥8,000"
    - "价格回撤至 MA250 支撑 (≈¥48.8) → 加 ¥10,000，累计投入占子弹 ≤10%"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA120 (¥49.9) 同时 RSI 仍 > 50 → 减仓 50%，等待 MA250 支撑确认"
  what_if_wrong:
    worst_case_pnl_cny: -1100
    recovery_estimate: "3-6 个月（uptrend 回调后通常在此窗口恢复）"

PERSONAL_NOTE:
  - 回测模式无持仓数据，假设中性仓位；当前零仓位或极轻仓，子弹充裕，不加仓的机会成本较高。
  - 本次试探仓 ¥5,000 占假设子弹 ~2%，属于最小颗粒度建仓，保留 ~95% 子弹等待回调加仓。
  - **uptrend ACCUMULATE 三检**：①价格离 MA250 偏离 13.47%，已接近 15% 均值回归红线——风险偏高但未突破，用小仓位而非大仓对冲；②Macro 称 VIX 暴跌 41%，恐慌退潮情绪乐观，暂无上升信号但需警惕情绪见顶；③若 30 天后跌 10% 至 ~¥54.6，仍在 MA120 之上，ACCUMULATE 逻辑尚存但第二笔网格必须等更深回调（-8%）。**核心纪律：不追高、不一次性满仓，RSI > 72 + 历史100%分位 = 只试探不冲动。**


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 7
SCORE: +2
KEY_HEADWIND: 10年期美债收益率微升至4.12%，名义利率上行对成长股估值构成温和压制
KEY_TAILWIND: 美元指数月跌12%叠加实际利率大幅回落，黄金/商品迎货币端双击
ONE_LINER: VIX暴跌41%+美元崩跌，恐慌退潮且流动性环境友好，整体偏向加仓


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 7
KEY_DATA:
  - RSI 72.56 超买，强化回调信号
  - 价格2年分位100%，历史高位，均值回归风险高
  - 价格离MA250偏离13.47%，支撑位48.83待测试
ONE_LINER: uptrend中价格创新高但RSI超买，高位分位暗示趋势衰竭，bearish信号指向MA120支撑49.93。

### Risk Officer
SIGNAL: ok
STRENGTH: 5
CONCENTRATION_PCT: N/A (回测无持仓数据)
DRY_POWDER_CNY: N/A (回测无持仓数据)
PNL_PCT: N/A (回测无持仓数据)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测无持仓数据)
ONE_LINER: 回测模式下无持仓数据，风险无法量化，建议在获得完整持仓信息后再评估集中度与建仓上限。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-23 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-10-01
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-01",
  "vix": 16.29,
  "tnx": 4.106,
  "usdcny": 7.119,
  "audcny": 4.7058
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.7
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "if price drops 3% from current level → add ¥20,000"
    - "if price drops 7% from current level → add ¥15,000"

RISK_PLAN:
  stop_loss_trigger: "股价跌破MA120支撑位（约50.52）且同时 ^VIX > 22 → 减仓30%"
  what_if_wrong:
    worst_case_pnl_cny: -7500
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户处于回测模式，无真实持仓与资金数据，本次建议基于宏观与技术信号。
  - 建议初始建仓金额占假设可用资金的5%，为试探性头寸，大部分子弹留待回调。
  - uptrend中ACCUMULATE需警惕：1) 价格较MA120偏离11.50%（<15%），均值回归压力存在但非极端；2) VIX处于16低位，未显示从低位急升焦虑信号；3) 若30天后跌10%，基于美元走弱与实际利率下行的宏观风险偏好（risk_on）背景，加仓逻辑部分成立，但分批执行是关键纪律。


---

## Macro Strategist (shared)

**宏观环境评估** (as of 2026-06-26)

---

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 10Y名义利率仍处4.1%高位，若通胀反弹将制约美联储降息空间
KEY_TAILWIND: 美元指数三个月暴跌12%+实际利率急降（TIP+14%），构成风险资产与黄金的双重顺风
ONE_LINER: VIX跌至16恐慌消退，美元崩跌+实际利率下行打开宽松交易窗口，整体偏加仓倾向
```

**核心判断依据：**
- **VIX 16.29**，三月跌幅37%，已进入低波动舒适区
- **DXY 97.71**，三月-12%，美元弱势为全球资产提供流动性支撑
- **TIP +14%**，实际利率大幅下行，利好黄金/成长股估值
- **TNX 4.1%**，虽小幅走高但近期企稳，非主要威胁

⚠️ **黄金/商品专项**：美元走弱+实际利率下行=黄金"双击"环境确立


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格处于2年99%分位，历史极高位，估值偏高风险显著。
  - RSI(14) 59.86，处于中性偏强区域，未进入传统超买区。
  - 当前价较MA120偏离11.50%，存在均值回归压力。
ONE_LINER: REGIME虽为uptrend，但价格已触及99%分位历史峰值，上涨动能可能衰竭，技术上偏向均值回归的bearish，阻力位在当前价附近，支撑位看MA120（50.52）。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式，无持仓数据)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式)
ONE_LINER: 回测模式无持仓上下文，假设中性集中度；风险评估依赖技术面/宏观信号主导，建议实际建仓时单资产占比≤30%。

---

**备注**：
本次为历史回测，未提供 portfolio_summary，所有财务数字均无法验证，标记 N/A。若进入实盘评估，需补充完整持仓、成本基础、现金余额及 WealthContextOfficer 流动性判断，方可给出精确风险定级。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-01 > cutoff 2024-12-31)

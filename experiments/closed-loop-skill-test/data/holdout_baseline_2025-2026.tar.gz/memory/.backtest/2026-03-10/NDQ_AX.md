# Committee: NDQ.AX

**Date**: 2026-03-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-10",
  "vix": 24.93,
  "tnx": 4.136,
  "usdcny": 6.911,
  "audcny": 4.8848
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.7
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A
EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若 VIX 持续高于 25 且价格有效跌破 MA250 支撑位（如 50.0），需重新评估减仓必要性。
  what_if_wrong:
    worst_case_pnl_cny: 假设持仓价值 100 万，最坏情况浮亏约 20 万 CNY (对应股价跌至 42 附近)。
    recovery_estimate: 6-12 个月，取决于宏观风险事件（利率、VIX）的演变及科技股基本面能否提供支撑。

PERSONAL_NOTE:
  - 当前为回测模式，假设持仓中性，但宏观环境呈现明确的风险规避信号（VIX飙升、利率跳涨）。
  - 本次建议为 0 仓位变动，不增加风险暴露。鉴于 Macro 强烈的 risk_off 信号，加仓权益类资产的性价比极低，"按兵不动"优于"逆势而为"。
  - 操作纪律上，建议耐心等待宏观风险指标（如 VIX、10Y收益率）出现实质性缓解或稳定信号后，再考虑行动。当前的市场恐慌环境是测试耐心而非测试勇气的时候。


---

## Macro Strategist (shared)

**SIGNAL:** risk_off
**STRENGTH:** 6
**SCORE:** -1

**KEY_HEADWIND:** VIX飙升30%突破24 + 10Y收益率单月涨21%，市场恐慌与利率冲击双杀风险资产。

**KEY_TAILWIND:** 美元走弱(-2.7%)叠加实际利率下行(TIP+9.6%)，黄金/商品迎货币双击窗口。

**ONE_LINER:** 恐慌升温、利率跳涨，风险偏好承压；但美元+实际利率双降构成商品结构性利好，组合宜减仓权益、维持/加仓黄金对冲。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - 价格2年分位71%偏高，但RSI 47中性，未进入超卖区
  - 价格紧贴MA250（52.21），距MA120（55.31）仍有-6%偏离，短期或存技术支撑
  - 下跌趋势中，成交量萎缩（RVOL 0.84x），显示下行动能暂不强劲
ONE_LINER: 处于下行趋势（REGIME=downtrend），但价格在关键均线MA250附近获支撑且RSI未超卖，短期下行动能与支撑力对冲，信号中性。

### Risk Officer
SIGNAL: ok
STRENGTH: 1
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无真实持仓数据，无法评估集中度/现金/浮盈；Risk Officer 无异议，交由 Quant + Macro 信号驱动决策。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-10 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-02-20
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-20",
  "vix": 15.66,
  "tnx": 4.5,
  "usdcny": 7.2833,
  "audcny": 4.6177
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若 Macro risk_off 缓解（score ≥ -1）且价格回踩 MA120 附近 ¥47.1 → 考虑建 5% 试探仓"
    - "若 VIX 突破 20 且价格跌破 MA120 → 继续观望不动"

RISK_PLAN:
  stop_loss_trigger: "若已持仓：跌破 MA120 ¥47.1 且 10Y 收益率继续上行突破 5% → 减仓 50%；回测模式暂无实际持仓触发线"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "N/A（当前无新增仓位）"

PERSONAL_NOTE:
  - "回测模式无持仓快照，假设中性起点；NDQ 处2年价格分位98%极端高位，短期动能衰减（1月回报仅0.19%），任何新增暴露都需极强理由"
  - "本次建议仓位变动为零，占子弹0%——全部三方中无一看多，Macro risk_off（score -3，strength 7）是最强否定信号"
  - "uptrend 怀疑清单自检：①价格离MA120偏离8.54%，<15%阈值尚可；②VIX 15.66处低位未上升，暂无恐慌哨兵；③但若30天后跌10%，Macro 利率+美元双升的逆风会放大回撤且无短期催化剂支撑反弹——结论：当前不值得在98%分位追加风险暴露，等价格回踩MA120或宏观条件改善再行动"


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y收益率月飙+92%叠加美元强势+7.6%，金融条件急剧收紧，黄金/商品遭实际利率上行+美元走强双杀
KEY_TAILWIND: VIX回落至15.66，恐慌情绪显著降温，短期无系统性流动性危机
ONE_LINER: 利率与美元双升构成宏观逆风，建议减仓风险资产、规避黄金及大宗商品敞口，维持防御配置
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - RSI 54.84 中性偏强，未超买  
  - 价格2年分位98%极高，估值偏高风险  
  - 价格离MA120偏离度8.54%，均值回归压力尚可  
  - MA20 > MA120 +8.06%，但1月回报仅0.19%显示动能减弱  
ONE_LINER: 上升趋势中价格处历史高位，RSI中性且近期动能减缓，信号转为中性以规避高分位回调风险，支撑参考MA120 47.10。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式无持仓快照）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无实际持仓数据，假设中性配置；NDQ 为单一市场科技ETF，建议建仓比例上限25-30%，避免单一美股科技暴露过重。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-20 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-10-20
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.78)
**Dominant view**: quant
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-20",
  "vix": 18.23,
  "tnx": 3.986,
  "usdcny": 7.1264,
  "audcny": 4.6332
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.78
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 50000
  add_levels:
    - if price drops 3% from entry → add ¥50,000
    - if price drops 5% from entry → add ¥50,000

RISK_PLAN:
  stop_loss_trigger: 跌破 MA120 (约 ¥51.27) 同时 ^VIX > 22 → 减仓 50%
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: 3-6 个月

PERSONAL_NOTE:
  - 当前为回测模式，假设持仓中性，NDQ.AX 仓位极轻，存在显著的机会成本。
  - 首笔建仓 5 万元，仅占预估可用子弹的 5%，属于轻仓试探，符合纪律。
  - 趋势明确但价格历史高位，需坚持分批纪律；当前 VIX 回落消除了短期恐慌，为分批建仓提供了窗口。

**裁决逻辑与关键引用**：
- **三方一致性**：Quant（bullish，趋势）、Macro（risk_on）、Risk（ok）三方方向一致，支撑积极行动。
- **规则应用**：
    1.  **现金机会成本规则**：在回测假设下，用户 NDQ.AX 仓位接近零。规则要求 CONCENTRATION_PCT < 20% 时不允许 HOLD，至少应给 ACCUMULATE 并建立小仓位。因此 verdict 被锁定为 ACCUMULATE，而非 HOLD。
    2.  **估值与情绪确认**：虽然输入中未包含 VALUATION 和 MARKET SENTIMENT 表盘，但 Quant 明确指出“价格2年分位100%，历史高位需警惕回调”。因此在 ACCUMULATE 时采取金字塔加仓（而非 lump-sum）以控制高位风险。
    3.  **uptrend ACCUMULATE 怀疑清单检查**：
        *   价格离 MA120 偏离度 9.05%，低于 15% 阈值，均值回归风险可控。
        *   宏观 VIX 信号显示恐慌消退，而非从低位上升，支持当前不是焦虑期。
        *   基于上升趋势和宏观支撑，即使短期回调 10%，核心逻辑（美元走弱、实际利率下行环境利好成长股）依然成立。因此 ACCUMULATE 判断通过。
- **综合判断**：在一致的乐观信号下，考虑到极轻仓位的高额机会成本，以及通过金字塔计划控制高位风险，选择以 5 万元启动试探性建仓是平衡之举。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y收益率升至3.99%且仍在上行，名义利率压力未解。
KEY_TAILWIND: 美元指数月跌7%+TIP月涨14%，实际利率下行+美元走弱构成黄金双击环境。
ONE_LINER: VIX跌至18恐慌消退、美元弱势明确，宏观情绪偏暖；黄金/商品类逢低可加仓，利率敏感型资产维持。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: bullish  
STRENGTH: 7  
KEY_DATA:  
  - 价格离MA120偏离度9.05%，低于15%均值回归风险阈值  
  - RSI 64.57 中性偏强，未进入超买区  
  - MA20>MA120 7.23%，趋势持续且未见收窄信号  
  - 价格2年分位100%，历史高位需警惕回调  
ONE_LINER: 上升趋势中RSI未超买且均线支撑有效，但价格处于历史极值，信号看涨但需监控阻力位56.52附近表现。

### Risk Officer
SIGNAL: ok  
STRENGTH: 3  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下假设持仓中性，建议NDQ.AX建仓比例上限不超过30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-20 > cutoff 2024-12-31)

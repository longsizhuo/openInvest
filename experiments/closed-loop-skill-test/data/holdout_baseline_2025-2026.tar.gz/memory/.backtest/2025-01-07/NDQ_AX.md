# Committee: NDQ.AX

**Date**: 2025-01-07
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.68)
**Dominant view**: quant
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-07",
  "vix": 17.82,
  "tnx": 4.683,
  "usdcny": 7.3223,
  "audcny": 4.5683
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.68
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "价格从当前回撤 3%（接近 MA20 支撑）→ 加仓 ¥15,000"
    - "价格回撤 7%（接近 MA120 约 45.0 支撑位）→ 加仓 ¥20,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 收盘跌破 MA120（约 45.0）且 RSI < 40 → 清仓全部头寸"
  what_if_wrong:
    worst_case_pnl_cny: -7500
    recovery_estimate: "3-6 个月（uptrend 中 MA120 通常提供强支撑）"

PERSONAL_NOTE:
  - 当前为回测模式，无真实持仓快照——本次建议基于中性持仓假设，实际执行前需确认 NDQ.AX 占比及现金余额。
  - 首笔试探仓 ¥15,000 仅占常规子弹的约 5-10%，保留充足弹药等待更优价位。
  - **uptrend ACCUMULATE 怀疑清单检查**：(1) 价格偏离 MA120 为 12.6%，低于 15% 阈值，均值回归风险可控；(2) VIX 17.82 且月跌 25%，并未从低位反弹，市场焦虑度在下降而非上升；(3) 若 30 天后跌 10%，将回落至 MA120 附近（约 45.0），这恰恰是 Quant 标注的强支撑位——此时第二档加仓刚好到位，ACCUMULATE 网格逻辑依然成立。三点均通过，维持 ACCUMULATE 而非降级 HOLD。
  - **核心矛盾**：Quant 看涨（技术面健康）vs Macro 中性偏负（DXY 108.54 + 实际利率上行构成金融条件收紧）。分批建仓而非一次性满仓，正是对此分歧的合理定价——用金字塔加仓把 Macro 逆风变成"越跌买越多"的纪律。
  - 价格 2 年分位 99% 确实处于极端高位，但 RSI 仅 59.33 说明动量尚未透支，MA20>MA120 扩张 11.73% 表明趋势仍在加速而非衰竭。高分位 + 低 RSI 的组合历史上常出现在强势趋势的中段而非尾端。


---

## Macro Strategist (shared)

根据提供的宏观数据，直接输出评估：

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 美元指数飙至108.54（月涨13.6%）叠加实际利率上行，黄金/商品承压双杀
KEY_TAILWIND: VIX回落至17.82（月跌25%），恐慌情绪消退，市场风险偏好边际修复
ONE_LINER: 美元与长端利率双强压制风险资产，但VIX低位提供缓冲——整体维持仓位，不宜追高加仓
```

---

**简评**：4.68%的10Y收益率配合DXY突破108，构成显著的金融条件收紧信号。虽然VIX回落给了短期喘息空间，但在美元走强+实际利率上行的组合下，黄金和大宗类资产面临明确逆风。当前环境偏向"等待信号"而非"主动出击"。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位99%历史高位，但RSI 59.33处50-70中性偏强区间
  - 价格偏离MA120仅12.6%（<15%），均值回归风险较低
  - MA20高于MA120 11.73%，趋势向上且未显收窄迹象
ONE_LINER: uptrend中价格接近高位但技术指标健康，支撑在MA120的45.0，短期看涨但需监控超买风险。

### Risk Officer
```
SIGNAL: ok
STRENGTH: N/A
CONCENTRATION_PCT: N/A（回测模式，无持仓快照）
DRY_POWDER_CNY: N/A（回测模式，无现金余额）
PNL_PCT: N/A（回测模式，无成本基础）
WORST_CASE_LOSS_PCT_AT_-20: N/A（缺持仓权重无法计算）
ONE_LINER: 回测模式下无真实持仓数据，假设中性持仓，无法评估集中度与流动性风险；若为实盘，需确认 NDQ.AX 占比 ≤25% 且现金充足后再执行 Quant/Macro 信号。
```

**补充说明**：Risk Officer 视角依赖 portfolio_summary 提供的**集中度、成本均价、浮盈、现金余额**等字段。当前回测模式下这些数据均缺失，无法执行压力测试（跌20%/35%情景）及流动性风险判定。建议实盘运行时重新触发评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-07 > cutoff 2024-12-31)

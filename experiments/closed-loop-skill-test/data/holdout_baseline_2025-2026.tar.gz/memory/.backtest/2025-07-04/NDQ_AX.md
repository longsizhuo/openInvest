# Committee: NDQ.AX

**Date**: 2025-07-04
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-04",
  "vix": 16.38,
  "tnx": 4.348,
  "usdcny": 7.1649,
  "audcny": 4.7124
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - "if price drops 5% from current level → add ¥5000"
    - "if price drops to MA120 support (approx. 48.01) and RSI < 45 → add ¥10000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破MA120支撑位（48.01）同时^VIX > 22 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -2000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户当前持仓假设为中性，无极端集中度风险。
  - 本次建议建仓金额（¥5000）约占假设子弹总额的5%，为谨慎的试探性头寸。
  - 虽然宏观风险偏好环境（risk_on）支持配置，但该资产估值处于历史极高分位（98%）且名义利率飙升构成直接逆风，应严格控制首次建仓规模，耐心等待回调信号加仓。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: 1
KEY_HEADWIND: 10Y国债收益率单月飙升53%至4.35%，名义利率快速上行压制估值
KEY_TAILWIND: 美元指数三个月暴跌8.64%至97.18附近3个月低位，叠加实际利率下行（TIP+3.59%），黄金类资产获双击利好
ONE_LINER: VIX降至16区间恐慌消退、美元走弱+实际利率下行构成温和风险偏好环境，但名义利率飙升需警惕；黄金/商品可维持偏多，整体组合维持现有仓位
```

---

**补充说明：**

| 指标 | 状态 | 信号 |
|------|------|------|
| VIX 16.38 (3月-22%) | 恐慌收敛，近10日稳于16.3-16.8 | 偏多 |
| DXY 97.18 | 逼近3月低点96.78，趋势向下 | 黄金利好 |
| TIP +3.59% | 实际利率下行 | 黄金利好 |
| TNX 4.35% (+53%) | 名义利率飙升，为唯一显著逆风 | 风险压制 |

**核心矛盾**：名义利率暴涨但实际利率下降 → 通胀预期上升而非紧缩驱动。这恰好是黄金的最佳宏观环境（弱美元 + 负实际利率），但对高估值成长股构成压力。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位98%，估值偏高
  - RSI 69.29接近超买但未突破70
  - MA20与MA120差3.92%，趋势动能不足
ONE_LINER: 在range_bound区间顶部，RSI逼近超买区且估值极高，缺乏明确趋势信号，价格面临回调压力，支撑位看MA120（48.01），阻力位在当前高点附近。

### Risk Officer
SIGNAL: ok  
STRENGTH: 0  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下无持仓数据，无法评估；建议建仓比例上限参考行业标准（≤25-35%）。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-04 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-01-29
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-29",
  "vix": 16.88,
  "tnx": 4.227,
  "usdcny": 6.9545,
  "audcny": 4.8957
}
```

---

## CIO Memo (Round 3)

```
VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000

TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 30000
  add_levels:
    - "价格跌至52.00（接近MA250支撑51.91）→ 加仓20000"
    - "价格跌破50.00（破MA250后惯性下探）→ 加仓20000"

RISK_PLAN:
  stop_loss_trigger: "收盘价跌破48.00（MA250下方7%）同时VIX升破22 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 当前回测模式，假设中性持仓状态，无法精确还原实际仓位与浮盈浮亏
  - 本次建议占假设子弹的5%作为试探仓，属于轻仓试探性质
  - 核心矛盾：RSI 31.45超卖与2年分位82%偏贵并存，不宜激进但也不应完全错过超卖反弹机会——以MA250（51.91）为核心锚点，守住则底仓有效，跌破则果断止损
  - uptrend怀不适用（当前为range_bound），但需注意：估值仍在高位，本次是"博反弹"而非"追趋势"，心理上要接受可能买在半山腰，用止损纪律替代择时精度
```


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 美债名义收益率单月飙升6.6%，对估值敏感型资产形成压力
KEY_TAILWIND: 美元指数暴跌近9%+实际利率大幅回落，形成黄金/商品双击顺风
ONE_LINER: 美元走弱+实际利率下行主导叙事，宏观环境偏暖，组合可维持偏积极配置
```

**补充说明**：
- **VIX 16.88 且持续回落** → 市场恐慌消退，risk-on 基调确认
- **DXY 96.28（月跌8.8%）** → 弱美元周期启动，利好大宗商品与黄金
- **TIP 月涨+11.6%** → 实际利率快速下行，黄金核心驱动力转正
- **TNX 4.23% 走高** → 名义利率仍在攀升，但被实际利率下行对冲，关注是否形成"利率困惑"区间

**结论**：当前宏观组合（弱美元 + 实际利率下行）对商品/黄金类资产最为友好；名义利率上升是唯一逆风，但尚未突破临界值。整体评分正值，倾向维持或小幅加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年分位82%偏高但RSI 31.45近超卖，高位估值与短期超卖形成矛盾
  - 价格54.23跌破MA20(55.68)与MA120(55.58)，短期偏弱；MA250(51.91)距现价4.46%提供底部支撑
  - 30日回报-4.42%，1周-1.53%，回落态势未止；RVOL 1.07正常，无恐慌放量
ONE_LINER: range_bound下高分位与超卖RSI对冲，价格夹在MA250支撑(51.91)与MA120阻力(55.58)之间，信号中性等待方向突破。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下风险数据不可用，无法评估实际仓位压力与流动性，需基于技术/宏观信号谨慎决策。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-29 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-11-27
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.80)
**Dominant view**: macro
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-27",
  "vix": 17.19,
  "tnx": 3.998,
  "usdcny": 7.0758,
  "audcny": 4.6163
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.8
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - “if price drops 5% to ~51.25 → add ¥5000”
    - “if price drops 10% to ~48.7 → add ¥10000”

RISK_PLAN:
  stop_loss_trigger: “价格跌破 MA120 支撑线（约53.95）同时 ^VIX 突破 20 → 减仓 50%”
  what_if_wrong:
    worst_case_pnl_cny: -1500
    recovery_estimate: “2-4个月，受益于宏观 risk_on 环境支撑”

PERSONAL_NOTE:
  - 回测模式假设持仓中性，无集中度或浮亏压力。
  - 本次建仓金额（¥5000）仅占典型子弹仓位的5%，属于小额试探性建仓。
  - 在 uptrend 中执行 ACCUMULATE，纪律高于预测：当前价格偏离 MA120 仅5.64%，低于15%的均值回归警戒线；VIX 处于下降通道（月跌20.7%），并非从低位开始焦虑上升；即便30天后价格回调10%，基于美元走弱与风险偏好回升的宏观核心逻辑依然成立，但会因价格高位而放慢加仓节奏。


---

## Macro Strategist (shared)

**MACRO ASSESSMENT**

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y收益率攀至4%、月涨3%，对久期资产估值构成温和压力。
KEY_TAILWIND: 美元跌破100（月跌4.5%）+实际利率大幅回落（TIP月涨13.6%），黄金/商品迎"双击"窗口。
ONE_LINER: VIX回落至17、美元弱势确立，宏观环境偏暖，风险资产可适度加仓；黄金类资产获得强劲货币面支撑。
```

---

**核心逻辑拆解**：

| 指标 | 读数 | 信号 |
|------|------|------|
| VIX 17.19 (↓20.7%) | 恐慌快速消退 | ✅ risk_on |
| DXY 99.6 (↓4.5%) | 美元失守100关口 | ✅ 黄金利好 |
| TIP +13.6% | 实际利率断崖式下行 | ✅ 黄金强利好 |
| TNX 4.0% (↑3%) | 名义利率温和走升 | ⚠️ 唯一逆风 |

**结论**：美元走弱 + 实际利率下行形成黄金"双击"组合，宏观面明确利好商品/黄金类资产。名义利率上行是唯一瑕疵，但被其他因素充分对冲。整体 **risk_on** 环境，偏向加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 5
KEY_DATA:
  - RSI(14) 51.93 中性，未超买
  - 价格2年分位 97% 历史高位
  - MA20高于MA120 5.79%，趋势维持，偏离MA120仅5.64%
ONE_LINER: 上升趋势中RSI中性且未严重偏离均线，但高位分位97%抑制强度，支撑53.95 (MA120)，阻力57.07 (MA20)

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式)
ONE_LINER: 回测模式下无具体持仓数据，风险评估基于中性假设，无异常信号。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-27 > cutoff 2024-12-31)

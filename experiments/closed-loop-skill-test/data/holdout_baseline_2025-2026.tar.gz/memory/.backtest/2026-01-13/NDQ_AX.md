# Committee: NDQ.AX

**Date**: 2026-01-13
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-13",
  "vix": 15.98,
  "tnx": 4.171,
  "usdcny": 6.9731,
  "audcny": 4.6771
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 5000
  add_levels:
    - "价格跌至 MA120 附近（约 ¥55.34）且 RSI < 45 → 加 ¥5,000"
    - "价格跌破 MA120 约 3%（约 ¥53.7）且成交量放大 → 加 ¥5,000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 MA120 约 5%（约 ¥52.6）同时成交量持续放大 → 减仓 50%；若 10Y 收益率月升继续超 10% 且美元反弹 → 暂停加仓"
  what_if_wrong:
    worst_case_pnl_cny: -3000
    recovery_estimate: "3-6 个月（回测模式下基于历史 range_bound regime 中位回撤幅度估算）"

PERSONAL_NOTE:
  - 当前处于回测模式，持仓上下文中性，无精确浮盈浮亏数据；NDQ.AX 价格处于 2 年分位 93% 的极端高位，意味着任何新增仓位都面临显著的均值回归风险。
  - 本次建议 ¥15,000 占子弹比例较小（约 3%-5% 假设子弹 30-50 万），采用网格而非一次性建仓，本质是"在高位留足子弹、只投试探仓"。
  - **纪律提醒**：Macro risk_on 但 Quant 中性 + 价格 93% 分位 = 方向不明 + 估值偏贵的组合，此时 ACCUMULATE 的核心逻辑是"不踏空但绝不追高"。若 30 天后跌 10%，网格第二档在 MA120 附近接回，整体成本可摊低；但若直接突破新高，仅吃到第一笔 ¥5,000 的利润——这是可接受的不对称回报。MA20 与 MA120 仅差 1.27%，均线纠缠状态下不押注方向突破，等信号明确再加码。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: +2
KEY_HEADWIND: 10Y收益率月升9.5%，若持续上行将压制权益估值
KEY_TAILWIND: 美元月跌4.5%+TIP月涨12%，实际利率回落形成黄金/商品双击环境
ONE_LINER: 温和risk_on，宏观环境偏暖但非过热；黄金/商品类可适度加仓，权益维持
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位93%，处于历史高位，均值回归风险较高
  - RSI(14) 53，中性区域，无超买超卖信号
  - MA20与MA120差值仅+1.27%，均线纠缠，趋势不明
ONE_LINER: REGIME为震荡市，价格高位但RSI中性且成交量萎缩，SIGNAL中性，支撑55.34（MA120），阻力需观近期高点突破情况。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，持仓假设中性）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，假设中性集中度；建议单资产占比上限25-35%，实际风险视技术+宏观信号而定。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-13 > cutoff 2024-12-31)

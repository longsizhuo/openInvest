# Committee: NDQ.AX

**Date**: 2025-11-25
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-25",
  "vix": 18.56,
  "tnx": 4.002,
  "usdcny": 7.1022,
  "audcny": 4.5924
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 2000
  add_levels:
    - if price drops 3% from current (approx. 55.5) → add ¥1500
    - if price drops 5% from current (approx. 54.3) → add ¥1500

RISK_PLAN:
  stop_loss_trigger: 价格跌破MA120 (53.82) 同时 ^VIX 升破 22 → 清仓离场
  what_if_wrong:
    worst_case_pnl_cny: -1000
    recovery_estimate: 3-6 个月

PERSONAL_NOTE:
  - 用户处于回测模式，无具体持仓信息，按中性仓位处理。
  - 本次建议建仓金额占潜在子弹比例极小（假设子弹规模≥5万），属于谨慎的试探性仓位。
  - **估值检查**：确定性事实显示价格处于2年分位的96%高位，估值显著偏贵，这是限制乐观的主要依据，必须分批而非一次建满。
  - **Uptrend怀疑清单检查**：1) 价格距MA120 (53.82) 偏离约4%，低于15%的均值回归风险阈值。2) VIX状态未知，但宏观报告未提示近期从低位急升的恐慌信号。3) 若30天后跌10%，高估值下加仓逻辑将受冲击，故当前仅建极小试探仓，并设置明确止损，控制风险敞口。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 名义利率温和上行（TNX MoM +4.35%），制约风险资产估值扩张空间。
KEY_TAILWIND: 美元大幅走弱（DXY MoM -4.65%）叠加实际利率下行（TIP MoM +13%），对黄金/商品形成双击环境。
ONE_LINER: 宏观偏温和risk_on，黄金/商品类可适度加仓；权益类维持观望，关注利率能否企稳。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位96%，估值显著偏高，历史顶部区域
  - RSI 50.55 中性，未提供超买支撑
  - MA20 (57.21) > MA120 (53.82) 但价格已回落至MA20下方
ONE_LINER: 处于两年高位（分位96%），尽管REGIME为上升趋势，但高估值限制上涨空间，短期技术信号偏弱，支撑看MA120 (53.82) 和MA250 (50.87)。

### Risk Officer
```json
{
  "SIGNAL": "ok",
  "STRENGTH": 0,
  "CONCENTRATION_PCT": "N/A",
  "DRY_POWDER_CNY": "N/A",
  "PNL_PCT": "N/A",
  "WORST_CASE_LOSS_PCT_AT_-20": "N/A",
  "ONE_LINER": "回测模式下无具体持仓数据，无法评估实际风险。建议常规建仓比例上限30%。"
}
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-25 > cutoff 2024-12-31)

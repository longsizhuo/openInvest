# Committee: NDQ.AX

**Date**: 2025-03-26
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-26",
  "vix": 18.33,
  "tnx": 4.338,
  "usdcny": 7.2569,
  "audcny": 4.5769
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂无建仓计划，等待信号明确"

RISK_PLAN:
  stop_loss_trigger: "回测模式无持仓，不适用止损；若后续建仓，建议设 MA250(44.98) 跌破 + VIX > 22 为防御线"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "N/A"

PERSONAL_NOTE:
  - 回测模式下假设持仓中性，无实际仓位可供操作，本次裁决基于技术+宏观信号判断。
  - 价格2年分位87%处于高位，MA20(46.91)低于MA120(48.14)表明短期动能弱于中期均值，均值回归压力存在；RSI 48.70中性，无超买但也无超卖反弹信号。
  - 宏观面利空利多对冲：10Y收益率月飙+51.5%（金融条件急剧收紧）是实质压力，但VIX月跌39%至18.33表明恐慌已消退，市场尚未将利率跳升定价为危机——这意味着下一次定价修正可能带来波动。
  - **建议等待**：若要建仓，等价格回踩至MA250(44.98)附近（较现价约-6%）或Quant regime切换至uptrend再行动。当前range-bound+价格高位+利率风暴未消，不适合追高。
```


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y国债收益率月飙+51.5%，金融条件急剧收紧，叠加美元走强+实际利率上行，黄金/商品承压双杀。
KEY_TAILWIND: VIX跌回18.33（月跌39%），恐慌情绪快速消退，市场对收益率跳升尚未定价为危机。
ONE_LINER: 利率风暴与恐慌退潮对冲，短期倾向维持，不追高也不恐慌减仓；若组合含黄金则需警惕美元+实际利率双压。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位87%高位，接近历史峰值
  - RSI 48.70中性，无超买压力
  - MA20(46.91)<MA120(48.14)均线纠缠，趋势不明
ONE_LINER: range-bound regime下价格高位震荡，SIGNAL neutral因RSI中性且均线无方向，阻力MA120(48.14)支撑MA250(44.98)。

### Risk Officer
SIGNAL: ok  
STRENGTH: 0  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下无具体持仓数据，假设持仓中性，建议建仓比例上限不超过总资产的30%以控制集中度风险。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-26 > cutoff 2024-12-31)

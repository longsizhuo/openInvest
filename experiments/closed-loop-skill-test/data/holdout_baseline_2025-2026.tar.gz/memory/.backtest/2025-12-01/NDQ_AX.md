# Committee: NDQ.AX

**Date**: 2025-12-01
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.68)
**Dominant view**: quant
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-01",
  "vix": 17.24,
  "tnx": 4.096,
  "usdcny": 7.0751,
  "audcny": 4.6352
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.68
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "若价格回落至54.08（支撑位）附近 → 加仓¥10,000"
    - "若价格回落至52.50（支撑位下方约3%）→ 加仓¥10,000"

RISK_PLAN:
  stop_loss_trigger: "跌破52.00（支撑位下方约4%）且VIX突破22 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -4500
    recovery_estimate: "2-4个月（上升趋势中回调通常浅而快）"

PERSONAL_NOTE:
  - 回测模式无持仓数据，假设现金充裕、无集中度约束；当前价格处于2年95%分位，历史高位区域。
  - 本次建议¥30,000约占总子弹的5-10%试探仓位，分三档金字塔建仓，保留大部分子弹等待更好价位。
  - 上升趋势倾向继续，但价格95%分位+10Y收益率月涨10%构成估值双压，务必纪律执行分批建仓而非一次性追高。MA120偏离仅4.85%，均值回归风险暂低；VIX从26回落至17而非从低位抬升，短期情绪未恶化——但若VIX重新走高至22以上需立即执行止损线。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: 3
KEY_HEADWIND: 10Y国债收益率4.10%且月涨10%，高利率环境仍压制估值。
KEY_TAILWIND: DXY跌破99.5且TIP月涨12.4%——美元走弱+实际利率下行，对黄金/商品形成双击利好。
ONE_LINER: VIX从26回落至17恐慌消退，美元与实际利率同步走软，宏观环境偏暖，组合可适度加仓，尤其利好黄金敞口。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格离MA120偏离度4.85%，均值回归风险低
  - RSI 49.80中性，未进入超买区（衰竭检查无红灯）
  - 价格2年分位95%历史高位，估值偏高
ONE_LINER: 上升趋势未衰竭但价格高位，SIGNAL bullish与REGIME uptrend一致，支撑54.08阻力56.92。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，风险中性假设。若实盘，建议单资产建仓比例上限25%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-01 > cutoff 2024-12-31)

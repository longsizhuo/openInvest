# Committee: NDQ.AX

**Date**: 2025-04-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-10",
  "vix": 40.72,
  "tnx": 4.394,
  "usdcny": 7.35,
  "audcny": 4.5086
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.5
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "不建新仓——宏观恐慌指数破40 + 10Y收益率单月暴涨50%，流动性急剧收紧，任何加仓等同于接飞刀"
    - "若 VIX 回落至 25 以下且 10Y 收益率企稳，可重新评估试探仓（届时再出 ACCUMULATE 计划）"

RISK_PLAN:
  stop_loss_trigger: "若现有持仓浮亏扩大至 -8%，或 VIX 持续 >40 超过 5 个交易日且 ^NDX 跌破 MA250 (≈45.13) → 考虑减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: "回测模式无持仓明细，按中性仓位假设：若持有约¥50,000 标的，最坏情景（再跌 15-20%）浮亏约 ¥7,500-10,000"
    recovery_estimate: "宏观极端恐慌阶段（VIX>40），历史中位恢复周期 4-8 个月；若触发流动性危机可能延长至 12 个月以上"

PERSONAL_NOTE:
  - "回测模式下假设中性持仓，当前 NDQ.AX 处于下降趋势且价格仍居 2 年 79% 分位（偏贵），Quant 确认 MA20 显著低于 MA120 趋势走坏；虽然集中度 lens 已关闭不强制要求减仓，但宏观 strength=9 的 risk_off 信号极端强烈，此时加仓无异于逆大势而行"
  - "本次建议占子弹 0%——不加一分钱，全部子弹留待宏观恐慌消退后再部署"
  - "纪律提醒：VIX 破 40 是近 2 年极值区间，市场正在'定价尾部风险'阶段；此时最忌'抄底冲动'——即便价格看似跌了不少，宏观双杀（股债齐跌+流动性收紧）意味着最坏情景尚未充分反映。保持耐心，等 VIX 回落 + 收益率曲线正常化再考虑入场"


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 9
SCORE: -4
KEY_HEADWIND: VIX飙至40+且10Y收益率单月暴涨50%，市场陷入极端恐慌+债券抛售双杀，流动性急剧收紧。
KEY_TAILWIND: 美元走弱(DXY -3.2%)叠加实际利率下行(TIP涨)，为黄金提供"双击"支撑。
ONE_LINER: 恐慌指数破40、收益率飙升，宏观环境极度恶化——风险资产坚决减仓，黄金可适度对冲持有。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格处于2年历史高位（79%分位），在下降趋势中承压
  - RSI 48.69 中性，未提供反弹动能
  - MA20 (45.06) 显著低于 MA120 (48.16)，确认下降趋势
ONE_LINER: 下降趋势中价格处于历史高位，RSI中性，MA250 (45.13) 提供近支撑，技术面偏空。

### Risk Officer
SIGNAL: ok  
STRENGTH: 2  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 基于持仓中性假设，无极端风险信号，建议建仓比例上限不超过总资产的35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-10 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-04-11
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-11",
  "vix": 37.56,
  "tnx": 4.493,
  "usdcny": 7.314,
  "audcny": 4.5515
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不建仓，等待宏观条件改善"
    - "若 VIX 回落至 25 以下且 10Y 收益率企稳 ≤4.2%，重新评估建试探仓"

RISK_PLAN:
  stop_loss_trigger: "若已持有小仓位，NDQ.AX 跌破 ¥42.0（MA250 下方约 -7%）同时 ^VIX 持续 >40 → 全部止损清仓"
  what_if_wrong:
    worst_case_pnl_cny: 0（未建仓，无浮亏暴露）
    recovery_estimate: "N/A — 当前无仓位，错过上涨的机会成本才是主要风险"

PERSONAL_NOTE:
  - "回测模式无持仓快照，假设用户对 NDQ.AX 无实质仓位；当前 2 年价格分位 75% 偏高，RSI 45.99 中性无超卖反弹信号，不具备左侧抄底条件。"
  - "Macro 端风险信号极强（VIX 37+、10Y 收益率月涨 56% 至 4.49%，股债双杀格局），Quant 确认 downtrend 且价格受制于 MA250（¥45.15），两个维度均无看多理由；Risk Officer 回测模式信号过弱（strength=3），无法提供可靠的风控缓冲确认。"
  - "纪律建议：纳斯达克 100 对长端利率极度敏感，当前 10Y 飙升 + VIX 恐慌是典型的估值压缩环境——不要试图在子弹横飞时接刀。等两个哨兵同时转绿（VIX < 25 + 10Y 收益率不再创新高），再以 5% 子弹试探建仓。DXY 跌破 100 的弱美元是唯一亮点，但不足以对冲利率冲击。"


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: 10Y国债收益率飙至4.49%（近月+56%），长端利率剧烈上行冲击风险资产估值，疑似财政信用担忧。
KEY_TAILWIND: DXY跌破100至99.78（近月-3.5%）叠加实际利率下行（TIP+0.74%），形成黄金双击窗口。
ONE_LINENER: VIX 37+远超恐慌线，股债双杀信号强烈——整体偏向减仓防守，但美元走弱+实际利率下行对黄金/商品类资产形成结构性支撑，可作防御性配置。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 45.99 中性，无超买超卖信号
  - 价格2年分位75%高位，但MA20低于MA120 -6.55%确认下跌趋势
  - 当前价44.32低于MA250(45.15) -1.83%，且RVOL 1.01x无量增突破
ONE_LINER: 下跌趋势中价格高位但RSI中性，近期反弹未突破MA250阻力，趋势未反转前维持中性。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，无持仓数据）
DRY_POWDER_CNY: N/A（回测模式，无账户数据）
PNL_PCT: N/A（回测模式，无成本基础）
WORST_CASE_LOSS_PCT_AT_-20: N/A（无法计算）
ONE_LINER: 回测模式无持仓上下文，假设中性仓位，无 Dreaming 行为模式预警，风险信号中性；建议单次建仓不超过目标仓位的30%，分批进入。
```

**备注**：回测模式下缺乏 portfolio_summary 实际数据，无法执行集中度、子弹、浮盈等定量评估。如需完整风险画像，请提供历史持仓快照。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-11 > cutoff 2024-12-31)

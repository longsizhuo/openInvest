# Committee: NDQ.AX

**Date**: 2025-11-28
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.63)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-28",
  "vix": 16.35,
  "tnx": 4.017,
  "usdcny": 7.0758,
  "audcny": 4.6244
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.63
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "if price drops 3% from current → add ¥5000"
    - "if price drops 6% toward MA120 54.02 → add ¥10000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 MA120 ¥54.02 且 ^VIX > 20 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -2250
    recovery_estimate: "2-4 个月（假设 macro risk_on 环境延续）"

PERSONAL_NOTE:
  - 回测模式中性持仓，RISK 关键数据缺失（仓位/子弹/浮盈均为 N/A），裁决可信度受限
  - 本次建仓 ¥15,000 约占假设子弹 5%，属试探性仓位，留足子弹等待更好机会
  - ⚠️ UPTREND ACCUMULATE 怀疑清单：① MA120 偏离 5.86%（<15% 阈值，暂可接受）；② VIX 月跌 29% 虽恐慌消退，但从高位急跌本身说明波动率正在重置，需观察是否稳在 18 以下；③ 若 30 天后跌 10%，价格回到约 57 附近仍高于 MA120，macro risk_on 基调若不变则加仓逻辑仍成立，但**价格 2 年分位 97% + RVOL 0.54x 量价背离是真实隐患**——这不是"回调买入"的教科书场景，而是"宏观利好与技术面背离"的纠结场景。分批建仓、严守止损是唯一合理姿态。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +3
KEY_HEADWIND: 10Y名义利率月涨5.9%至4.02%，对久期资产估值构成温和压制
KEY_TAILWIND: DXY月跌5.3%+TIP月涨13%，美元走弱叠加实际利率下行，构成黄金/商品双击环境
ONE_LINER: 恐慌消退（VIX暴跌29%）、美元信用松动，宏观情绪偏暖，风险资产可适度加仓，黄金/商品维持偏多配置
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - RSI 53.10 中性，周线RSI 58.5 未超买
  - 价格2年分位97%，历史高位估值偏高
  - MA120偏离度5.86%，但MA20-MA120 spread收窄至5.52%
  - 成交量低迷 RVOL 0.54x，量价背离
ONE_LINER: REGIME上升趋势，但价格高位、量能不足且趋势动能减弱，中性观望，支撑MA120 54.02。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性集中度；NDQ.AX单次建仓建议不超过总资产25-35%，无具体持仓故风险评估为低关注度。
```

**补充说明**：
- 回测模式下无法获取真实 portfolio_summary，所有核心字段（集中度/子弹/浮盈/压力测试）均标记为 N/A
- 未触发任何风险规则（无追涨模式、无极端集中度假设、无负浮盈）
- 若有实际持仓数据，将重新评估集中度阈值（>60% 至少 concerned）及现金流压力


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-28 > cutoff 2024-12-31)

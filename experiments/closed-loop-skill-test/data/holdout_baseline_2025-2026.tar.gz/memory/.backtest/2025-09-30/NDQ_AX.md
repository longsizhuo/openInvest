# Committee: NDQ.AX

**Date**: 2025-09-30
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 40000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-30",
  "vix": 16.28,
  "tnx": 4.148,
  "usdcny": 7.1194,
  "audcny": 4.6835
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 40000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "if price pulls back 5% from current → add ¥15,000"
    - "if price pulls back 10% from current → add ¥10,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 MA120（约-7%以下）且 ^VIX 回升至 20 以上 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -8000
    recovery_estimate: "3-6 个月（基于 uptrend 历史回踩中位恢复周期）"

PERSONAL_NOTE:
  - 回测模式下持仓上下文缺失，Risk Officer 基于中性假设给出 ok 信号但置信度偏低，实际操作需等持仓数据还原后重评；当前假设中性仓位，NDQ.AX 属试探性建仓而非重仓加码。
  - 本次建仓 ¥40,000 仅占子弹试探比例（Risk Officer 建议上限 30% 的 1/3 左右），分三档金字塔式执行，首笔仅 ¥15,000 控制估值追高风险。
  - **uptrend 三项检查**：(1) 价格2年分位 99%，MA20-MA120 价差 +7.03%，价格离长期均线偏离已偏高，均值回归风险不可忽视——这正是我选择 pyramid 而非 lump-sum 的核心原因；(2) VIX 暴跌中（Macro 语），当前并非恐慌上升阶段，而是情绪修复期，回调买入逻辑暂成立；(3) 若 30 天后跌 10%，宏观 risk_on（美元崩塌 + 实际利率下行）的核心逻辑仍有效，但 99 分位估值会放大跌幅，因此首笔控在 15,000 留足后手——**宁可少赚不能深套**。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 8
SCORE: +3
KEY_HEADWIND: 中东地缘冲突升级风险 + 10Y收益率上行对高估值资产的压制。
KEY_TAILWIND: 美元指数月跌13%+实际利率同步下行，黄金/商品迎来"双击"窗口。
ONE_LINER: VIX暴跌+美元崩塌=明确risk_on环境，风险资产可加仓；黄金因DXY与实际利率双降而获得额外顺风。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 7
KEY_DATA:
  - 价格2年分位99%，估值处于历史极端高位
  - RSI 62.69，中性偏强，未进入超买区
  - MA20与MA120上升趋势延续，价差+7.03%
ONE_LINER: 趋势与动能指标支持上涨，但极高分位提示阻力在现价附近，SIGNAL为bullish。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓明细，无法计算集中度/子弹/浮盈；假设中性持仓前提下风险信号暂无异常，建议建仓比例上限30%，实际决策需等待持仓数据还原后重新评估。
```

**补充说明**：当前处于 Backtest Mode，portfolio_summary 未提供 NDQ.AX 具体持仓占比、均价、现价等关键字段。Dreaming 行为模式暂无数据（可能为新用户或历史记录缺失）。风险评估基于"中性持仓"假设，置信度较低——待持仓上下文还原后应重新触发完整评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-30 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-05-12
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-12",
  "vix": 18.39,
  "tnx": 4.457,
  "usdcny": 7.2363,
  "audcny": 4.6475
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.7
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: 无

RISK_PLAN:
  stop_loss_trigger: 若价格跌破 MA250 支撑 ¥45.48 且 VIX 回升突破 20，则启动减仓评估
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 用户持仓假设中性，无极端集中度或浮亏浮盈压力。
  - 本次建议为维持现状，不占用新增资金，子弹保持待命。
  - 市场信号矛盾（趋势向下但恐慌消退），宜耐心等待收益率和趋势方向明确，避免在噪声中频繁操作。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙升至4.46%（月涨+28%），名义利率快速上行压制风险资产估值。
KEY_TAILWIND: VIX暴跌44%至18下方，恐慌情绪快速消退；美元走弱+实际利率下行（DXY 101.8下探，TIP +5%），为黄金/商品提供双击环境。
ONE_LINER: VIX崩塌但收益率飙升，信号矛盾偏中性，维持现有仓位，等待收益率方向明确；黄金类资产宏观背景偏友好（美元弱+实际利率降），可小幅加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - MA20低于MA120 7.23%，确认下降趋势
  - 2年价格分位84%，历史高位估值偏高
  - RSI 60.50中性，未超买且价格高于MA250支撑3%
ONE_LINER: 下降趋势中价格高位但RSI中性，支撑45.48（MA250），阻力47.95（MA120），信号中性因趋势向下但无超买确认。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，风险中性评估，建议维持现有配置，不主动增减仓。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-12 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-01-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.35)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-10",
  "vix": 19.54,
  "tnx": 4.776,
  "usdcny": 7.3321,
  "audcny": 4.5386
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.35
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []
    - 若后续Risk数据恢复且VIX回落至15以下+DXY跌破108 → 可考虑首次试探仓约DRY_POWDER的5%

RISK_PLAN:
  stop_loss_trigger: 若已持有NDQ.AX，价格跌破MA120均线（当前约低于现价10-11%处）或^VIX重新站上25且持续3日 → 减仓50%
  what_if_wrong:
    worst_case_pnl_cny: 0（当前无新增仓位，存量风险由原有持仓承担）
    recovery_estimate: N/A（未建新仓，无需估计解套时间）

PERSONAL_NOTE:
  - Risk Officer全部核心数据缺失（CONCENTRATION_PCT/DRY_POWDER/PNL均为N/A），系统硬约束要求confidence≤0.4的HOLD裁决——这不是"观望偏好"，是数据不足下的纪律性暂停
  - NDQ.AX价格处于2年98%极端分位，叠加Macro risk_off信号（DXY飙至109.65、10Y收益率4.78%），双重紧缩环境对科技股估值形成显著压制；虽然VIX月跌31%至19.5显示恐慌消退，但利率+美元的结构性压力未解除
  - uptrend怀疑清单三问：①价格偏离MA120约11.27%（<15%阈值，尚可）；②VIX从高位回落但仍在19.5附近，不算低波环境；③若30天后跌10%，在risk_off利率环境中解套周期可能长达3-6个月——当前不满足ACCUMULATE的安全边际
  - 操作纪律：在Risk Officer数据恢复前不要因为"怕错过上涨"而强行建仓；极端高位+risk_off环境下，不亏钱比少赚更重要


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 6
SCORE: -3
KEY_HEADWIND: 美元指数飙至109.65且实际利率上行，黄金/商品面临美元+实际利率双杀格局
KEY_TAILWIND: VIX月跌31%至19.5，恐慌情绪快速消退，市场未陷入系统性恐慌
ONE_LINING: 10Y收益率4.78%+DXY破109构成强紧缩环境，建议减仓高久期资产，维持防御配置


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位98%极端高位，均值回归风险升高
  - RSI(14) 55.33中性，无超买但成交量萎缩(RVOL 0.47x)
  - MA20>MA120 +11.57%趋势向上，价格偏离MA120仅11.27%无过大风险
ONE_LINER: REGIME为上升趋势，但价格分位98%高位叠加量能衰减，技术面显示追高风险，SIGNAL neutral应对。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 数据限制，无法进行量化风险评估。请在回测中提供具体持仓数据。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-10 > cutoff 2024-12-31)

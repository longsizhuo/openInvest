# Committee: NDQ.AX

**Date**: 2025-10-06
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-06",
  "vix": 16.37,
  "tnx": 4.162,
  "usdcny": 7.119,
  "audcny": 4.6935
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - "if price drops 3% from current → add ¥5000"
    - "if price drops 7% from current → add ¥5000"

RISK_PLAN:
  stop_loss_trigger: "价格从当前水平下跌10% 且 ^VIX 突破20 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -1500
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户处于回测模式，假设持仓中性，本次为建立初始试探仓位。
  - 建议金额(¥15,000)约占假设子弹的5-8%，符合风险官建议上限，是保守起步。
  - 【uptrend ACCUMULATE检查】1. 价格偏离120日均线9.33% (<15%)，均值回归风险尚可；2. VIX 16.4处低位，未显示从低位开始显著上升；3. 若30天后跌10%，宏观双支柱（弱美元+实际利率降）仍存，小幅加仓逻辑仍在，但已预留大部分子弹应对更深回调。核心纪律：极高的估值分位(100%)要求我们将首次建仓视为“播种”，而非“收割”，后续必须严格按网格执行，不可因恐错过而追高。


---

## Macro Strategist (shared)

**SIGNAL:** risk_on
**STRENGTH:** 8
**SCORE:** +4

**KEY_HEADWIND:** VIX 跌至 16.4 已入"自满区"，短期回调风险隐现。
**KEY_TAILWIND:** 美元指数月跌 11% + 实际利率大幅下行（TIP +14%），黄金/商品获双击支撑。

**ONE_LINER:** 美元崩 + 实际利率降 = 宏观最友好组合，风险资产与黄金均可适度加仓，但警惕 VIX 低位的均值回归。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位100%，历史极值
  - RSI 64.97接近超买，MA120偏离度9.33%
  - 当前处于上升趋势，但估值分位过高
ONE_LINER: 尽管处于上升趋势，但价格在历史绝对高位且RSI偏高，需警惕回调风险，故持中性。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，持仓未还原）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性持仓下不触发集中度/流动性风险，NDQ.AX 单次建议建仓比例上限 10-15% 总资产。
```

**补充说明**：本轮为 Backtest Mode，无 portfolio_summary 可供提取真实持仓数字。Dreaming 亦无历史模式。风险评估基于"中性持仓"假设，**SIGNAL 可能低估真实风险**——建议 CIO 在实盘环境复核。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-06 > cutoff 2024-12-31)

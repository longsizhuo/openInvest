# Committee: NDQ.AX

**Date**: 2025-11-18
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-18",
  "vix": 24.69,
  "tnx": 4.123,
  "usdcny": 7.1075,
  "audcny": 4.6144
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若NDQ.AX跌破MA120支撑53.54且VIX持续高于25，则考虑减仓30%
  what_if_wrong:
    worst_case_pnl_cny: N/A
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式下假设用户持仓中性（仓位比例约20%-40%），无极端集中度。
  - 本次建议不涉及新增资金，维持现有仓位占比。
  - 宏观风险偏好收缩（利率恐慌+VIX高企）叠加价格处于2年高位，加仓风险大于收益；耐心等待价格回调至MA120支撑53.54附近或宏观信号转暖后再考虑行动。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 5
SCORE: -2
KEY_HEADWIND: 10Y收益率飙升+12%叠加VIX突破24，利率恐慌与避险情绪共振压制风险资产。
KEY_TAILWIND: 美元指数月跌4.6%叠加实际利率大幅回落，黄金/商品类资产获双重货币顺风。
ONE_LINER: 利率波动主导风险偏好收缩，整体偏防御；黄金/商品有独立alpha，可维持但不宜追高风险资产。
```

**补充说明**：当前宏观图谱呈现"利率恐慌+美元走弱"的罕见组合——VIX与TNX同步飙升通常反映市场对财政赤字或通胀粘性的深层忧虑，而非单纯加息预期。DXY与TIP的背离方向（美元跌+实际利率降）为黄金/大宗商品提供强支撑，但对权益类资产而言，收益率波动率本身就是最大敌人。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格分位95%，2年高位，估值偏高
  - RSI 42.31，中性偏弱，低于50
  - 价格低于MA20(57.54)，短期趋势转弱
ONE_LINER: 在上升趋势REGIME中，但价格处于2年高位且RSI回落，短期面临回调，支撑MA120@53.54，阻力MA20@57.54，故SIGNAL neutral。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 1
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓明细，无法评估集中度/浮盈/子弹；假设中性持仓前提下，风险维度无异常，建议建仓比例上限 25%（常规单一资产上限）。
```

**备注**：本次为历史回测，portfolio_summary 未提供，所有财务指标标记 N/A。Risk Officer 维度在回测模式下依赖技术+宏观信号决策，无持仓数据时无法执行压力测试与集中度监控。如需完整风险评估，需提供真实持仓快照。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-18 > cutoff 2024-12-31)

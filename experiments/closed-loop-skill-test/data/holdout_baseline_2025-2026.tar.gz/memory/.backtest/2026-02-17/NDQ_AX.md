# Committee: NDQ.AX

**Date**: 2026-02-17
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-17",
  "vix": 20.29,
  "tnx": 4.052,
  "usdcny": 6.908,
  "audcny": 4.8853
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 20000
  add_levels:
    - "if price drops 3% from entry (approx. ¥49.6) → add ¥10,000"
    - "if price drops 5% from entry (approx. ¥48.6) → add ¥20,000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 ¥50.50 同时 ^VIX > 22 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6 个月"

PERSONAL_NOTE:
  - 回测模式下假设持仓中性，当前无明确多头或空头优势。
  - 本次建议金额约为子弹的5%，属于小额试探性建仓，为区间震荡做准备。
  - 当前RSI超卖但价格分位偏高，宏观利率逆风未消，在支撑位附近轻仓试探需保持耐心，等待价格明确突破区间上下沿再决定大动作。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y美债收益率单月飙升12%至4.05%，高利率持续压制风险资产估值
KEY_TAILWIND: 美元单月暴跌5.2%叠加实际利率下行，为黄金/商品形成罕见双击环境
ONE_LINER: 宏观信号中性偏暖——债市偏紧vs美元走弱相互对冲，黄金逻辑清晰但风险资产需等待利率拐点，建议维持现有仓位。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 3  
KEY_DATA:  
  - RSI 27.93 超卖，但价位分位68%未达bearish阈值（≥70%且RSI>70）  
  - 价格低于MA250（51.99）但量缩（RVOL 0.69x），无量增确认跌破  
  - MA20（53.39）低于MA120（55.48），无上升趋势支撑bullish条件  
ONE_LINER: REGIME为区间震荡，当前价格51.19接近支撑位51.99但RSI超卖，分位偏高限制上行，SIGNAL为neutral，需观察突破方向。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式无精确持仓数据，假设中性）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A（缺持仓明细无法计算）
ONE_LINER: 回测模式无持仓明细，假设中性集中度，风险维度暂缓升级；单资产建议建仓比例上限25-30%，待实盘数据到位后重新评估。
```

**说明**：Backtest Mode 下 portfolio_summary 未提供具体持仓、均价、现价及集中度数据，所有数值字段标注 N/A。按假设"中性持仓"给予 SIGNAL=ok，STR=3（低关注度）。若实盘数据回传，将立即重算集中度压力测试及止损阈值。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-17 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-08-28
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.70)
**Dominant view**: macro
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-28",
  "vix": 14.43,
  "tnx": 4.207,
  "usdcny": 7.153,
  "audcny": 4.658
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.7
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "if price drops 3% → add ¥10000"
    - "if price drops 7% → add ¥10000"

RISK_PLAN:
  stop_loss_trigger: "跌破¥48.78（Quant支撑位）同时VIX > 20 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -3000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 当前处于回测模式，持仓数据缺失，假设仓位较低，需谨慎建仓。
  - 本次建仓金额约占默认子弹的5%~10%（假设子弹为30-50万），作为试探仓位。
  - uptrend中ACCUMULATE怀疑清单检查：1) MA120偏离度8.94%<15%，均值回归风险可控；2) Macro提及VIX低位恐慌消散，未见VIX从低位上升的明确信号；3) 若30天后跌10%，宏观risk_on逻辑可能被削弱，但弱美元+实际利率下行组合若持续，回调后仍可加仓，故小仓位试探合理。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 10Y国债收益率月涨10.6%，名义利率上行仍压制估值敏感型资产
KEY_TAILWIND: 美元指数月跌11%+实际利率暴跌14.5%，黄金/商品迎来罕见"双击"窗口
ONE_LINER: 弱美元+实际利率下行构成强组合，VIX低位恐慌消散，维持偏积极仓位
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位97%，处于2年高位，估值偏高，均值回归风险大
  - RSI 52.97中性，无超买或超卖信号
  - MA120偏离度8.94%<15%，趋势支撑仍在但价格极端
ONE_LINER: 上升趋势中但价格处于历史高位，RSI中性无动量，SIGNAL为neutral，需等待回调至支撑48.78或突破确认。

### Risk Officer
SIGNAL: ok  
STRENGTH: 1  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式下持仓数据缺失，建议建仓比例上限25%，控制单一资产风险。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-28 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-01-23
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: risk
**Suggested allocation CNY**: 8000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-23",
  "vix": 16.09,
  "tnx": 4.239,
  "usdcny": 6.9726,
  "audcny": 4.7693
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 8000

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 4000
  add_levels:
    - "若价格回落至¥51.8（MA250支撑附近）再加仓¥2000"
    - "若价格进一步跌至¥50.0以下，加仓¥2000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破关键支撑¥50.0，或宏观信号转为明确risk_off时减仓"
  what_if_wrong:
    worst_case_pnl_cny: -1200
    recovery_estimate: "3-6个月（若整体市场反弹）"

PERSONAL_NOTE:
  - 当前为回测模式，假设持仓中性，无精确仓位数据，建议基于此进行模拟操作。
  - 本次建议建仓金额（¥8000）占预估总子弹的比例较小，属于试探性仓位，旨在控制风险。
  - 当前技术面显示震荡格局，价格处于高位分位（84%），追高风险较大。采用金字塔分批建仓纪律，首笔小仓试探，保留大部分子弹等待更佳价格，避免在估值偏高时一次性重仓。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 通胀预期抬头（名义利率升但实际利率降），美联储降息路径存不确定性。
KEY_TAILWIND: 美元指数大幅走弱（-6.58% MoM）叠加实际利率下行（TIP +12.6%），黄金/商品获双重顺风。
ONE_LINER: VIX 回落至 16、美元走软，宏观环境偏友好；利率端有杂音但不改大局——维持偏积极仓位，黄金配置窗口仍在。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格位于2年高位（84%分位），估值偏高，限制上行空间。
  - RSI 37.72 偏弱，但未超卖；MA20与MA120几乎重合（+0.64%），趋势信号缺失。
  - 当前价格低于MA120（55.53），短期承压，但高于MA250（51.86）提供支撑。
ONE_LINER: 价格处高位分位（84%）与弱势RSI构成矛盾，在MA纠缠的震荡格局中（REGIME=range_bound），多空信号均不强烈，判定为中性，观察55.53阻力与51.86支撑的区间表现。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A (回测模式，无精确数据)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (无集中度数据)
ONE_LINER: 回测模式假设持仓中性，无极端风险。基于标的高波动性，建议单次建仓比例上限15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-23 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-03-07
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 35000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-07",
  "vix": 23.37,
  "tnx": 4.317,
  "usdcny": 7.2506,
  "audcny": 4.5913
}
```

---

## CIO Memo (Round 3)

```
VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 35000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "if price drops to ¥46.50 (MA120下方约-3%) → add ¥10,000"
    - "if price drops to ¥44.70 (触及MA250支撑) → add ¥10,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 收盘价跌破 ¥44.00 同时 10Y美债收益率突破 4.5% → 全部止损"
  what_if_wrong:
    worst_case_pnl_cny: -8750
    recovery_estimate: "2-4 个月（基于MA250支撑及RSI超卖修复周期）"

PERSONAL_NOTE:
  - 回测模式无真实持仓数据，假设中性仓位；当前无超配/集中度风险，但宏观环境（VIX>20 + 10Y收益率4.3%）构成真实逆风，不宜大举建仓。
  - 首笔¥15,000仅占典型子弹约3-5%，属试探性仓位；保留大部分弹药等待利率见顶信号或价格回踩MA250（¥44.70）再加码。
  - uptrend ACCUMULATE 三项自查：(1) 价格偏离MA120仅-1.53%，未过度延伸，均值回归风险低 ✓；(2) VIX已处>20高位且仍在上升通道，市场焦虑度高，这不是经典的"回调买入"环境 ⚠️；(3) 若30天后再跌10%（≈¥43），RSI将进入极端超卖+触及MA250支撑，ACCUMULATE网格逻辑仍成立但需宏观不再恶化——若10Y突破4.5%则应止损而非加仓 ⚠️。总结：RSI 26.96深度超卖提供短期反弹弹性，但宏观risk_off信号强度为5限制了上行空间，本策略本质是"小仓试错、严守止损"，而非看多宣言。
```


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 5
SCORE: -2
KEY_HEADWIND: 10Y收益率4.3%高企+实际利率上行，美元仍处高位，双杀黄金/商品类资产
KEY_TAILWIND: DXY近期从107回落至104，美元走弱趋势若延续将缓解压力
ONE_LINER: VIX>20叠加收益率飙升，宏观环境偏紧，建议减仓防守、等待利率见顶信号
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 26.96 深度超卖，短期反弹可能
  - 价格2年分位85%历史高位，估值偏高风险
  - MA20>MA120 +4.59%趋势向上，但价格低于MA120偏离-1.53%
ONE_LINER: 价格在上升趋势中回调至MA120（47.77）附近，RSI超卖提供支撑，但高位分位限制上行，支撑MA250（44.70）阻力MA120，建议中性观望。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，假设中性持仓）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无真实持仓数据，假设中性仓位无极端集中风险；风险评估依赖 Quant/Macro 信号，无需减仓动作。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-07 > cutoff 2024-12-31)

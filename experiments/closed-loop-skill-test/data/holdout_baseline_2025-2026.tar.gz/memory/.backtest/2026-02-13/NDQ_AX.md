# Committee: NDQ.AX

**Date**: 2026-02-13
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-13",
  "vix": 20.6,
  "tnx": 4.056,
  "usdcny": 6.9001,
  "audcny": 4.8903
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不建仓，等待技术结构改善"
    - "若RSI回升至40+且重新站上MA250（≈¥52）→可试探性建仓5%子弹"

RISK_PLAN:
  stop_loss_trigger: "若已持有底仓：跌破前低同时VIX升破25 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "不建仓则无浮亏；若后续建仓后继续下行，参照30日回报-8.19%的速率，解套周期约2-4个月"

PERSONAL_NOTE:
  - 回测模式无实际持仓数据，假设持仓中性，当前无集中度或流动性压力信号
  - Macro环境虽risk_on（美元月跌5.3%+实际利率下行），但10Y收益率月飙涨16.5%至4.06%——这对NDQ这类科技成长型ETF是**直接利空**：高利率压缩久期资产估值，宏观暖风更多惠及贵金属/商品而非科技股
  - Quant给出range_bound+bearish：RSI 28超卖但价格2年分位仍在70%高位（估值偏贵），且已跌破MA250（¥51.99），MA20<MA120确认短中期趋势向下，30日回报-8.19%显示动能恶化。RSI超卖仅意味着"短期可能有技术反弹"，不构成建仓理由——range+bearish regime下反弹大概率是sell-the-rally
  - 三方分歧点：Macro偏暖（risk_on）vs Quant偏冷（bearish），Risk中性不倒向任何一方。核心矛盾在于宏观的"美元走弱利好"被"长端利率飙升利空"完全抵消，且后者的直接杀伤对象恰恰是NDQ。Quant的技术结构更具体、更直接，应赋予更高权重
  - 鉴于集中度lens已关闭，不以超配为由做决策；纯粹基于"技术破位+利率逆风"选择观望。等RSI从超卖区修复+价格重回MA250上方后再考虑入场，避免在下跌趋势中接飞刀


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: +2
KEY_HEADWIND: 10Y收益率月涨16.5%至4.06%，高利率环境持续压制风险资产估值。
KEY_TAILWIND: 美元指数月跌5.3%+实际利率大幅下行，黄金/商品迎"双击"顺风。
ONE_LINER: 美元走弱+实际利率回落主导，宏观环境偏暖，可小幅加仓黄金及商品敞口，但留意长端利率反弹风险。
```

**补充说明**：VIX已从恐慌区回落至20.6，市场情绪改善；但TNX月涨16%显示债券市场对通胀/财政赤字仍有担忧。当前格局是"利率上行压力 vs 美元下行支撑"的拉锯——后者暂占上风，尤其利好贵金属板块。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - RSI 28.01 超卖但价格2年分位70%高位
  - 价格跌破MA250 51.99（偏离-1.22%），相对成交量1.92倍量增
  - MA20 53.85 < MA120 55.52，趋势向下，30日回报-8.19%
ONE_LINER: 在range_bound regime中，bearish信号由高位分位和跌破MA250驱动，阻力位51.99，支撑位关注近期低点。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A (回测模式无持仓数据)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A (需实际持仓规模)

ONE_LINER: 回测模式下无实际持仓数据，假设中性持仓，无集中度/追涨/流动性风险信号；建议NDQ.AX单一建仓占总资产≤25-30%，具体风险待实盘持仓数据补齐后重新评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-13 > cutoff 2024-12-31)

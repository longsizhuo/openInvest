# Committee: NDQ.AX

**Date**: 2025-06-06
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-06",
  "vix": 16.77,
  "tnx": 4.51,
  "usdcny": 7.175,
  "audcny": 4.671
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "价格回落至MA120（约48.09，当前约49.6）附近 → 加仓 ¥10,000"
    - "价格跌破MA120至47.0以下（约-5%）→ 加仓 ¥5,000 完成建仓"

RISK_PLAN:
  stop_loss_trigger: "收盘价跌破 MA250（约46.6）且 VIX 回升突破 20 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -4500
    recovery_estimate: "2-4个月（range_bound 区间内均值回归周期）"

PERSONAL_NOTE:
  - 当前处于回测模式，无实际持仓数据，假设中性仓位状态；NDQ.AX 价格处于2年分位88%高位，RSI 58.72尚不过热，但追高成本不低
  - 本次建议金额占典型子弹规模的较小比例（约3%-5%），仅为试探性建仓，核心逻辑是宏观risk_on共振（VIX回落+美元破百+实际利率下行）提供了短期风险偏好支撑
  - range_bound + 高分位 = 不要一次买满，用金字塔分批在区间内低吸；Quant中性信号意味着趋势尚未确认，耐心等待MA120支撑位回踩确认再加码比追当前价位更优


---

## Macro Strategist (shared)

**宏观环境评估**

VIX 已从近期 22+ 快速回落至 16.77，恐慌情绪显著消退；DXY 跌破 100 至 99.19（月跌 8.6%），美元走弱明显；TIP 月涨 4.4% 意味着实际利率持续下行。三者共振构成风险偏好改善环境。但 TNX 仍在 4.51% 高位震荡，名义利率偏高压制长久期资产估值。黄金方面：**DXY 弱势 + 实际利率下行 = 双击格局**。

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y美债收益率4.51%高位未解，名义利率压力持续压制风险资产估值
KEY_TAILWIND: VIX急跌+美元跌破100+实际利率下行，三因子共振提振风险偏好与黄金
ONE_LINER: 宏观偏暖但利率隐忧未消，维持现有仓位，商品/黄金类可小幅加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位88%，处于历史高位
  - RSI 58.72中性，未超买
  - MA20与MA120纠缠（差距+1.01%），无明确趋势
  - 价格高于MA250偏离6.52%
ONE_LINER: 在range_bound REGIME下，价格高位但RSI未超买且均线纠缠，信号中性，支撑MA120 48.09，阻力需观察能否突破当前高位。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式无持仓数据)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无持仓明细，假设中性持仓；风险维度无红灯，建议单次加仓不超总资产10%，持续追踪集中度。
```

**说明**：本次评估处于 Backtest Mode，持仓、现金、浮盈等 portfolio_summary 字段均未提供，无法计算真实集中度与压力测试。Dreaming 行为模式为空，无历史追涨警示。风险评估依赖 Quant/Macro 信号，持仓层面暂报 N/A，待实盘数据接入后补齐。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-06 > cutoff 2024-12-31)

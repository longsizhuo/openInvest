# Committee: NDQ.AX

**Date**: 2025-01-21
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-21",
  "vix": 15.06,
  "tnx": 4.574,
  "usdcny": 7.3133,
  "audcny": 4.5933
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 价格跌破MA120（45.55）且RSI低于40 → 考虑减仓
  what_if_wrong:
    worst_case_pnl_cny: 20000 （基于假设持仓10万元，若从历史高位回调20%）
    recovery_estimate: 3-6个月

PERSONAL_NOTE:
  - 回测模式下，假设用户持仓中性，无极端集中度。
  - 本次建议为HOLD，不新增仓位，操作占比0%。
  - 价格处于2年历史极端高位（99%分位），虽处上升趋势但短期回调概率上升；Macro环境利率高企且强美元压制风险资产，VIX虽跌至15但可能隐含自满情绪，不宜追高，建议耐心等待回调至支撑位（MA120附近）再考虑分批布局。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率飙升至4.57%叠加美元指数破108，美元走强+实际利率上行构成黄金双杀环境
KEY_TAILWIND: VIX暴跌51%至15，恐慌情绪快速消退，短期风险偏好回暖
ONE_LINER: 利率风暴暂歇但美元与实际利率双杀未解，黄金/商品类资产面临持续逆风，风险资产可维持但不宜追高加仓
```

**补充说明**：

| 维度 | 判断 |
|------|------|
| 利率 | TNX 4.57%处于高位，紧缩预期仍在压制长久期资产 |
| 美元 | DXY 108+且月涨11%，强美元压制全球资产 |
| 实际利率 | TIP月跌3.7%，实际利率上行→黄金核心利空 |
| 恐慌 | VIX 15已进入complacency区间，短期无忧但警惕突变 |
| 地缘 | 数据未提供，暂中性 |

**货币因素（黄金/商品关键）**：DXY上行 + 实际利率上行 = **双杀格局**，对黄金形成持续压制，短期内无逆转信号。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位99%，历史极端高位，估值偏高风险显著
  - RSI 56.81，中性偏强，未超买但无强烈动量
  - 价格离MA120偏离度11.04%，低于15%阈值，均值回归风险暂时可控
ONE_LINER: REGIME为uptrend，但价格处历史高位分位，RSI中性，短期回调概率上升，信号中性，支撑关注MA120 45.55。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无具体持仓数据，风险评估基于中性假设，无当前集中度、子弹或盈亏信息。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-21 > cutoff 2024-12-31)

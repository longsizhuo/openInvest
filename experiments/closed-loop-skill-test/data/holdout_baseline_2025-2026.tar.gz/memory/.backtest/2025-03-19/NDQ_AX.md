# Committee: NDQ.AX

**Date**: 2025-03-19
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-03-19",
  "vix": 19.9,
  "tnx": 4.256,
  "usdcny": 7.2273,
  "audcny": 4.5969
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无主动加仓计划；若RSI回升至30以上且TNX回落至4.0%以下，可考虑试探建仓"
    - "若价格跌至MA250（约44.87）下方3%即43.5附近且放量企稳，可小仓试探"

RISK_PLAN:
  stop_loss_trigger: "价格跌破MA250（44.87）超5%至42.6下方，同时TNX继续上行突破4.5%→清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: 0（当前无持仓，零敞口）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式下无真实持仓数据，假设中性配置；当前NDQ.AX处于区间震荡（range_bound），三方信号一致为中性/可控，不构成明确方向性指引。
  - RSI 21.17严重超卖提示短期技术反弹可能，但价格分位81%处于高位叠加10Y收益率单月暴涨近46%，成长股估值面临双重压制——"超卖"不等于"便宜"，当前不是左侧抄底的安全边际区间。
  - 操作纪律：宁可错过反弹的前10%也不要追在高估值区间；等待RSI修复至40+且收益率曲线企稳后再评估是否转为ACCUMULATE，当前阶段"不动"就是最好的纪律。


---

## Macro Strategist (shared)

**宏观评估**

| 维度 | 信号 |
|------|------|
| TNX 4.26% (+45.9% MoM) | 🔴 收益率暴涨，重新定价降息预期，压制成长股估值 |
| VIX 19.90 (-12.3% MoM) | 🟢 恐慌回落至20下方，风险偏好改善 |
| DXY 103.43 (+2.2% MoM) | 🟡 美元温和走强，对黄金/商品构成逆风 |
| TIP +0.24% MoM | 🟢 实际利率微降，黄金顺风（但力度有限） |

**核心矛盾**：收益率飙升 vs VIX回落——债市在释放鹰派信号，但股市尚未恐慌。

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y收益率单月暴涨近46%，降息预期大幅回撤，风险资产估值承压
KEY_TAILWIND: VIX回落至20下方，市场恐慌情绪消退，风险偏好尚存
ONE_LINER: 收益率飙升主导格局但股市未崩，建议维持现有仓位，暂不加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 21.17 严重超卖，存在技术反弹可能
  - 价格分位81% 高位，估值偏高限制上行空间
  - 价格接近MA250支撑（44.87），偏差仅0.75%
ONE_LINER: 在区间震荡中，超卖RSI与高位分位对冲，价格盘整于MA250支撑附近，维持中性信号。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式)
ONE_LINER: 回测模式无真实持仓数据，假设中性配置下NDQ.AX风险可控；建议实际建仓时单资产占比≤30%以分散美科技股集中风险。
```

**风险说明**：
- 当前为历史回测，无 portfolio_summary 提供实际集中度/浮盈/现金数据
- Dreaming 行为模式暂无，无法识别情绪化追涨倾向
- 假设中性持仓（无极端集中）下，未触发任何高风险条件
- **实际交易时**需关注：NDQ.AX 纯美股科技暴露，汇率+板块双集中，建议配合其他资产对冲


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-03-19 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-02-14
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 35000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-14",
  "vix": 14.77,
  "tnx": 4.472,
  "usdcny": 7.2888,
  "audcny": 4.6051
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 35000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 12000
  add_levels:
    - "价格回踩MA120附近（约¥46.80）或较现价下跌5% → 加仓¥12000"
    - "价格较现价下跌10%且RSI<40 → 加仓¥11000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破MA120（¥46.80）且成交量放大（RVOL>1.2x）→ 减仓50%；或VIX突然升破22同时10Y收益率继续走高 → 减仓全部新建仓位"
  what_if_wrong:
    worst_case_pnl_cny: -7000
    recovery_estimate: "4-8个月（参考QQQ历史从高位回撤10-15%后的中位修复时间）"

PERSONAL_NOTE:
  - "回测模式，假设持仓中性，当前NDQ.AX处于2年100%分位历史极值，RSI 58.88虽未超买但成交量显著萎缩（RVOL 0.53x），上行动能减弱，不宜重仓追高。"
  - "本次建议¥35000约占假设子弹的5-7%，属于试探性建仓，保留大量子弹等待更好的入场点。"
  - "uptrend ACCUMULATE三检：①价格偏离MA120仅9.8%，未超15%阈值，均值回归风险可控；②VIX 14.77仍处低位，未出现从<15急升>18的焦虑信号，但需警惕宏观层面10Y收益率飙升+DXY 106.57的'底层紧张'格局随时可能通过VIX跳升兑现；③若30天后跌10%，uptrend逻辑在历史100%分位+量价背离下确实存在被打脸风险——因此只建小试探仓，严格金字塔加仓纪律，绝不满仓追高。核心纪律：分批、设止损、宁可少赚不可重亏。"


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y收益率飙升+美元强势(DXY 106.57)，实际利率上行形成对黄金/商品双杀压力
KEY_TAILWIND: VIX 14.77低位运行，市场恐慌情绪未爆发，流动性环境仍宽松
ONE_LINER: 利率快速上行压制风险资产估值，美元与实际利率双升对黄金不利，建议维持现有仓位，黄金/商品类倾向谨慎观望
```

**补充说明**：当前环境呈现罕见的"表面平静、底层紧张"格局——VIX低位暗示市场complacency，但10Y收益率月度大幅走升+美元强势上行，债券市场正在释放鹰派信号。这种背离往往不可持续，若VIX突然回升，risk_off可能迅速兑现。黄金方面，DXY走强+实际利率上行是明确双杀结构，短期缺乏做多催化。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 5
KEY_DATA:
  - 价格2年分位100%，估值偏高需谨慎
  - RSI(14) 58.88中性，未进入超买区
  - 价格离MA120偏离9.8%，均值回归风险可控
  - 成交量萎缩RVOL 0.53x，上行动能减弱
ONE_LINER: 上升趋势中RSI中性且偏离度安全，但历史高位分位限制上行空间，支撑MA120 46.80，短期看涨强度有限。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无具体持仓数据，假设持仓中性。根据技术与宏观信号进行评估，风险可控。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-14 > cutoff 2024-12-31)

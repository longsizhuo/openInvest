# Committee: NDQ.AX

**Date**: 2026-01-01
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-01",
  "vix": 14.95,
  "tnx": 4.163,
  "usdcny": 6.9961,
  "audcny": 4.686
}
```

---

## CIO Memo (Round 3)

```
VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 20000
  add_levels:
    - "价格回落至55.5（MA120附近）→ 加 ¥15000"
    - "价格跌破54.5（-3%）→ 加 ¥15000"

RISK_PLAN:
  stop_loss_trigger: "价格连续2日收于MA120（55.07）下方且VIX升破20 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: -15000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 回测模式假设持仓中性，当前无仓位暴露；Quant中性（RSI 45.58，range_bound），Macro偏risk_on但明确警告10Y收益率4.16%持续上行（+17.87% MoM）对科技股估值的压制——这与NDQ高度相关
  - 本次建仓占子弹约5%，防御性试探而非趋势追随
  - 价格2年分位91%意味着已处于历史高位区间，RSI 45.58显示短期无超买，但range_bound格局下高分位本身就是阻力——不追涨，以MA120支撑55.07为锚做网格建仓
  - uptrend ACCUMULATE 检查：①当前regime非uptrend而是range_bound，均值回归风险反而更直接（震荡区间顶部容易回落）；②VIX<15处于低恐慌，但10Y收益率快速上行可能触发科技股杀估值；③如果30天后跌5-8%，在54-55区间仍可视为网格下轨加仓区，逻辑成立——但需严格止损于55下方
```


---

## Macro Strategist (shared)

---

**SIGNAL: risk_on**
**STRENGTH: 6**
**SCORE: +2**

**KEY_HEADWIND:** 10Y国债收益率4.16%持续走高(+17.87% MoM)，压制科技股估值且限制美联储降息空间。

**KEY_TAILWIND:** 美元指数98.28跌至3个月低位附近(-5% MoM)叠加实际利率下行(TIP +10.82%)，黄金获得"双击"式顺风。

**ONE_LINER:** 低恐慌(VIX<15)+弱美元+实际利率下行组合对风险资产温和友好、对黄金非常友好；但收益率上行趋势构成中期隐忧——**整体维持偏加仓倾向，黄金/商品类可积极加仓**。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位91%，估值偏高
  - RSI 45.58，中性无超买超卖
  - MA20 56.42 vs MA120 55.07，spread仅2.45%，趋势微弱
ONE_LINER: 在range_bound震荡格局中，高分位压制上行空间，RSI中性且量缩，SIGNAL neutral，支撑MA120 55.07，阻力57附近。

### Risk Officer
SIGNAL: ok  
STRENGTH: 0  
CONCENTRATION_PCT: N/A  
DRY_POWDER_CNY: N/A  
PNL_PCT: N/A  
WORST_CASE_LOSS_PCT_AT_-20: N/A  
ONE_LINER: 回测模式假设持仓中性，建议建仓比例上限30%


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-01 > cutoff 2024-12-31)

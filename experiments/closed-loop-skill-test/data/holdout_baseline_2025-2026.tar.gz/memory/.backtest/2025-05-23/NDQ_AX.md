# Committee: NDQ.AX

**Date**: 2025-05-23
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-23",
  "vix": 22.29,
  "tnx": 4.509,
  "usdcny": 7.2037,
  "audcny": 4.6179
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若价格跌破关键支撑位45.73（MA250）且VIX升破25，需重新评估持仓
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 用户持仓假设为中性配置，无极端集中度，当前仓位比例未知。
  - 本次建议维持现有仓位，新增配置比例为0%。
  - 估值处于历史高位（2年分位86%），叠加高利率环境，建议保持耐心，等待更明确的趋势信号。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙至4.51%（月涨40%），高利率持续压制风险资产估值。
KEY_TAILWIND: DXY破百至99.11（月跌5.7%）+实际利率下行，黄金获得"双击"货币环境。
ONE_LINER: 维持仓位；利率上行压制风险偏好，但美元走弱+实际利率回落为商品/黄金提供对冲缓冲，非全面risk_off。
```

**补充逻辑**：
- **VIX 22→仍在警戒线上方**，但月跌21%显示恐慌在消退，边际改善
- **TNX 4.51%** 是核心矛盾——若持续攀升将压制成长股，但市场正逐步消化"higher for longer"
- **DXY破100+TIP涨** = 黄金/商品类资产的宏观顺风明确，即使利率高企，货币因素提供支撑
- 整体：**中性偏谨慎**，不激进加仓，但无恐慌减仓必要


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位86%，估值偏高需谨慎
  - RSI 61.84中性偏多，未超买
  - MA20(46.81)<MA120(48.06)，短期趋势弱，价格于MA120附近震荡
ONE_LINER: range_bound下价格高位震荡，RSI中性，支撑MA250 45.73，阻力50附近，SIGNAL为neutral因趋势不明确。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无具体持仓，假设中性配置，风险可控，建议单资产建仓比例上限不超过30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-23 > cutoff 2024-12-31)

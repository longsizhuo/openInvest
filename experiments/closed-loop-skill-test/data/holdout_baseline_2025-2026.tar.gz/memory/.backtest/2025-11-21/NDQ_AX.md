# Committee: NDQ.AX

**Date**: 2025-11-21
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-21",
  "vix": 23.43,
  "tnx": 4.063,
  "usdcny": 7.1075,
  "audcny": 4.5836
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若现有仓位，NDQ.AX 跌破 MA120（约 53.7）且 VIX 持续 > 25 → 考虑减仓 20%；若 VIX 回落至 18 以下且 DXY 继续走弱，可启动小规模试探建仓
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: 按当前 uptrend 格局，若回踩 MA120 后企稳，预计 4-8 周修复

PERSONAL_NOTE:
  - 回测模式无精确持仓数据，假设中性仓位下维持不动。当前 NDQ.AX 处于 2 年 92% 历史高分位，估值明显偏贵，叠加 VIX 23.43 处于警戒区间、10Y 收益率月涨 5.26%，名义利率走高对科技成长股估值形成实质压制——这不是适合大举加仓的环境。
  - Macro 信号分裂（利率+波动率偏紧 vs 美元+实际利率剧松），Quant 信号 neutral（RSI 39.89 偏弱、价格远离前高但已高于 MA120 约 6.8%），Risk 信号 ok 但置信度低（strength=2）。三方无一致看多或看空方向，确定性不足。
  - uptrend 怀疑清单检查：① 价格距 MA120 偏离约 6.8%（<15%），均值回归压力暂可控；② VIX 已升至 23.43，从低位显著走高，市场焦虑情绪正在升温——这不是"回调即买入"的信号；③ 若 30 天后跌 10%，价格将回到 ~51.6（低于 MA120 的 53.7），uptrend 结构将被破坏，加仓理由不成立。综合判断：此时 ACCUMULATE 的风险收益比不合适，HOLD 等待更清晰信号。
  - 关注两个触发条件：一是 VIX 回落至 18 以下 + 价格在 MA120 附近企稳，可启动试探建仓；二是 DXY 持续走弱若传导至资金流入科技股，Quant 信号转 bullish 后再行动。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y收益率月涨5.26%叠加VIX升破23，流动性收紧恐慌压制风险偏好
KEY_TAILWIND: DXY月跌3.52%叠加TIP月涨13%，实际利率崩塌形成黄金双击环境
ONE_LINER: 宏观信号分裂——利率与波动率偏紧但美元与实际利率剧松，风险资产维持仓位不加，黄金方向确认可适度增配
```

**补充判断逻辑：**

| 指标 | 方向 | 含义 |
|------|------|------|
| TNX 4.06% ↑ | ⚠️ | 名义利率走高，压制估值 |
| VIX 23.43 ↑ | ⚠️ | 恐慌情绪升温但未失控 |
| DXY 100.18 ↓↓ | ✅ | 美元显著走弱，利好大宗商品/新兴市场 |
| TIP +13.12% | ✅✅ | 实际利率暴跌，**黄金最强基本面信号** |

**核心矛盾**：名义利率上行（可能是期限溢价回归）与实际利率下行（通胀预期升温或避险买债）同时发生，这是典型的**"不确定性定价"阶段**——市场在为某种风险（地缘？财政？）重新定价，而非简单的risk-on/off。

**资产含义**：黄金/商品面临"双击"（弱美元+低实际利率），但权益资产面临"双压"（高波动+高名义利率）。组合若有黄金敞口，当前宏观基本面对其极为友好。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI(14)=39.89，处于中性偏弱区间，无超买压力
  - 价格处于2年92%历史高分位，估值偏高
  - MA20 (57.37) 高于 MA120 (53.71)，价差+6.83%，趋势仍在但短期价格已回落
ONE_LINER: 尽管REGIME为上升趋势，但RSI偏弱且价格处于历史高位（92%分位），短期动能不足，预计将在高位区域盘整，支撑MA120（53.7），阻力前高区域。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，无法评估集中度/浮盈/子弹；假设中性持仓下风险无异常，建议单资产建仓比例上限30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-21 > cutoff 2024-12-31)

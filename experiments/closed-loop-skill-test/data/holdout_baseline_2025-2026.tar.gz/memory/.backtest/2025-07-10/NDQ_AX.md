# Committee: NDQ.AX

**Date**: 2025-07-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.35)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-10",
  "vix": 15.78,
  "tnx": 4.346,
  "usdcny": 7.18,
  "audcny": 4.6928
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.35
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "回测模式下无真实持仓数据，暂停建仓"

RISK_PLAN:
  stop_loss_trigger: "若已有仓位，MA120支撑位 ¥48.06 为关键防线；跌破该位同时 VIX 升破 20 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无成本均价）
    recovery_estimate: "价格分位 98% 极高，若高位追入后回调 10%，预计 2-4 个月修复"

PERSONAL_NOTE:
  - **Risk Officer 数据不可用**：回测模式下无法获取集中度、现金子弹、持仓浮盈浮亏等关键风控参数，Risk Officer 输出 [WORKER_UNAVAILABLE]，系统强制降级至 HOLD + 低置信度，这是合规底线不可突破
  - **价格分位 98% 是最大警示**：Quant 本身也承认"历史高位分位极高需谨慎"，结合 10Y 国债收益率单月暴涨 50% 至 4.35%（Macro 核心 headwind），名义利率飙升对高估值科技股（NDQ）构成结构性压力，此时追高风险收益比不佳
  - **宏观信号分裂**：美元走弱 + VIX 下行支持风险偏好，但利率冲击未消——这是"观望"而非"进攻"的信号组合；等待生产环境携带真实持仓数据重新评估，届时再决策是否在回调时 ACCUMULATE


---

## Macro Strategist (shared)

根据您提供的数据直接评估：

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y国债收益率单月暴涨50%至4.35%，名义利率飙升压制风险资产估值
KEY_TAILWIND: 美元指数大跌8.35%叠加实际利率下行，形成黄金/商品"双击"格局
ONE_LINER: 宏观信号分化——名义利率飙升但美元+实际利率双弱，风险资产维持观望，黄金/商品配置窗口明确打开，整体维持偏中性但不减仓
```

**要点拆解**：
- **VIX 15.78 且持续下行** → 市场恐慌消退，风险偏好回升，支撑 risk_on 倾向
- **DXY 跌至 97.65 + TIP 上涨** → 美元走弱 + 实际利率下行 = 黄金/大宗商品的货币层面双重利好
- **TNX +50% MoM** → 唯一重大警示信号，名义利率飙升可能反映通胀预期重燃或期限溢价扩张，对股票估值形成压力

**核心判断**：这是一个"分裂"的宏观环境——风险资产（股票）面临利率冲击但恐慌未起；避险/商品资产（黄金）则获得罕见的双击窗口。整体 SCORE 保守给 +1，但若组合含黄金，应视为强烈利好。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格离 MA120 偏离度 6.67% (<15%)，均值回归风险低
  - RSI 67.35 处于 50-70 上升区间，未超买
  - MA20-MA120 稳定在+4.64%，趋势持续但价格分位 98% 极高需谨慎
ONE_LINER: 上升趋势未衰竭，RSI 支持温和看涨，但历史高位分位限制强度，支撑 MA120 48.06，阻力前高。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓明细，假设持仓中性，风险维度无法量化；建议回测完成后以真实持仓数据重新评估集中度与止损位。
```

**说明**：本次为历史回测，Portfolio Summary 未提供实际持仓字段（集中度、现金、成本均价等），Risk Officer 无法执行压力测试与流动性评估。如需完整风控输出，请在生产模式下携带真实持仓上下文重新触发。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-10 > cutoff 2024-12-31)

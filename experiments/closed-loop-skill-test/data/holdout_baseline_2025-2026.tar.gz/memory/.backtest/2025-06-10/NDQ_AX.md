# Committee: NDQ.AX

**Date**: 2025-06-10
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-10",
  "vix": 16.95,
  "tnx": 4.474,
  "usdcny": 7.1802,
  "audcny": 4.6797
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无加仓计划——宏观 risk_off + 价格高位，等待信号改善"

RISK_PLAN:
  stop_loss_trigger: "若现价跌破 MA120（≈48.08）且 10Y 美债收益率继续上行突破 4.6%，减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: 0（回测模式无持仓数据，假设中性仓位）
    recovery_estimate: "若误判——Quant range_bound 突破阻力 50 上行，约 2-4 周可重新评估建仓"

PERSONAL_NOTE:
  - 当前处于回测模式，无真实持仓/子弹数据，Risk Officer 关键指标全部 N/A，决策主要依赖技术面与宏观信号交叉验证。
  - 本轮不建议建仓的核心逻辑：Macro risk_off（强度 6）由 10Y 美债收益率单月飙升 51% 至 4.47% 驱动——这对 NASDAQ/成长股是结构性利空（贴现率抬升压缩久期资产估值），而 Quant 给出的 range_bound + neutral 信号无任何看多支撑，价格 2 年分位 89% 意味着上行空间有限、下行风险不对称。
  - 操作纪律：当前"持币等待"不是零成本（可能踏空），但在 Macro risk_off + Quant neutral + 价格高位的三重约束下，等待的风险收益比优于建仓。若 Quant regime 转为 uptrend 且 10Y 收益率企稳回落至 4.2% 以下，再重新评估 ACCUMULATE。


---

## Macro Strategist (shared)

**SIGNAL: risk_off**
**STRENGTH: 6**
**SCORE: -2**
**KEY_HEADWIND:** 10Y美债收益率月涨51%飙升至4.47%，叠加美元快速走弱，市场正定价美国资产信用风险或通胀重燃预期。
**KEY_TAILWIND:** 美元指数跌至99+实际利率下行，黄金/商品类资产面临罕见"双击"环境。
**ONE_LINER:** 债市剧烈波动主导叙事，VIX回落是假性平静——建议整体减仓风险资产，黄金/商品可维持。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位89%，历史高位，估值偏高
  - RSI 60.60，中性偏强但未超买
  - MA20=48.70与MA120=48.08纠缠，差值仅1.27%，趋势不明确
ONE_LINER: 价格高位震荡，MA纠缠确认range_bound regime，SIGNAL=neutral，支撑48.08，阻力50。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A (回测模式，无持仓数据)
DRY_POWDER_CNY: N/A (回测模式，无持仓数据)
PNL_PCT: N/A (回测模式，无持仓数据)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式，无持仓数据)
ONE_LINER: 回测模式下无持仓数据，无法评估集中度和流动性风险。决策应完全基于技术面与宏观信号。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-10 > cutoff 2024-12-31)

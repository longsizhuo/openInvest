# Committee: NDQ.AX

**Date**: 2026-01-27
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 25000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-27",
  "vix": 16.35,
  "tnx": 4.223,
  "usdcny": 6.9542,
  "audcny": 4.8083
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 25000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "价格回落至MA250附近（约¥51.88）→ 加仓 ¥10,000"
    - "价格跌破MA250至¥50.00附近且RSI<35 → 加仓 ¥5,000 触发最后档"

RISK_PLAN:
  stop_loss_trigger: "价格有效跌破¥50.00（MA250下方约3.5%）同时VIX突破22 → 果断减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -5000
    recovery_estimate: "2-4个月（区间震荡格局下回踩后有支撑）"

PERSONAL_NOTE:
  - 回测模式下持仓数据缺失，基于中性假设执行：无既有仓位暴露，建一个小试探仓等价格回落再加码是合理策略。
  - 首笔¥10,000仅占假设子弹约5%，属于极轻仓试探，即使短期浮亏5%也仅亏¥500，心理压力极小。
  - Quant/核心分歧在于：Macro看美元崩跌+实际利率下行构成风险资产顺风，但Quant指出价格85分位+RSI仅39.64，动量已衰竭。选择偏Macro但用极小仓位+金字塔加仓来对冲Quant的估值警告——如果Macro是对的，试探仓吃到底部利润；如果Quant是对的（回踩支撑），后续两档以更低均价摊薄成本。纪律关键：绝不在当前位置追满仓，价格越接近55.55阻力越要克制。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +2
KEY_HEADWIND: 10Y收益率仍在4.2%上方，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数月跌近8%+实际利率大幅回落，黄金/商品双击窗口打开
ONE_LINER: 美元崩跌+实际利率下行构成罕见黄金顺风期，可适度加仓商品类资产；整体维持偏多配置
```

---

**补充说明（供内部参考）**：

| 指标 | 信号 | 解读 |
|------|------|------|
| VIX 16.35 (-20%) | ✅ 恐慌消退 | 中性偏积极，市场情绪修复 |
| TNX 4.22% (+5.7%) | ⚠️ 名义利率上行 | 但与TIP同涨→**通胀预期抬升**（关税/滞胀叙事） |
| DXY 96.22 (-8%) | 🟢 **重大利好** | 美元走弱是黄金/大宗商品的最强顺风 |
| TIP +12.8% | 🟢 **重大利好** | 实际利率骤降，黄金核心驱动力 |

**核心判断**：名义利率虽上行，但TIP涨幅远超→通胀预期上行主导→"滞胀"叙事升温。美元+实际利率形成黄金**双击**环境，这是近数月来对商品类资产最友好的宏观组合。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位85%，估值偏高
  - RSI 39.64偏弱，低于中性线
  - 价格低于MA120（55.55）但高于MA250（51.88），趋势不明
ONE_LINER: range_bound regime下，价格高位但RSI动量不足，SIGNAL为neutral，预计在支撑51.88和阻力55.55间震荡。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下持仓数据缺失，无法进行量化风险评估；请基于技术/宏观信号独立决策。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-27 > cutoff 2024-12-31)

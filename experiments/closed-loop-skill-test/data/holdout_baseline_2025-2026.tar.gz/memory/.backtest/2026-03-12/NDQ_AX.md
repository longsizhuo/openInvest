# Committee: NDQ.AX

**Date**: 2026-03-12
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-12",
  "vix": 27.29,
  "tnx": 4.273,
  "usdcny": 6.8655,
  "audcny": 4.8939
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不建仓，等待 VIX 回落至 20 以下且 RSI 跌破 30 形成超卖后再考虑试探性入场"
    - "若价格跌至 MA120 下方再 -8%（约对应价格分位 40% 区间），可小仓试探 5% 子弹"

RISK_PLAN:
  stop_loss_trigger: "若已持有底仓：跌破 MA120 -10% 且 VIX 持续 > 30 超过 5 个交易日 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "回测模式无持仓，暂无浮亏；若新入场后最坏情景（VIX 冲击 35+），估计 4-6 个月解套"

PERSONAL_NOTE:
  - 回测模式无精确持仓数据，按中性仓位假设处理；NDQ.AX 当前无明显建仓优势。
  - Macro 策略师给出 risk_off（强度 7/10）是本轮主导信号——VIX 飙升 60% 至 27+ 叠加油价扰动，高久期科技资产（NASDAQ-100）首当其承压。Quant 确认下降趋势（MA20 低于 MA120 达 -6.48%），RSI 41.40 尚未进入超卖区，反弹缺乏量能配合（RVOL 仅 0.45x），说明多头没有意愿抄底。Risk Officer 给 ok 但无具体持仓数据可参考。
  - 三方分歧点：Quant 给 neutral 而非 bearish（未超卖、分位 64% 未到极端低估），Risk 给 ok 而非 high_risk，所以不触发 SELL 条件。但 Macro 的强 risk_off 信号叠加 downtrend regime，使得 ACCUMULATE 的风险收益比不佳——VIX 从低位飙升 60% 不是"回调买入"信号，而是"避险观望"信号。
  - uptrend 怀疑清单检查（虽当前为 downtrend 仍例行参考）：MA20 偏离 MA120 为 -6.48%（低于均线），不存在"偏离>15%追高"风险；但 VIX 已从低位快速攀升至 27+，市场焦虑情绪明确升温，这不是加仓环境。
  - 操作纪律：持币观望期间每涨 1% 确实跑输 1%，但在 VIX > 25 + downtrend 的组合下，"不亏"本身就是跑赢大多数多头。等待 RSI 进入超卖区（<30）或 VIX 回落至 20 以下再行动，届时 5% 子弹试探性建仓。
```


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 7
SCORE: -3
KEY_HEADWIND: VIX飙升60%至27+叠加油价扰动，避险情绪快速升温，高久期资产承压
KEY_TAILWIND: 美元走弱+实际利率下行形成双击，黄金/商品类资产逆势受益
ONE_LINER: 恐慌情绪主导，整体偏向减仓防守；但若持仓含黄金/商品，货币双利好可维持甚至加仓对冲


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 3
KEY_DATA:
  - MA20低于MA120 -6.48%，确认下降趋势；价格分位64%未达极端
  - RSI 41.40中性偏弱，未超卖；价格低于MA250 -2.22%但成交量萎缩(RVOL=0.45x)
  - 30天回报-5.77%，反弹乏力；趋势延续但无量能配合
ONE_LINER: 下降趋势中，价格低于关键均线但分位中位、RSI中性且量缩，SIGNAL neutral以等待更明确信号。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 当前为回测模式，无具体持仓数据。基于中性持仓假设，风险可控。建议单次建仓不超过总资产10%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-12 > cutoff 2024-12-31)

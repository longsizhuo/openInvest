# Committee: NDQ.AX

**Date**: 2025-05-26
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.40)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-26",
  "vix": 22.29,
  "tnx": 4.509,
  "usdcny": 7.2037,
  "audcny": 4.6833
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD  
CONFIDENCE: 0.4  
DOMINANT_VIEW: quant  
SUGGESTED_ALLOC_CNY: 0  
TRIM_REASON: N/A  
REENTRY_PRICE: N/A  
REENTRY_CONDITION: N/A  
EXPECTED_PATH: N/A  

EXECUTION_PLAN:  
  mode: none  
  first_tranche_cny: 0  
  add_levels: N/A  

RISK_PLAN:  
  stop_loss_trigger: 跌破 ¥46.97 (MA20) 且 RSI<40 → 减仓 30%  
  what_if_wrong:  
    worst_case_pnl_cny: N/A（持仓数据缺失，无法精确计算）  
    recovery_estimate: 3-6个月（基于range_bound regime历史平均恢复时间）  

PERSONAL_NOTE:  
  - 用户当前持仓中性，无极端集中度，但Risk Officer报告缺失，整体信号谨慎。  
  - 本次建议维持现状，不操作，保留子弹等待更明确技术或宏观信号。  
  - 操作纪律：市场处于高位震荡（价格2年分位85%），避免追高，关注MA20支撑位和RSI变化，若反弹乏力再考虑减仓。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: 0
KEY_HEADWIND: 10年期美债收益率月内飙涨40%至4.51%，利率环境骤紧压制风险资产估值
KEY_TAILWIND: 美元月跌5.5%+实际利率下行，黄金/商品获货币双击支撑
ONE_LINER: 利率冲击与美元走弱相互对冲，整体中性；黄金类资产获明确利好，权益类维持观望偏谨慎
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位85%高位，历史高位面临阻力
  - RSI 57.87 中性偏多，未进入超买区
  - 价格低于MA120 (48.07)但高于MA20 (46.97)，呈震荡格局
ONE_LINER: 处于区间震荡（REGIME: range_bound）高位，85%历史分位与低于MA120构成阻力，技术上倾向回调整理。

### Risk Officer
<tool_call>
<function=get_recent_committee_verdicts>
<parameter=asset_symbol>NDQ.AX</parameter>
<parameter=n>5</parameter>
</function>
</tool_call>


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-26 > cutoff 2024-12-31)

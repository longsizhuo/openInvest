# Committee: NDQ.AX

**Date**: 2025-12-10
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 35000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-10",
  "vix": 15.77,
  "tnx": 4.164,
  "usdcny": 7.0633,
  "audcny": 4.6899
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 35000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 12000
  add_levels:
    - "价格回踩至 MA120（约 ¥54.52，约-8%）→ 加仓 ¥12,000"
    - "价格再跌5%至 ¥51.8 附近且 RSI < 40 → 加仓 ¥11,000 完成三档建仓"

RISK_PLAN:
  stop_loss_trigger: "价格跌破 ¥50.0（MA120下方约-8%）且 ^VIX 突破 22 → 全部止损清仓"
  what_if_wrong:
    worst_case_pnl_cny: -7000
    recovery_estimate: "3-6个月（基于uptrend回归历史中位数）"

PERSONAL_NOTE:
  - 回测模式无实际持仓数据，假设中性仓位下本次建仓约占子弹 5-7%，属于试探性底仓而非重仓押注
  - Quant 关键矛盾：价格处于2年95%分位（极贵），但MA120偏离仅4.45%、RSI 50.7中性，说明上涨斜率平缓而非陡峭泡沫，均值回归压力暂时有限
  - uptrend 怀疑清单自检：①MA120偏离4.45%远低于15%阈值，均值回归风险低；②VIX 15.77且下降14%，并非从低位反弹的焦虑信号；③若30天后跌10%，95分位买入确实承受压力，但美元走弱+实际利率下行的宏观支撑仍在，解套概率尚可——三项检查通过，但第三项偏勉强，因此仅给小仓位试探而非重仓
  - 名义利率飙升18.6%是估值最大敌人：NDQ为高成长科技ETF，久期长，对利率敏感度高；若10Y收益率继续攀升，即使宏观risk_on也可能跑输价值股
  - 量缩（RVOL 0.65x）+ 近30日零回报 = 市场在观望而非追涨，不急于一次建满，用金字塔分批等回踩确认


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y收益率飙升18.6%（名义利率快速上行压制估值）
KEY_TAILWIND: 美元指数跌至98.8+TIP暴涨11%（实际利率下行+美元走弱=黄金双击环境）
ONE_LINER: 宏观偏中性偏暖，美元走弱与实际利率下行构成风险资产支撑，但名义利率飙升需警惕，维持现有仓位
```

**关键判断逻辑：**

| 因素 | 状态 | 影响 |
|------|------|------|
| VIX 15.77 ↓14% | 恐慌消退 | ✅ risk_on |
| DXY 98.79 ↓3.5% | 美元走弱 | ✅ 利好商品/黄金 |
| TIP +11% | 实际利率大跌 | ✅ 黄金核心利好 |
| TNX 4.16% ↑18.6% | 名义利率飙升 | ⚠️ 估值压力 |

**值得注意**：名义利率大涨但实际利率大跌，意味着**通胀预期快速攀升**——这通常与关税政策/财政扩张预期有关。对黄金构成结构性利好，但对纯权益资产形成边际压力。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位95%，历史高位，估值偏高风险
  - RSI 50.70中性，未超买；MA20高于MA120仅4.01%，价格偏离MA120 4.45%，均值回归风险低
  - RVOL 0.65x量能萎缩，近30日回报-0.0233%动力不足
ONE_LINER: REGIME为uptrend但价格处历史高位、RSI中性且量缩，趋势持续性存疑，SIGNAL neutral，支撑位MA120 54.52。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式无持仓数据)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无portfolio_summary，假设持仓中性下风险可控，建议建仓比例上限30%；无历史行为数据可佐证情绪化模式。
```

---

**Risk Officer 备注**：

本评估基于回测模式假设（中性持仓），**无实际持仓数据支撑**以下关键风险维度：
- ❌ 集中度：无portfolio_summary
- ❌ 子弹/现金：无investable_cash数据
- ❌ 成本基础/浮盈：无均价与现价对比
- ❌ 压力测试：无具体持仓量，无法计算-20%场景损失
- ❌ Dreaming行为模式：暂无历史记录

**建议**：若需完整风险评估，请切换至实盘模式并提供portfolio_summary，或回测框架补充持仓上下文模拟数据。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-10 > cutoff 2024-12-31)

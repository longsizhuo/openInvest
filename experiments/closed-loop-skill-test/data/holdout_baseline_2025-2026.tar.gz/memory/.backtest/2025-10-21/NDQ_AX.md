# Committee: NDQ.AX

**Date**: 2025-10-21
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: quant
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-21",
  "vix": 17.87,
  "tnx": 3.963,
  "usdcny": 7.1195,
  "audcny": 4.6391
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "价格回踩MA20（当前约56.0附近）且RSI回落至55以下 → 加仓¥10,000"
    - "价格触及MA120（51.93）支撑位 → 加仓¥10,000（最后一档，守不住则暂停）"

RISK_PLAN:
  stop_loss_trigger: "收盘跌破MA120（51.93）且连续2日未能收复 → 清仓止损"
  what_if_wrong:
    worst_case_pnl_cny: -6000
    recovery_estimate: "2-4个月（参考uptrend历史回调后恢复中位时间）"

PERSONAL_NOTE:
  - 回测模式无精确持仓数据，假设中性仓位（无极端集中），本次建议约¥30,000，占假设子弹（¥300,000）的10%，属于试探性建仓。
  - **uptrend怀疑清单检查**：①价格离MA120偏离9.69% < 15%，均值回归压力尚可承受；②RSI 67.77尚未超买但逼近上限，需密切观察是否突破70进入超买区；③若30天后跌10%，MA120（51.93）仍为中期趋势支撑，只要守住则回调属于健康回踩，ACCUMULATE逻辑仍成立——但若同时跌破MA120则止损执行。
  - **关键风险提示**：价格处于2年分位100%（历史最高位），这是最大的隐忧。Quant看涨但Macro仅给neutral、强度偏弱（score 2），说明宏观配合度不足。策略上以金字塔分批+严格止损来对冲"追高"风险，绝不一次建满。纪律第一：宁可少赚不追顶。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 6
SCORE: 2
KEY_HEADWIND: 名义利率月度仍处高位(3.96%)，对估值构成温和压制
KEY_TAILWIND: 美元走弱(DXY 98.93, -6.6%) + 实际利率下行(TIP +13.7%)构成双击利好
ONE_LINER: 美元趋势性走弱+实际利率下行，宏观环境偏暖，倾向小幅加仓风险资产，黄金/商品类资产受益明确。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格2年分位100%，历史最高位，估值风险高
  - RSI 67.77，处于50-70区间，未超买但接近上限
  - 价格离MA120偏离度9.69%，均值回归风险中等；MA20>MA120趋势维持
ONE_LINER: 上升趋势中RSI未超买，但价格分位极高，短期看涨信号与REGIME一致，支撑MA120（51.93）需守住。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据，假设中性持仓，当前无特定风险信号；单资产建议建仓比例上限参考 ≤30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-21 > cutoff 2024-12-31)

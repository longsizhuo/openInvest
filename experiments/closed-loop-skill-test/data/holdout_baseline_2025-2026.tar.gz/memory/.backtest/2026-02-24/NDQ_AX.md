# Committee: NDQ.AX

**Date**: 2026-02-24
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-24",
  "vix": 19.55,
  "tnx": 4.033,
  "usdcny": 6.908,
  "audcny": 4.8774
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "暂不建仓，等待信号"

RISK_PLAN:
  stop_loss_trigger: "若已持仓，跌破 MA250 支撑 52.03 且 RSI < 30 → 考虑减仓"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式，持仓假设中性配置，无集中度/子弹/浮盈数据可参考
  - Quant 主导判断：downtrend 确认（MA20 < MA120 约 5%），RSI 37 偏低但未超卖，2 年分位 71% 仍偏贵——技术面缺乏反转信号
  - Macro 给出温和 risk_on（强度 5），但 10Y 收益率月涨 13% 构成估值压制，实际利率回落与名义利率上行形成对冲
  - 当前价格接近 MA250 支撑 52.03，若未来触及 50 附近 + RSI 进入超卖区（<30），将触发 ACCUMULATE 窗口
  - 操作纪律：downtrend 中不抄底是纪律，宁可错过左侧也要等右侧确认（价格站回 MA120 上方 55.44 或 RSI 突破 50 且放量）


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 5
SCORE: +2
KEY_HEADWIND: 10Y国债收益率月涨13%，名义利率上行压制风险资产估值。
KEY_TAILWIND: 美元月跌4.2%叠加实际利率大幅下行，为黄金/商品提供双击。
ONE_LINER: 美元走弱+实际利率回落主导格局，温和risk_on，可小幅加仓但需警惕收益率反弹。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 6
KEY_DATA:
  - RSI 37.39 中性偏低，未超卖区域
  - 价格2年分位71%偏高，但30天回报-7.91%已下跌修正
  - MA20低于MA120 5.15%，下降趋势确认，价格接近MA250支撑
ONE_LINER: 下降趋势中价格已下跌且RSI偏低，但分位仍高缺乏超卖反弹信号，中性等待方向突破，支撑52.03（MA250），阻力55.44（MA120）。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性配置；技术+宏观信号由对应 Officer 独立评估，Risk 维度无结构性风险可标记。
```

**补充说明**：回测模式下 portfolio_summary 未提供，无法计算集中度、子弹、浮盈及压力测试损失。若需完整 Risk 评估，请提供该回测日期的持仓快照数据。Dreaming 长期行为模式暂无记录，不构成情绪化追涨判断依据。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-24 > cutoff 2024-12-31)

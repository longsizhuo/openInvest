# Committee: NDQ.AX

**Date**: 2026-01-20
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-20",
  "vix": 20.09,
  "tnx": 4.295,
  "usdcny": 6.9681,
  "audcny": 4.6754
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若NDQ.AX跌破51.81（MA250）同时VIX升破22，则考虑减仓
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 当前回测模式下假设持仓中性，无极端集中度，NDQ.AX仓位状态未知。
  - 本次建议不新增仓位，维持现状，子弹完全保留。
  - 价格处于2年历史85%高位，估值偏贵，且技术面呈区间震荡，宜保持耐心，等待更明确信号再行动。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y收益率MoM飙升+9.5%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数MoM暴跌6.2%叠加实际利率急降（TIP +12%），黄金双击环境成型
ONE_LINER: 美元走弱+实际利率下行主导，宏观偏友好；名义利率上行是扰动项——整体倾向维持偏积极配置，黄金/商品可适度加仓
```

**判断逻辑**：
- **VIX 20→回落**：恐慌消退，风险偏好修复
- **DXY 98.64（-6.2%）**：美元大幅走弱，对新兴市场+商品释放流动性
- **TIP +12%**：实际利率急降，名义利率上行被通胀预期吸收→利好实物资产
- **核心矛盾**：名义利率 vs 实际利率背离，说明市场定价"通胀粘性+宽松预期"，短期Risk-On但中期需警惕通胀反弹引发鹰派预期


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - RSI 38.01 中性偏弱，未超买或超卖
  - 价格2年分位85%历史高位，但REGIME显示区间震荡
  - MA20与MA120仅差1.09%，趋势纠缠无方向
ONE_LINER: 区间震荡中价格高位但RSI偏低，信号中性，关注支撑51.81(MA250)和阻力55.47(MA120)。

### Risk Officer
```
SIGNAL: ok
STRENGTH: N/A
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性仓位无极端集中度；实际决策前需补全真实持仓快照以完成集中度与压力测试评估。
```

**备注**：回测环境下 Risk Officer 无法执行集中度校验（无 portfolio_summary）和历史行为分析（Dreaming 暂无数据）。若为实盘决策，必须提供：
- 各资产持仓市值与均价
- NDQ.AX 集中度占比
- 可用投资现金（INVESTABLE_CASH_CNY）
- 用户近期交易频率（判断情绪化追涨）

以上字段缺失时，风险评估仅为形式化输出，不具实质约束力。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-20 > cutoff 2024-12-31)

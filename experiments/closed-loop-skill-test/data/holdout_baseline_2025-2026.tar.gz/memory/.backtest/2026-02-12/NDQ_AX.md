# Committee: NDQ.AX

**Date**: 2026-02-12
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-12",
  "vix": 20.82,
  "tnx": 4.104,
  "usdcny": 6.9125,
  "audcny": 4.9249
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.60
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0

TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回踩至 ¥49.5 附近（MA250下方约5%）且 RSI < 30 → 可建试探仓约 ¥30,000"
    - "若价格站稳 ¥55.5（MA120）并放量突破 → 回踩确认后可加入约 ¥20,000"

RISK_PLAN:
  stop_loss_trigger: "若价格跌破 ¥49.0（MA250下方约6%）且 VIX 升破 25 → 不再加仓，等待下一个支撑位 ¥46 区域"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "N/A（当前零仓位）"

PERSONAL_NOTE:
  - 当前回测模式下假设中性持仓，NDQ.AX 仓位为零或极轻，暂无浮盈浮亏压力
  - 本次建议在子弹中占比为 0%，保留全部弹药等待方向明朗
  - 价格处于2年73%分位（偏贵区间），同时 RSI 32.77 接近超卖，两端信号拉锯——**便宜到可以买 vs 贵到没空间**。Uptrend ACCUMULATE 怀疑清单三问回答：①价格贴近MA250（51.99），偏离120日均线（55.53）约-5.8%，不存在均值回归风险但存在向下破位风险；②VIX 20.82 月跌18%但仍高于20警戒线，市场紧张感未完全消退；③若30天后跌10%（至约¥47），MA250支撑已破且宏观收紧趋势加剧，ACCUMULATE 理由将不成立。结论：三问中②③均有隐患，等RSI确认底部 + MA250守住再入场比此刻试探更稳妥


---

## Macro Strategist (shared)

根据提供的宏观数据进行评估：

---

**宏观环境分析：**

- **VIX 20.82**（月跌18%）：恐慌情绪从高位回落，但仍高于20警戒线，市场紧张感尚未完全消退
- **TNX 4.10%**（月涨21%）：长端利率快速攀升，金融条件收紧，对风险资产估值构成压制
- **DXY 96.93**（月跌6%）：美元显著走弱，利好商品/黄金
- **TIP 月涨11.7%**：实际利率大幅下行，黄金双击条件之一成立

**货币因素核心判断**：美元走弱 + 实际利率下行 = **黄金双击环境**，商品类资产受强力支撑。

**风险因素**：名义利率飙升仍在进行，若通胀数据反复，联储转鹰可能扭转当前格局。

---

```
SIGNAL: neutral
STRENGTH: 4
SCORE: 1
KEY_HEADWIND: 10Y国债收益率月涨21%至4.1%，金融条件快速收紧压制风险资产估值
KEY_TAILWIND: 美元月跌6%+实际利率大幅下行，黄金/商品迎双击窗口
ONE_LINER: 宏观环境分裂——风险资产承压但商品黄金有利，整体维持现有仓位，黄金/商品可小幅加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位73%处于高位，限制上行空间
  - RSI 32.77接近超卖，提供短期支撑
  - 当前价52.29紧贴MA250（51.99）关键支撑
ONE_LINER: REGIME为range_bound，价格处于73%高位与RSI超卖区间的拉锯中，支撑在MA250（51.99），阻力在MA120（55.53），方向未明，故出neutral。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓明细，假设中性持仓下风险可控，建议单资产集中度上限≤30%


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-12 > cutoff 2024-12-31)

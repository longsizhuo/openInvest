# Committee: NDQ.AX

**Date**: 2025-11-19
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.58)
**Dominant view**: risk
**Suggested allocation CNY**: 25000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-19",
  "vix": 23.66,
  "tnx": 4.133,
  "usdcny": 7.1075,
  "audcny": 4.626
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.58
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 25000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 12000
  add_levels:
    - "价格回落至MA120附近（约-3.6%）且VIX回落<22 → 加仓¥8,000"
    - "价格进一步回调8%（约-8%）且RSI<35 → 加仓¥5,000"

RISK_PLAN:
  stop_loss_trigger: "跌破MA120同时^VIX维持>25 → 全部止损清仓"
  what_if_wrong:
    worst_case_pnl_cny: -5000
    recovery_estimate: "3-6个月（基于uptrend regime历史路径中位恢复时间）"

PERSONAL_NOTE:
  - 回测模式无精确持仓数据，假设中性仓位；当前资产处于上升趋势但价格分位93%处于历史极端高位，估值偏贵
  - 本次建仓仅占假设子弹的约5%，属极小试探仓，保留大量弹药等待更好价位
  - uptrend中ACCUMULATE三项自查：①距MA120偏离仅3.6%（<15%阈值，均值回归风险可控）✓；②VIX已升至23.66远超18警戒线，市场焦虑情绪真实存在——这不是"回调买入"的温和信号，而是防御信号 ✗；③若30天后跌10%，小仓位可承受且有加仓空间，理由基本成立 ✓。VIX检查未通过是本次仅给极小仓位的核心原因；Macro risk_off叠加VIX恐慌区间意味着不要追涨，耐心等待利率恐慌消退后的更清晰信号再加码


---

## Macro Strategist (shared)

根据您提供的宏观数据，我来给出评估：

---

**SIGNAL: risk_off**
**STRENGTH: 6**
**SCORE: -2**

**KEY_HEADWIND:** VIX升至23.66（>20恐慌区间）+ TNX月涨12.65%至4.13%，名义利率快速走高压制风险资产估值，衰退担忧升温。

**KEY_TAILWIND:** DXY跌至100.23（月跌3.79%）+ TIP月涨12%（实际利率骤降），美元走弱与实际利率下行形成黄金"双击"环境。

**ONE_LINER:** 利率恐慌+避险情绪主导，传统风险资产维持防御；但货币环境对黄金/商品极为友好，组合若持有贵金属可维持甚至加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 6
KEY_DATA:
  - 价格分位93%处于历史高位，估值偏高风险显著
  - RSI(14) 38.71，已从超买区回落至中性偏弱，上涨动能减弱
  - 价格从近期高点回调5.24%，处于高位整理，距MA120偏离仅3.6%
ONE_LINER: 处于高位震荡的上升趋势中，价格分位极高但RSI走弱，短期方向不明，观望为主。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无持仓数据，但Dreaming显示用户有过度交易倾向，建议本次建仓比例不超过总资产的15%，并设置明确止损。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-19 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-08-25
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 15000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-25",
  "vix": 14.79,
  "tnx": 4.275,
  "usdcny": 7.1675,
  "audcny": 4.6477
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 15000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - "价格从当前回撤5% → 加仓 ¥5000"
    - "价格从当前回撤10% → 加仓 ¥5000"

RISK_PLAN:
  stop_loss_trigger: "跌破MA120（约当前价-9%）同时10Y国债收益率突破4.5% → 清仓全部试探头寸"
  what_if_wrong:
    worst_case_pnl_cny: -3000
    recovery_estimate: "2-4个月（基于uptrend历史路径中位恢复时间）"

PERSONAL_NOTE:
  - 用户回测模式、持仓中性，无极端集中度，可用现金充裕，试探建仓无流动性压力。
  - 本次建议金额仅占假设子弹约3%-5%，属于极轻仓试探，核心目的是在uptrend中建立观察哨而非重仓押注。
  - uptrend怀疑清单检查：①价格离MA120偏离9.5%，未超15%阈值，均值回归压力暂可控；②VIX当前<15处于低位，暂无从低位快速攀升的恐慌信号；③若30天后跌10%，ACCUMULATE理由（DXY暴跌+实际利率下行的宏观顺风）仍成立，美元走弱趋势非短期噪音。但必须正视98%价格分位意味着上行空间极有限——这是"小额跟趋势"而非"大举建仓"，任何信号恶化立刻停手。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 10Y国债收益率上行至4.28%，名义利率攀升压制估值扩张
KEY_TAILWIND: DXY暴跌12%+实际利率下行，美元走弱与实际利率双降构成黄金/商品双击
ONE_LINER: 恐慌指数骤降至15以下、美元大幅走软，宏观环境偏暖，黄金/商品类资产维持或小幅加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格处于2年分位98%的极高位置，上行空间可能受限
  - RSI 55.08 中性，未进入超买区
  - MA20高于MA120 9.37%确认上升趋势，但价格离MA120偏离9.5%（未过度拉伸）
ONE_LINER: REGIME为上升趋势，但价格位于历史极端高位（98%分位），RSI中性，趋势虽强但追高风险极大，故倾向高位盘整（neutral）。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 假设持仓中性，无极端集中度，建议NDQ.AX建仓比例不超过总资产的35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-25 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-07-01
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-01",
  "vix": 16.83,
  "tnx": 4.251,
  "usdcny": 7.1636,
  "audcny": 4.7114
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回落至 MA120 附近（约当前价 -3.4%）且 RSI < 50 → 可试探建仓 ¥50,000"
    - "若价格进一步跌至 2 年 70% 分位以下且 Quant regime 切换至 uptrend → 加仓 ¥100,000"

RISK_PLAN:
  stop_loss_trigger: "若已有仓位，价格跌破 MA120 同时 VIX > 20 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无实际仓位数据）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式，无实际持仓数据，基于中性假设评估。当前无实际仓位需管理。
  - NDQ.AX 处于 2 年 95% 极端高位，Quant REGIME = range_bound 且 SIGNAL = bearish（强度 6），均值回归压力是当前最显著的风险因子——在 range-bound 市况中追高极端分位资产，历史上是胜率最低的操作之一。
  - Macro 信号矛盾偏中性（强度 5，SCORE +1）：10Y 名义利率飙升 54% 压制风险资产估值，但美元大跌 9.2% + 实际利率下行又提供对冲，两股力量互相抵消，不构成方向性催化。
  - RSI 67.25 接近超买但尚未突破 70，MA20/MA120 偏离仅 +3.43% 说明趋势动能弱——"高位 + 弱动能 + range-bound"三者叠加，向上突破的概率低于向均值回归的概率。
  - 操作纪律：当前价位不追高，耐心等待价格回归合理区间（MA120 附近或 2 年 70% 分位以下）。若 Quant regime 切换为 uptrend 且价格回踩确认支撑，再考虑 ACCUMULATE。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙升54%至4.25%，名义利率压力对风险资产估值构成压制
KEY_TAILWIND: 美元大跌9.2%叠加实际利率下行，黄金/商品类资产获得货币因素"双击"
ONE_LINER: 名义利率跳升但实际利率与美元同跌，信号矛盾偏中性——黄金/商品可维持，纯风险仓位暂观望。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: bearish
STRENGTH: 6
KEY_DATA:
  - 价格分位 95%，处于 2 年极端高位
  - RSI 67.25 接近超买区，上行空间受限
  - MA20 与 MA120 偏离仅 +3.43%，趋势动能弱
ONE_LINER: 价格处于 2 年 95% 高位且 RSI 接近超买，在 range_bound 的 REGIME 中面临均值回归压力，技术面偏向 bearish。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无实际持仓数据，无法计算集中度与现金头寸，风险评估基于中性假设。建议在实盘中观察真实数据后再定比例上限。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-01 > cutoff 2024-12-31)

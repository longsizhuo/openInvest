# Committee: NDQ.AX

**Date**: 2026-01-22
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-22",
  "vix": 15.64,
  "tnx": 4.249,
  "usdcny": 6.9637,
  "audcny": 4.7033
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000

TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 20000
  add_levels:
    - "若价格回踩 MA250（约 ¥51.85）附近 → 加仓 ¥15,000"
    - "若价格跌破 MA250 且 RSI < 35 → 加仓 ¥15,000（抄底档）"

RISK_PLAN:
  stop_loss_trigger: "价格连续 3 日收于 MA250 下方且 RSI < 30 → 全部止损出局"
  what_if_wrong:
    worst_case_pnl_cny: -7500
    recovery_estimate: "2-4 个月（range_bound 格局下均值回归周期）"

PERSONAL_NOTE:
  - 回测模式无真实持仓数据，假设持仓中性；当前信号组合为"宏观温和看多 + 量化中性偏弱 + 风险无警报"，属于弱信号环境，不宜重仓。
  - 首笔 ¥20,000 约占合理子弹的 5%-10%，预留两档加仓空间，整体为试探性建仓而非趋势性押注。
  - **Range-bound 怀疑检查**：(1) 价格处 2 年 85% 分位属偏高区间，但 MA20 与 MA120 仅差 0.44 均线粘合，无趋势性偏离 120MA 的风险，属于"高位横盘"而非"趋势过热"；(2) VIX 15.6 处于中性偏低水平，非恐慌也非自满，无反转先兆；(3) 若 30 天后跌 10%，宏观 tailwind（美元走弱 + 实际利率下行）大概率仍有效，均值回归逻辑依然成立——结论：ACCUMULATE 合理但必须分批，不追高。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y国债收益率月涨7.6%至4.25%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数月跌6.2%+TIP月涨12.6%，美元走弱+实际利率下行构成黄金双击环境
ONE_LINER: VIX回落至15.6恐慌消退，美元与实际利率双降利好风险资产及黄金，但名义利率抬升需警惕，整体偏向适度加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年价格分位85%，处于高位区间
  - RSI 38.48中性偏弱，买盘动能不足
  - MA20与MA120仅差0.44，呈典型纠缠态，无方向
ONE_LINER: 价格处于2年高位但均线粘合、RSI乏力，范围震荡格局下缺乏单边突破动力，支撑MA250（51.85），阻力前高区域，维持中性判断。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A (回测模式)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式)
ONE_LINER: 回测模式无持仓详情，按中性假设暂无风险信号；正式评估时建议确认集中度<35%后可建仓，单笔不超过可用子弹的30%。
```

**Risk Officer 备注**：回测模式下无法获取真实 portfolio_summary，以上评估基于"持仓中性"假设。建议 CIO 在正式入金前要求补全持仓数据后重新跑一轮完整风险评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-22 > cutoff 2024-12-31)

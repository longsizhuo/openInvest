# Committee: NDQ.AX

**Date**: 2025-05-13
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-13",
  "vix": 18.22,
  "tnx": 4.499,
  "usdcny": 7.2018,
  "audcny": 4.5894
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.50
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回落至 MA250 附近 (≈45.50) 且 RSI<40 → 可试探建仓 5% 子弹"
    - "若进一步跌至 43.00 区间且 VIX 回落至 15 以下 → 加仓至 10% 子弹"

RISK_PLAN:
  stop_loss_trigger: "若已持仓，跌破 MA250 (45.50) 且 ^VIX 突破 22 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: "N/A（回测模式无真实持仓，假设 10 万试探仓最坏 -8% ≈ 亏 8,000）"
    recovery_estimate: "下降趋势中可能 3-6 个月"

PERSONAL_NOTE:
  - "回测模式下持仓假设为中性，Risk Officer 数据几乎全部缺失（集中度/现金/PnL 均为 N/A），这大幅削弱了本次裁决的信息质量——信心上限被限制在 0.5。"
  - "Quant 信号非常清晰：MA20 已死叉 MA120 确认下降趋势，价格处于 2 年 87% 高分位，RSI 64 虽未超买但缺乏向上动能。当前不适合加仓。"
  - "Macro 维持中性（5/10），10Y 收益率飙升至 4.50% 是实质性的估值压缩风险，但 VIX 从 25 暴跌至 18 又限制了急跌空间——这是一段'阴跌磨人'而非'暴跌抄底'的环境。纪律建议：宁可错过反弹也不要在下降趋势中摊平成本，等到 MA20 重新站上 MA120 再考虑入场。"
  - "120 日均线偏离检查：当前价格约 46.x，MA120 在 47.96，价格已在均线下方，不存在偏离过高问题——反而是确认了下行通道。VIX 从 25 回落至 18 但 10Y 收益率持续走高，利率端的紧缩信号比 VIX 的恐慌消退更值得关注。"


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: 0
KEY_HEADWIND: 10Y国债收益率飙升至4.50%（MoM +32%），金融条件收紧压制风险资产估值
KEY_TAILWIND: VIX从25高位暴跌至18，恐慌情绪大幅消退；美元走弱+实际利率下行利好黄金
ONE_LINER: 利率上行与恐慌消退相互对冲，维持现有仓位，不追高亦不恐慌减仓
```

**补充说明**：

| 指标 | 信号 | 解读 |
|------|------|------|
| TNX 4.50% ↑ | ⚠️ 鹰派 | 连续爬升，金融条件收紧 |
| VIX 18.22 ↓ | ✅ 鸽派 | 恐慌退潮，风险偏好回升 |
| DXY 101 ↓ | ✅ 美元走弱 | 黄金/商品顺风 |
| TIP +3.82% | ✅ 实际利率下行 | 黄金顺风 |

**核心矛盾**：名义利率飙升但实际利率下行，意味着通胀预期走高。当前宏观处于"增长尚可+通胀隐忧+恐慌消退"的微妙平衡期，方向未明前宜观望。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 7
KEY_DATA:
  - 价格2年分位87%，估值偏高
  - RSI 64.46，虽未超买但配合高位分位与下降趋势有回调压力
  - MA20(44.62)已低于MA120(47.96)，确认趋势反转
ONE_LINER: 下降趋势中高位价格（87%分位）易受抛压，短期反弹不改中期下行风险，支撑位45.50（MA250），阻力位47.96（MA120）。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，持仓数据不可用）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A（无法计算，需真实持仓）
ONE_LINER: 回测模式无持仓上下文，假设中性持仓下风险可控，若实际集中度>35%建议单次建仓≤20%总仓位。
```

**备注**：本次评估基于用户声明的"持仓中性假设"。若需精确风险计算，请提供真实 portfolio_snapshot（含持仓均价、现价、集中度、可用现金）。当前无 Dreaming 行为模式数据，无法判断是否存在情绪化追涨历史。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-13 > cutoff 2024-12-31)

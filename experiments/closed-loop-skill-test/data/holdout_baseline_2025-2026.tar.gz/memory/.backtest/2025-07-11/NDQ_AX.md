# Committee: NDQ.AX

**Date**: 2025-07-11
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-11",
  "vix": 16.4,
  "tnx": 4.423,
  "usdcny": 7.1748,
  "audcny": 4.7306
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无加仓计划，等待估值回落或趋势信号明确

RISK_PLAN:
  stop_loss_trigger: 若已持有仓位，价格跌破 MA120（当前约偏离 +6.1% 对应区域）且 ^VIX 突破 20 → 减仓 30%
  what_if_wrong:
    worst_case_pnl_cny: 0（本次无新增仓位，无新增浮亏敞口）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 当前假设持仓中性，回测模式下无精确持仓还原；NDQ.AX 处于 uptrend 但价格已处于 2 年分位 96% 的极端高位，追高风险显著。
  - 本次不新增仓位，SUGGESTED_ALLOC_CNY = 0，子弹 100% 保留，等待估值修正后再考虑入场。
  - 裁决逻辑：三方信号全部为 neutral/ok，无任何方向性共识——Quant 虽确认 uptrend 但明确指出"涨势可能衰竭"；Macro 10 年期美债收益率单月飙升 55% 构成估值压缩压力；Risk Officer 回测模式下数据缺失但建议仓位上限 30%。在 96% 分位的极贵估值下，倾向观望而非追高。
  - Uptrend ACCUMULATE 怀疑清单（虽本裁决为 HOLD，仍显式检查）：(1) 价格偏离 MA120 仅 6.11%，未触发 15% 均值回归阈值——OK；(2) 10 年期美债收益率从低位急升至 4.42%，融资成本跳升等价于 VIX 上升的焦虑信号——不支持"回调即买"；(3) 若 30 天后跌 10%，96% 分位的入场点将使持仓面临深度浮亏且回本路径不确定——因此 HOLD 优于 ACCUMULATE。
  - 纪律建议：不要因为"趋势还在"就在历史高位区间加仓。耐心等待价格回落至 2 年分位 80% 以下或 RSI 回踩至 45-50 区间再考虑建仓，届时以子弹 5%-8% 建试探仓并设网格加仓计划。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: +1

KEY_HEADWIND: 10年期美债收益率单月飙升55%至4.42%，名义利率急速上行压制风险资产估值。

KEY_TAILWIND: 美元指数月跌8%至97.85，叠加实际利率下行（TIP月涨3.3%），形成黄金/商品双击格局。

ONE_LINER: 混合信号环境——利率跳升与美元崩跌并存，风险资产承压但商品受益，整体倾向**维持**观望，黄金类仓位可小幅加仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位96%，历史高位估值偏高
  - RSI 62.71，中性未超买但趋势强度有限
  - 价格偏离MA120约6.11%，低于15%均值回归风险阈值
ONE_LINER: 尽管处于上升趋势，但价格分位极高接近顶部，RSI未超买但涨势可能衰竭，建议中性。

### Risk Officer
SIGNAL: ok
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确风险数据，假设持仓中性，技术/宏观信号主导。建议本次加仓后，该资产总占比不超过30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-11 > cutoff 2024-12-31)

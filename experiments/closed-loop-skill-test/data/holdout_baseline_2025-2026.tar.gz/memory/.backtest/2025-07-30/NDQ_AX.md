# Committee: NDQ.AX

**Date**: 2025-07-30
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.72)
**Dominant view**: quant
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-30",
  "vix": 15.48,
  "tnx": 4.376,
  "usdcny": 7.1764,
  "audcny": 4.6736
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.72
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 20000
  add_levels:
    - "if price drops 5% from current highs → add ¥15000"
    - "if price approaches and holds MA120 support (48.22 area) → add remaining ¥15000"

RISK_PLAN:
  stop_loss_trigger: "价格有效跌破 MA120 (48.22) 并收盘确认，同时 ^VIX > 20 或 10Y US Treasury Yield > 4.5% → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -12500
    recovery_estimate: "若回踩至MA120支撑并企稳，预计1-2个月解套；若趋势破坏，可能需要3个月以上"

PERSONAL_NOTE:
  - **用户持仓状态评估**：回测模式下假设持仓中性，无极端集中度，无历史浮盈浮亏数据。
  - **本次建议在子弹中占比**：本次建仓金额50000 CNY，按常规子弹规模估计约占5%-8%，属试探性建仓。
  - **心理/操作纪律建议**：价格处于历史100%分位（Quant报告），且宏观利率环境矛盾，需保持耐心，严格执行分批计划，避免追高。
  - **uptrend 中 ACCUMULATE 怀疑清单检查**：
    1. **均线偏离**：价格高于 MA120 仅 7.36%，未超 15%，均值回归压力暂不突出。
    2. **VIX 状态**：VIX 为 15.48，处于中性区间，非恐慌也非极端自满，暂无明显反转信号。
    3. **30 天后跌 10% 的假设**：若一个月后跌 10%，当前上升趋势（REGIME: uptrend）可能仍部分成立，但接近 MA120 关键支撑。届时评估支撑有效性再决定是否加仓，初始小仓位试错风险可控。


---

## Macro Strategist (shared)

**Macro 快照分析完成。**

```
SIGNAL: neutral
STRENGTH: 5
SCORE: 1
KEY_HEADWIND: 10Y收益率单月飙升近40%至4.38%，名义利率急升压制风险资产估值，金融条件显著收紧。
KEY_TAILWIND: 美元指数跌破100（月跌8.8%）叠加实际利率下行（TIP+5.2%），形成黄金双击利好；VIX骤降40%恐慌消退。
ONE_LINER: 利率急升与美元走弱角力中，宏观信号矛盾偏中性，建议维持现有仓位，不急于加减。
```

**核心逻辑**：
- **矛盾信号**：TNX 暴涨（紧缩）vs DXY+实际利率齐跌（宽松）——市场正在重新定价，方向未明
- **VIX 15.48**：恐惧退潮但非极端自满，暂无系统性风险预警
- **黄金友好环境**：美元走弱+实际利率下行是明确的货币面双击
- **警惕点**：若 TNX 继续上行突破 4.5%，将实质冲击成长股估值并可能逆转当前 risk-on 情绪


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - RSI 69.59 接近超买区但未突破70
  - 价格分位100%历史最高，均值回归风险高
  - MA20高于MA120 +7.36%，趋势向上明确
ONE_LINER: 上升趋势中RSI未超买支撑看多，但价格处历史高位需谨慎，支撑位MA120 48.22。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无精确持仓数据；假设中性持仓前提下风险可控，建议实际交易前补充真实持仓校验集中度与子弹。
```

**补充说明**：
- 本次为历史回测，portfolio_summary 未提供实际持仓明细，所有量化字段标记 N/A
- Dreaming 行为模式暂无数据，无法判断是否存在情绪化追涨历史
- SIGNAL=ok 基于"假设中性持仓（无极端集中度）"这一前提；若实际持仓 NDQ.AX 集中度 >35%，需重新评估
- 建议：正式交易决策前，务必以真实持仓数据重新触发 Risk Officer 评估


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-30 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-06-11
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-11",
  "vix": 17.26,
  "tnx": 4.412,
  "usdcny": 7.1802,
  "audcny": 4.6864
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无加仓计划，等待更明确信号

RISK_PLAN:
  stop_loss_trigger: N/A（回测模式无持仓数据）
  what_if_wrong:
    worst_case_pnl_cny: N/A
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式，无实时持仓数据，Risk Officer无法量化风险评估（虽未标记UNAVAILABLE但实质上信息缺失），系统性下调confidence
  - Quant判定regime=range_bound且价格处于2年分位89%高位，MA20/MA120差值仅+1.46%表明趋势动能不足，非建仓时机
  - Macro指出10Y收益率单月飙涨+50%对利率敏感型资产构成压力（NDQ作为科技股ETF属此类），虽美元走弱提供一定缓冲但矛盾信号下应观望
  - 高位分位（89%）叠加range_bound regime=均值回归风险高于趋势延续概率，此时进场性价比不佳
  - 操作纪律：耐心等待价格回踩MA120（约48.08）附近或RSI跌入超卖区再考虑ACCUMULATE
```


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: 0
KEY_HEADWIND: 10Y收益率单月飙涨+50%压制风险资产估值，利率环境急剧收紧
KEY_TAILWIND: 美元指数跌破100且持续走弱(-7.5%)，叠加实际利率下行(TIP+3.88%)，黄金获双击支撑
ONE_LINER: 利率急升与VIX回落并存、美元弱势与实际利率下行共舞，环境矛盾——整体维持，黄金/商品类可小仓加码，利率敏感型资产偏防御。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位89%，处于历史高位区间
  - RSI(14) 61.13，中性偏强未超买
  - MA20与MA120差值仅+1.46%，趋势纠缠无方向
ONE_LINER: 价格高位分位且RSI中性，REGIME为range_bound缺乏趋势动能，建议中性，支撑MA120（48.08），阻力关注近期高点。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A (回测模式，无持仓数据)
DRY_POWDER_CNY: N/A (回测模式，无持仓数据)
PNL_PCT: N/A (回测模式，无持仓数据)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式，无持仓数据)
ONE_LINER: 回测模式，无实时持仓与现金流数据，无法进行量化风险评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-11 > cutoff 2024-12-31)

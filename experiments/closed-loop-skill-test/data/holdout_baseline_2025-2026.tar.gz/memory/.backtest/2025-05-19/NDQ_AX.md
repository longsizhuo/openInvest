# Committee: NDQ.AX

**Date**: 2025-05-19
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-19",
  "vix": 18.14,
  "tnx": 4.475,
  "usdcny": 7.209,
  "audcny": 4.6203
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 若已持有仓位，需警惕价格跌破MA120（约48.02）且伴随VIX回升至20以上
  what_if_wrong:
    worst_case_pnl_cny: 0 （当前建议为不操作，无新增风险）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 基于回测假设，当前持仓中性，无极端集中度。
  - 本次建议维持现状（HOLD），新增操作金额为0。
  - 确定性事实显示，资产价格处于两年分位88%的高位，估值偏高。技术面（Quant）判断为下跌趋势中的高位震荡，与宏观面（Macro）的risk_on信号形成分歧。考虑到估值偏高且技术面未形成一致看涨信号，当前不是理想的加仓时机。建议保持耐心，等待技术面与宏观面形成更明确的一致信号，或价格出现更具吸引力的回撤。纪律上，避免因宏观情绪回暖而在技术高位追涨。


---

## Macro Strategist (shared)

**宏观评估**

```
SIGNAL: risk_on
STRENGTH: 4
SCORE: +2
KEY_HEADWIND: 10Y收益率飙升至4.47%（MoM +42%），金融条件收紧，压制风险资产估值
KEY_TAILWIND: 美元走弱（DXY 100.4，MoM -3.8%）叠加实际利率下行（TIP +4.2%），黄金/商品迎来"双击"窗口
ONE_LINER: 恐慌消退+美元走弱驱动风险偏好回暖，组合可适度加仓黄金/商品；但收益率飙升提示不宜激进追涨成长股
```

---

**要点说明：**

- **VIX 18** 跌出恐慌区间（MoM -37%），情绪修复显著；
- **DXY + TIP 双信号共振**：美元走弱 + 实际利率下行 = 黄金基本面最友好组合；
- **唯一警示**：TNX 单月暴涨 42%，若后续 CPI/PCE 再度粘性，可能重新点燃加息预期——届时 VIX 与 DXY 方向将快速逆转。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格处于两年分位88%高位，估值偏高
  - RSI 67.88，接近但未进入超买区（>70）
  - 近30日自低点反弹20.20%，但整体仍处下跌趋势
ONE_LINER: 价格高位震荡，RSI接近超买但未突破，下行趋势未改，当前在MA120（48.02）附近多空交织，故维持中性。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式假设持仓中性，风险可控。基于行业标准，建议对该资产的建仓比例上限不超过总资产的35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-19 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-03-03
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-03-03",
  "vix": 23.57,
  "tnx": 4.056,
  "usdcny": 6.882,
  "audcny": 4.889
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "当前不建仓，等待技术面确认"
    - "若RSI跌入<30超卖区+价格触及MA250下方5%以上，可考虑首次试探 ¥50,000"

RISK_PLAN:
  stop_loss_trigger: "若已持仓，价格跌破MA250下方5%且RSI<30时止损；当前观望无触发"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "下行趋势中等待反转信号，预计3-6个月"

PERSONAL_NOTE:
  - 回测模式下无持仓数据，基于信号中性立场观望
  - 本次不建仓，子弹100%保留
  - Macro risk_off（国债收益率+VIX双飙升）叠加Quant downtrend=典型"股弱"环境，NDQ作为科技成长ETF首当其冲；Quant RSI 36未超卖且无反转信号，此时进场是"接飞刀"；宁可错过底部10%涨幅，也不吃后续可能的15-20%下跌——等RSI<30或价格放量突破MA250再考虑


---

## Macro Strategist (shared)

**MACRO ASSESSMENT — 2026-06-26**

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 国债收益率月涨21%+VIX月涨24%，利率与恐慌双升=风险资产承压
KEY_TAILWIND: 美元破百(DXY 99)+实际利率大幅下行(TIP+9.8%)，黄金/商品双击环境
ONE_LINER: 股债双杀压力加剧，但美元走弱+实际利率下行形成鲜明分化——权益端减仓，商品/黄金端维持偏多
```

**核心逻辑**：
- **利率+VIX同步飙升**（TNX +21.55%/VIX +24%）是经典risk-off组合，压制股票估值
- **DXY破百至99 + TIP月涨近10%** = 美元信用松动 + 实际利率坍塌 → 黄金/大宗商品的"完美风暴"
- 名义利率涨但实际利率跌 → 通胀预期跑赢名义利率 → **滞胀信号隐现**
- USDCNY 6.88 稳定，人民币压力可控

> 当前是"权益弱、商品强"的分化格局，需按资产类别区别对待，不宜一刀切。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI 36.39 处于弱势区但未超卖
  - 价格2年分位68%，估值偏高
  - 价格在MA250下方仅-1.34%，偏离度有限
ONE_LINER: 下降趋势中，RSI弱势但未极端，估值偏高，暂无明确反转或加速信号，观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无具体持仓风险数据，基于中性假设，建议建仓比例上限25%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-03-03 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2026-02-04
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 25000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-02-04",
  "vix": 18.64,
  "tnx": 4.275,
  "usdcny": 6.9377,
  "audcny": 4.8713
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 25000

TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 10000
  add_levels:
    - "价格回落至 MA120 (55.59) 附近 → 加 ¥8,000"
    - "价格回踩 MA250 (51.96) → 加 ¥7,000"

RISK_PLAN:
  stop_loss_trigger: "收盘跌破 MA250 (51.96) 同时 VIX 重返 25 以上 → 减仓 50%"
  what_if_wrong:
    worst_case_pnl_cny: -3500
    recovery_estimate: "2-4 个月（基于 range_bound regime 历史均值回归周期）"

PERSONAL_NOTE:
  - 回测模式无持仓数据，假设中性仓位；NDQ.AX 当前估值分位 77% 偏贵，不宜一次性重仓追入。
  - 首笔 ¥10,000 仅占标准子弹约 3-5%，属于试探性建仓，总计划 ¥25,000 也控制在合理范围。
  - RSI 30.46 已进入超卖区，短期存在反弹动能，但 77% 高估值分位意味着向上空间有限——本次 ACCUMULATE 的核心逻辑是"小仓捕捉超卖反弹 + 网格在支撑位分批接"，而非赌突破新高；若 Macro 风向转弱（VIX 重新走高或美元反弹），需果断暂停加仓计划。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 美债10Y收益率升至4.28%，名义利率上行对风险资产估值构成压力
KEY_TAILWIND: 美元指数大跌5.77%至97.62+实际利率大幅回落，为黄金和大宗商品提供双重顺风
ONE_LINER: VIX回落至18.64+美元走弱=宏观环境偏暖，风险资产可维持偏多配置，黄金受益于实际利率下行趋势


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - RSI(14) 30.46 进入超卖区
  - 价格2年分位77%估值偏高
  - 价格位于MA250 (51.96) 上方获得支撑
ONE_LINER: 震荡市中，高位估值与短期超卖相互制约，形成中性格局，支撑在MA250 (51.96)，阻力在MA120 (55.59) 附近。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无具体持仓数据。假设持仓中性，建议单一资产配置上限参考标准（≤25-35%）。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-02-04 > cutoff 2024-12-31)

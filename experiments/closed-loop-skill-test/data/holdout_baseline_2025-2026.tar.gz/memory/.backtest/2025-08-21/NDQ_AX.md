# Committee: NDQ.AX

**Date**: 2025-08-21
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-08-21",
  "vix": 16.6,
  "tnx": 4.33,
  "usdcny": 7.1757,
  "audcny": 4.6181
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "if price drops 3% → add ¥15000"
    - "if price drops 6% → add ¥20000"

RISK_PLAN:
  stop_loss_trigger: "跌破当前价位5%同时^VIX > 20 → 减仓30%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户当前持仓中性（回测模式，无极端集中度），假设现金充足，无浮亏浮盈数据。
  - 本次建议alloc 50000 CNY，占子弹比例假设5-10%，符合Risk Officer初始建仓不超过15%的谨慎建议。
  - uptrend中ACCUMULATE怀疑清单检查：1) 价格偏离MA120 +11.65%，低于15%，均值回归风险中等但可控；2) VIX腰斩至16.6，恐慌消退，但长端利率飙升需警惕，无VIX从低位急升信号；3) 如果30天后跌10%，ACCUMULATE理由可能削弱，因价格处于2年99%分位高位，但Macro risk_on（美元暴跌、实际利率下行）提供支撑，故分批建仓以管理风险。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 美债收益率月涨17%（4.33%），利率上行压制估值敏感型资产
KEY_TAILWIND: 美元暴跌13.5%至98.6+实际利率下行（TIP+10.6%），黄金/商品双击环境成型
ONE_LINER: VIX腰斩至16.6恐慌消退、美元走弱利好风险资产，但长端利率飙升需警惕——整体偏向加仓，尤其商品与非美资产。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位 99%，处于2年历史极端高位
  - RSI 56.34，中性区间，无超买/超卖
  - 距离MA120偏离+11.65%，均值回归压力存在
ONE_LINER: 处于上升趋势，但价格已至历史高位，RSI中性，短期上行空间或受高估值压制，故给出中性信号。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下持仓数据缺失，无法精确评估集中度与流动性风险，建议任何实盘操作时初始建仓比例不超过总资产的15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-08-21 > cutoff 2024-12-31)

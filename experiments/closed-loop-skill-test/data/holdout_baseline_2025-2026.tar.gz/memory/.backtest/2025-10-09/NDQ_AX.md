# Committee: NDQ.AX

**Date**: 2025-10-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-09",
  "vix": 16.43,
  "tnx": 4.148,
  "usdcny": 7.1185,
  "audcny": 4.6869
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: 若已持有NDQ.AX，价格跌破MA120且RSI下穿45 → 减仓20%；10Y收益率继续月涨超10%且美元反弹 → 提前防御
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 当前NDQ.AX价格处于2年分位100%（历史最高），Quant明确指出估值风险高、均值回归压力上升；trailing估值偏贵，加仓应极度保守
  - Quant/Macro/Risk三方信号均为中性或数据缺失（Risk Officer全部指标N/A），缺乏任何方向性驱动，本次裁决置信度降至0.55
  - uptrend中ACCUMULATE怀疑清单检查：①MA120偏离度9.59%，未破15%警戒线但已在累积回归势能；②RSI 69.25逼近70超买线，短期追高性价比极差；③若30天后跌10%，在ATH建仓的理由不成立——三条均指向"不宜在此价位主动建仓"
  - Macro面10Y国债收益率月涨+8.33%构成估值压制，虽美元走弱形成对冲，但利率上行环境对NDQ这类成长型ETF尤为不利
  - 操作纪律：耐心等待价格回踩MA20（约5-7%回调）或RSI回落至50以下区间再考虑介入；当前价位不追、不割，空仓或轻仓观望是最佳策略


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 4
SCORE: 1
KEY_HEADWIND: 10Y国债收益率月涨+8.33%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元指数月跌-6.68%+实际利率（TIP月涨+12.6%）同步下行，黄金/商品类双击环境
ONE_LINER: 恐慌消退但利率回升形成对冲，贵金属友好但整体偏中性，维持现有仓位
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:
  - 价格2年分位100%，历史最高，估值风险高
  - RSI 69.25接近超买区，MA120偏离度9.59%
  - MA20/MA120 spread 7.22%，但需查收窄信号（衰竭检查中）  
ONE_LINER: uptrend中价格处历史高位且RSI接近超买，虽趋势未破但均值回归风险上升，转为中性观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，无法评估集中度与流动性风险。建议在真实持仓中控制单一资产敞口不超过总资产的10-15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-09 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-09-04
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.75)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-04",
  "vix": 15.3,
  "tnx": 4.176,
  "usdcny": 7.1414,
  "audcny": 4.6734
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.75
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "if price drops 3% from current level → add ¥15,000"
    - "if price drops 7% from current level → add ¥25,000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破120日均线且同时^VIX > 22 → 减仓30%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - "回测模式下假设持仓中性，当前无极端集中度风险。"
  - "本次建仓金额约占假设子弹（¥500,000）的10%，属于试探性建仓。"
  - "宏观risk_on与技术uptrend共振，但价格处于2年高位，需警惕回调。建议分批执行，保留子弹等待更明确的回调或突破信号。"
  - "关于uptrend中ACCUMULATE的检查：(1) 价格偏离MA120仅7.8%，未达15%均值回归高风险阈值；(2) VIX已腰斩至15+，处于低位但未显示上升启动；(3) 若30天后跌10%，宏观risk_on及技术趋势健康的逻辑仍可能成立，但需重新评估。"


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 8
SCORE: +3
KEY_HEADWIND: 10Y收益率4.18%仍处高位，名义利率上行9%或压制成长股估值
KEY_TAILWIND: DXY暴跌13%叠加TIP暴涨14%（实际利率骤降），黄金/商品迎双击窗口
ONE_LINER: VIX腰斩至15+美元崩塌，宏观环境明确risk_on，可加仓风险资产；黄金受双顺风支撑尤其强势。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格处于2年96%高位，需警惕均值回归风险
  - RSI(14) 50.43，处于中性区域，非超买
  - 价格对MA120偏离度7.8%，未超过15%的均值回归高风险阈值
ONE_LINER: 尽管处于上升趋势（REGIME=uptrend），但价格已处历史高位，RSI中性提供了短期支撑，趋势健康度尚可，因此给出谨慎看涨信号。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无具体持仓与现金流数据，风险无法量化；建议基于技术信号建仓，单资产配置比例上限建议25%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-04 > cutoff 2024-12-31)

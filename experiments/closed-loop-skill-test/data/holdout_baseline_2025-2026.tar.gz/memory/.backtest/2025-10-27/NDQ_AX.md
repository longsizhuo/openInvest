# Committee: NDQ.AX

**Date**: 2025-10-27
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.72)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-27",
  "vix": 15.79,
  "tnx": 3.997,
  "usdcny": 7.1211,
  "audcny": 4.6525
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.72
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回踩至 MA120 附近（~52.31 AUD，约 ¥250 区间）且 RSI 降至 45 以下 → 首笔试探仓 ¥50,000"
    - "若价格进一步跌至 MA120 下方 3% 且 VIX 未突破 25 → 加仓 ¥80,000"

RISK_PLAN:
  stop_loss_trigger: "若已持仓，跌破 52.31（MA120）同时 ^VIX > 22 → 减仓 30%；若新建仓后浮亏 > 8% → 止损出局"
  what_if_wrong:
    worst_case_pnl_cny: 0（当前未建仓，机会成本为主）
    recovery_estimate: "若错过上涨行情，待回调至 MA20 附近（~55.8 AUD）重新评估建仓时机"

PERSONAL_NOTE:
  - "NDQ.AX 当前处于 2 年价格分位 100%（历史极值），RSI(14)=70.56 已进入超买区，Quant bearish 信号强度为 8，是本轮三个信号中最强烈的——即便 regime 仍为 uptrend，技术面的极端超买状态不容忽视。"
  - "宏观端 risk_on（score +3）与弱美元环境构成支撑，但 10Y 国债收益率月涨 6.6% 至 4%，这对科技/成长股估值形成结构性压制，Macro 与 Quant 的分歧实质上是'流动性友好 vs 估值昂贵'的矛盾。"
  - "uptrend ACCUMULATE 三检：①价格偏离 MA120 约 10.5%，未超 15% 但已属中高位——均值回归压力蓄积中；②VIX 15.79 处低位且仍在下降，暂无焦虑信号；③若 30 天后跌 10%，当前 100th 分位 + RSI 70+ 的组合意味着回调概率不低——在历史极值位追加仓位的纪律风险远大于错过行情的机会成本。结论：不追高，等 RSI 回落至 50 以下或价格回踩 MA120（~52.31）再考虑 ACCUMULATE。"
```


---

## Macro Strategist (shared)

**宏观快照分析**（基于用户提供的数据）

---

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +3
KEY_HEADWIND: 10Y国债收益率升至4%且月涨6.6%，名义利率上行压制成长股估值。
KEY_TAILWIND: 美元指数月跌5.7%+TIP涨13.9%，美元走弱与实际利率下行构成黄金/商品双击环境。
ONE_LINER: VIX跌至16以下+美元崩跌，宏观偏暖，组合维持偏进攻配置；若持有黄金类资产，当前货币环境极度友好，倾向加仓。
```

**逻辑拆解**：

| 维度 | 判断 |
|------|------|
| **恐慌情绪** | VIX 15.79（月跌28%），市场极度平静 → risk_on |
| **利率** | TNX 4% + MoM上升，名义利率走高 → 中性偏空（尤其科技） |
| **美元** | DXY 98.78（月跌5.7%），弱美元周期确认 → 利好非美资产/商品/黄金 |
| **实际利率** | TIP月涨+13.9% → 实际利率大幅下行 → **黄金核心利好** |
| **综合评分** | 弱美元+实际利率下行的组合力压名义利率上升，整体偏积极 |

**黄金/商品视角**：DXY跌破99 + TIP暴涨 = 经典"双击"结构，货币端阻力几乎消失。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: bearish  
STRENGTH: 8  
KEY_DATA:  
  - 价格2年分位100%，处于历史极高位，估值偏高风险  
  - RSI(14)=70.56，进入超买区，技术性回调压力大  
  - MA20高于MA120 7.27%但价格离MA120偏离仅10.49%，上升动能可能衰减  
ONE_LINER: 上升趋势中价格创新高但RSI超买且分位极高，bearish信号主导，支撑位52.31（MA120）。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: 10% (回测模式假设)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: -2%
ONE_LINER: 基于中性持仓假设，风险可控。若在实盘中，建议单资产建仓比例上限不超过15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-27 > cutoff 2024-12-31)

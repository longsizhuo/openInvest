# Committee: NDQ.AX

**Date**: 2026-01-09
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.35)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-09",
  "vix": 14.49,
  "tnx": 4.171,
  "usdcny": 6.9835,
  "audcny": 4.6786
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.35
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 不执行，等待数据补全与信号明朗

RISK_PLAN:
  stop_loss_trigger: 价格跌破 MA120 (≈55.27 AUD) 且 RSI < 40 → 已有仓位减半
  what_if_wrong:
    worst_case_pnl_cny: 0（无新增仓位，无额外浮亏风险）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式，用户持仓上下文中性，但 Risk Officer 全部关键字段（CONCENTRATION_PCT / DRY_POWDER_CNY / PNL_PCT）均为 N/A，等效于数据不可用，触发系统性保守规则——HOLD + confidence 上限 0.35。
  - 价格处于 2 年分位 91%（Quant 数据），属于历史极贵区间；同时 Quant 判定 range_bound + RSI 48.79 中性，MA20 与 MA120 仅差 1.47%，多空力量深度纠缠，没有任何方向性突破信号支撑在此价位建仓。
  - 宏观虽偏 risk_on（Macro strength 7），但 TNX 月涨 12.21% 对 NDQ 这类长久期 / 高成长标的构成直接估值压缩压力，宏观利好 ≠ 个股利好。弱美元 + 实际利率下行的"双击"更利好黄金/商品，而非 NASDAQ。
  - 操作纪律：在 Risk 数据缺失 + 价格历史高位 + 趋势方向不明的三重不确定性下，持币观望是唯一理性选择。若后续 Quant 出现 bullish 突破信号（如 MA20 上穿前高且放量），再评估 ACCUMULATE 建试探仓。


---

## Macro Strategist (shared)

SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 名义利率快速上行（TNX +12.21% MoM），压制久期资产估值
KEY_TAILWIND: DXY 大幅走弱（-4.61%）叠加实际利率下行（TIP +11.45%），为黄金/商品提供"双击"环境
ONE_LINER: 宏观偏暖，低VIX+弱美元+实际利率下行共振，风险资产可维持偏多配置，黄金尤其受益。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位91%，处于历史高位
  - RSI 48.79中性，无超买/超卖信号
  - MA20(56.08)与MA120(55.27)差值仅1.47%，趋势纠缠
ONE_LINER: range-bound市场中价格高位但RSI中性，缺乏明确方向，支撑55.27(MA120)阻力前高，建议观望。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 风险评估因数据缺失无法量化，回测中建议确保流动性缓冲，并建立建仓比例上限。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-09 > cutoff 2024-12-31)

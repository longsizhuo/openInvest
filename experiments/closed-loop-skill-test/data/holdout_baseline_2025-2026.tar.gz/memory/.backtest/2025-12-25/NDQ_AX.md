# Committee: NDQ.AX

**Date**: 2025-12-25
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: macro
**Suggested allocation CNY**: 40000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-12-25",
  "vix": 13.47,
  "tnx": 4.136,
  "usdcny": 7.028,
  "audcny": 4.7097
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 40000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 20000
  add_levels:
    - if price drops 5% from current → add ¥10,000（接近MA120支撑54.95区域）
    - if price drops 10% + RSI < 35 → add ¥10,000（恐慌性下杀时最后一档）

RISK_PLAN:
  stop_loss_trigger: 跌破MA120(约54.95)同时^VIX突破22 → 全部止损清仓；或价格跌至2年分位70%以下且宏观转risk_off → 减仓50%
  what_if_wrong:
    worst_case_pnl_cny: -8000（假设20%极端回撤，¥40,000仓位浮亏约¥8,000）
    recovery_estimate: 6-9个月（纳指ETF历史回撤恢复周期参考2022年经验）

PERSONAL_NOTE:
  - 回测模式假设中性持仓，当前无NDQ.AX已知敞口；**估值端价格2年分位已达92%高位**，追高风险显著，必须控制试探仓位规模。
  - 本次建议¥40,000仅作为试探仓，占常规子弹的小比例；宏观虽偏risk-on（弱美元+实际利率下行），但**VIX 13.47处于极端自满区间**，市场随时可能因黑天鹅事件快速反转，不值得在此情绪点一次建满。
  - 纪律要点：Regime为range_bound且MA20/MA120仅差2.93%——趋势动能极弱，不要把"宏观温和利好"误读为"趋势确认"。分批金字塔建仓，留足子弹等MA120附近或更低位置的真正性价比。若30天后跌10%，当前宏观支撑逻辑（弱美元+实际利率下行）仍成立，因此小仓试探合理——但若届时VIX已升破18，说明自满情绪已破裂，则应暂停加仓计划。


---

## Macro Strategist (shared)

**宏观快照已获取，综合分析如下：**

---

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y国债利率仍在4.1%+高位，市场自满(VIX<14)暗藏回调风险
KEY_TAILWIND: 美元走弱(DXY -3.2%)叠加实际利率下行(TIP +10.6%)，黄金/商品双击环境
ONE_LINER: 宏观温和risk-on，美元+实际利率双利好黄金，可维持仓位；但VIX过低需警惕情绪反转
```

---

**核心逻辑拆解：**

| 维度 | 信号 | 解读 |
|------|------|------|
| **恐慌情绪** | VIX 13.47 (3月-32%) | 自满区间，市场定价"无风险"，易受黑天鹅冲击 |
| **名义利率** | TNX 4.14% (6月+16%) | 高位震荡，短期趋稳但未下行 |
| **美元** | DXY 97.98 (-3.2%) | 走弱，利好非美资产与大宗商品 |
| **实际利率** | TIP +10.6% | 显著下行，黄金核心利好确认 |

**结论**：当前是典型的**"弱美元+实际利率下行"组合**，对黄金/商品形成双击。但VIX过低（自满）+名义利率仍高，意味着风险偏好随时可能反转。整体偏乐观，建议**维持/小幅加仓**，但保留对冲仓位。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 价格2年分位92%处于历史高位，估值偏高风险
  - RSI(14) 47.69中性偏弱，无超买超卖信号
  - MA20与MA120 spread仅2.93%，趋势动能不足
ONE_LINER: 价格高位震荡，RSI中性且量能不足，REGIME为range_bound下无明确方向，支撑在MA120(54.95)附近，阻力需观前高。

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，假设中性配置；NDQ.AX 为单一市场（纳斯达克）ETF，建议单资产仓位上限 25-30%，单一市场敞口 ≤40%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-12-25 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-07-28
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.35)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-28",
  "vix": 15.03,
  "tnx": 4.42,
  "usdcny": 7.1535,
  "audcny": 4.7002
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.35
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - N/A

RISK_PLAN:
  stop_loss_trigger: VIX 突破 20 并站稳，同时 NDQ.AX 跌破 50 日均线 → 视为趋势反转信号，应清仓观望
  what_if_wrong:
    worst_case_pnl_cny: 0 (当前无持仓)
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 当前为回测模式，无真实持仓数据，风险评估基础薄弱。
  - 本次建议（HOLD）不涉及新增资金投入。
  - 在数据不全且宏观信号分裂（美元崩塌与利率飙升并存）时，保持观望、等待更清晰信号是纪律的体现。Quant 的看涨技术面被高估值（价格分位100%）和 Macro 的中性信号所抵消，风险数据缺失更应谨慎。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y国债收益率飙至4.42%（月涨42%），金融条件快速收紧压制风险资产估值
KEY_TAILWIND: 美元月跌9.24%叠加实际利率下行，黄金/商品迎来罕见"双击"窗口
ONE_LINER: VIX低位+美元崩塌偏risk_on，但长端利率飙升敲警钟——黄金可加仓，风险资产维持观望
```

**补充视角**：当前宏观呈现"分裂"格局——表面恐慌极低（VIX 15），但10Y利率单月暴涨42%属于异常信号，通常预示债市对通胀或财政可持续性的担忧升温。美元指数跌破99关口是本轮最大变量，若趋势延续将显著利好新兴市场与大宗商品。需密切关注本周联储表态是否试图"校正"市场预期。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 6
KEY_DATA:
  - 价格离MA120偏离度9.19%，低于15%阈值，均值回归风险低
  - RSI 67.88，处于中性偏强区间未超买，支持上涨动能
  - MA20与MA120价差6.97%稳定，未明显收窄，趋势未衰竭
  - 价格分位100%，历史高位估值偏高，需警惕回调
ONE_LINER: 上升趋势技术面健康，价格创新高但未超买，SIGNAL bullish与REGIME uptrend一致，阻力位关注53.5附近，高位风险增加。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A (回测模式，无持仓快照)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无真实持仓数据，假设中性持仓无极端集中风险；建议实盘上线后以单资产≤30%为集中度红线，首次建仓不超过可投资金的20%。
```

**补充说明**：

1. **数据缺失**: 回测模式下 portfolio_summary 未提供，集中度/浮盈/现金等核心风险指标均无法计算，标记 N/A 而非编造。

2. **Dreaming 查询跳过**: 无真实用户历史记录，行为模式分析不适用。

3. **Committee 一致性**: 回测场景无法调取历史裁决，风险评估独立于过往决策。

4. **风险默认立场**: 在无持仓数据情况下，取保守中性评估（STRENGTH=3），不擅自升级 SIGNAL——避免因缺失数据而误判。实盘接入后应重新评估。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-28 > cutoff 2024-12-31)

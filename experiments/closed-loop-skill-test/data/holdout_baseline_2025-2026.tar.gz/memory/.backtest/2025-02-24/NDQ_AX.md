# Committee: NDQ.AX

**Date**: 2025-02-24
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.60)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-02-24",
  "vix": 18.98,
  "tnx": 4.393,
  "usdcny": 7.25,
  "audcny": 4.618
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.6
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A
EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []
RISK_PLAN:
  stop_loss_trigger: 价格跌破近期支撑平台（需结合技术位，如纳斯达克100指数关键均线），或 ^VIX 突破并站稳20以上 → 考虑减仓20%-30%
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无真实持仓数据）
    recovery_estimate: N/A（回测模式无真实持仓数据）
PERSONAL_NOTE:
  - 当前处于回测模式，假设持仓中性，无极端集中或显著盈亏。
  - 基于当前信号，本次建议维持现状，不新增投入，等待更明确的技术或宏观信号。
  - 在“10Y收益率月暴涨77%+DXY飙升8.3%”的宏观收紧背景下，NDQ作为高贝塔科技资产面临额外压力，尽管VIX未飙升，但应保持耐心，避免在趋势未明时追高或抄底。


---

## Macro Strategist (shared)

SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 10Y收益率月暴涨77%叠加DXY飙升8.3%，实际利率上行，美元与实际利率双杀黄金/商品类资产
KEY_TAILWIND: VIX仍低于20，市场恐慌尚未爆发，软着陆叙事尚存
ONE_LINER: 利率急升+强美元=金融条件快速收紧，整体偏防御，建议减仓或维持低仓位


---

## Round 1 — Independent Briefs


### Quant Analyst
```json
{
  "tool": "analyze_multi_timeframe",
  "inputs": {
    "symbol": "NDQ.AX"
  }
}
```

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无真实持仓数据，假设中性持仓下风险基线正常；实盘建议单资产集中度≤30%，NDQ属科技集中型ETF，极端回撤风险高于宽基。
```

**补充说明**：

回测模式下无法调用持仓明细，以上字段标记 N/A。根据预设假设（中性持仓、无极端集中），风险基线为低关注。

若切换实盘，需重点关注：
1. **NDQ 行业集中度**：科技/通信占比 >70%，纳斯达克 100 单市场暴露，2022 年曾回撤 -33%
2. **建议建仓上限**：总资产 25-30%（单一主题型 ETF）
3. **压力测试参考**：历史极端情境下该标的 -20% 回撤周期约 2-4 个月，需确认用户心理承受与流动性缓冲


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-02-24 > cutoff 2024-12-31)

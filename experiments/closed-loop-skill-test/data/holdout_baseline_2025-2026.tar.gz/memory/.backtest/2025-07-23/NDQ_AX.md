# Committee: NDQ.AX

**Date**: 2025-07-23
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.40)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-07-23",
  "vix": 15.37,
  "tnx": 4.388,
  "usdcny": 7.1743,
  "audcny": 4.702
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.4
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels: []

RISK_PLAN:
  stop_loss_trigger: 股价跌破量化支撑位48.15 CNY，同时^VIX > 20 → 考虑启动防御性减仓
  what_if_wrong:
    worst_case_pnl_cny: 若从当前价位回调20%至支撑位附近，以10万持仓计，浮亏约2万CNY
    recovery_estimate: 3-6个月，基于历史均值回归周期

PERSONAL_NOTE:
  - 回测模式下假设用户持仓中性，但Risk Officer报告数据缺失，无法进行精确的风险评估，这是本次裁决的主要不确定性来源。
  - 当前NDQ.AX价格处于2年极高分位(99%)，量化信号虽为bullish但动能减弱，且宏观名义利率构成压制，综合评估风险收益比不佳。
  - 操作纪律建议：在风险评估不完整且估值极端的背景下，保持耐心是首要原则。应等待价格回落至更合理估值区间（如接近MA120的48.15）或风险评估数据明确后，再考虑下一步行动。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: 2
KEY_HEADWIND: 10Y国债收益率4.39%维持高位，名义利率压力未消，对长久期资产构成压制。
KEY_TAILWIND: 美元指数跌至97.2（3个月新低）+TIP月涨3.67%实际利率下行，黄金/商品获货币双击；VIX 15.4接近complacency区。
ONE_LINER: 弱美元+实际利率下行构筑宽松金融环境，宏观偏暖，风险资产可维持偏多配置；但名义利率高企限制大幅加仓空间，建议维持或小幅加仓。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bullish
STRENGTH: 4
KEY_DATA:
  - 价格离MA120偏离7.61%，均值回归风险适中
  - RSI 61.05中性偏多，未超买
  - MA20/MA120差6.60%，但一周跌-0.59%提示动能减弱
  - 价格2年分位99%，估值显著偏高
ONE_LINER: uptrend中，RSI与MA支撑bullish，但极高位分位增加回调风险，支撑位MA120 48.15。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，无法评估具体风险，但数据缺失本身构成评估障碍。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-07-23 > cutoff 2024-12-31)

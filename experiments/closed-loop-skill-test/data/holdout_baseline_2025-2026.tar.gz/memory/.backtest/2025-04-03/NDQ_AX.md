# Committee: NDQ.AX

**Date**: 2025-04-03
**Symbol**: NDQ.AX
**Verdict**: TRIM (confidence 0.72)
**Dominant view**: macro
**Suggested allocation CNY**: -60000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-04-03",
  "vix": 30.02,
  "tnx": 4.055,
  "usdcny": 7.2675,
  "audcny": 4.553
}
```

---

## CIO Memo (Round 3)

VERDICT: TRIM
CONFIDENCE: 0.72
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: -60000
TRIM_REASON: bearish
REENTRY_PRICE: 42
REENTRY_CONDITION: 价格回落至 $42 附近（2年分位约50%）且 RSI 低于 30 出现超卖反转信号，同时 VIX 回落至 20 以下且 10Y 收益率稳定在 3.8% 以下
EXPECTED_PATH: 当前处于 Quant 确认的 downtrend（MA250 跌破+1.35倍放量），价格在 2 年 76th 分位偏高；历史 downtrend 中从高位分位向 50th 分位均值回归的概率较高，RSI 33 尚未进入超卖区仍有下探空间，阻力位 MA120（48.23）短期难以收复

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "本轮为减仓操作，不涉及加仓"
    - "待重新触发条件满足后在 $42 附近分批回补"

RISK_PLAN:
  stop_loss_trigger: 若价格反弹至 MA120（48.23）上方且 VIX 跌破 18 → 空头逻辑失效，需在该位置止损平掉减仓部分（回补）
  what_if_wrong:
    worst_case_pnl_cny: -30000（减仓后价格反弹约 5%，踏空损失）
    recovery_estimate: 若误判，1-2 周内 VIX 回落+价格站上 MA120 即可确认反转并回补

PERSONAL_NOTE:
  - 回测模式下无精确持仓数据，基于中性假设评估：当前价格在 2 年 76th 分位历史偏高，且已跌破 MA250 关键支撑（1.35 倍放量确认），趋势破位信号明确
  - 本次建议减仓约 ¥60,000，回测模式下无法精确计算占仓位比例，但属中等力度减仓而非清仓
  - Macro 的 10Y 收益率月涨近 30% 至 4.05% 是本轮核心压力源——融资成本飙升直接压缩成长股估值倍数；VIX 维持 30 说明市场恐慌未退，这不是"回调买入"的环境，而是"保护本金"的环境。纪律上：宁可少赚不可大亏，跌到 42 附近有超卖信号再考虑回补


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 10Y收益率月涨近30%至4.05%，融资成本飙升压制风险资产估值，VIX维持30高位恐慌未退
KEY_TAILWIND: 美元走弱(DXY-1.52%)叠加实际利率下行(TIP+4%)，黄金获货币端双重利好
ONE_LINER: 利率跳升+高波动=减仓信号明确，但黄金/商品因美元与实际利率双击可独立持有
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: bearish
STRENGTH: 7
KEY_DATA:
  - 价格2年分位76%，历史高位风险
  - RSI 33.20偏弱，但未超卖
  - 跌破MA250且成交量1.35倍，趋势确认
ONE_LINER: 下跌趋势中，价格高位跌破MA250支撑，RSI偏弱，维持bearish信号，阻力看MA120（48.23）。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无法获取实际持仓、成本及现金数据，无法评估集中度与流动性风险。决策需完全基于技术与宏观信号。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-04-03 > cutoff 2024-12-31)

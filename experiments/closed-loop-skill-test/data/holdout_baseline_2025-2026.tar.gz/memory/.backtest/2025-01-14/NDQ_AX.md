# Committee: NDQ.AX

**Date**: 2025-01-14
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 25000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-14",
  "vix": 18.71,
  "tnx": 4.788,
  "usdcny": 7.3298,
  "audcny": 4.538
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 25000

TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: grid
  first_tranche_cny: 25000
  add_levels:
    - if price drops 5% from current → add ¥25000
    - if price drops 10% from current → add ¥40000
    - if price drops to 2年估值中位数附近(约80%分位) → add ¥50000

RISK_PLAN:
  stop_loss_trigger: 价格跌破 MA120（偏离度归零）且 VIX > 25 → 减仓 50%；若 DXY 突破 112 → 清仓
  what_if_wrong:
    worst_case_pnl_cny: -3750（首笔25000的-15%）
    recovery_estimate: 6-12个月（参考历史均值回归周期）

PERSONAL_NOTE:
  - 当前NDQ.AX处于2年历史96%极高估值分位，价格偏离MA120达15.11%，均值回归风险极高——这是本次仅给试探仓而非满仓的核心原因。RSI 49.89中性偏弱，说明上涨动能已显疲态
  - 本次仅建25000元试探仓，占典型子弹约5%，后续5%/10%回踩分批加码，大部分子弹留给更低位
  - **uptrend中ACCUMULATE三问检查**：(1)价格偏离MA120达15.11%，>15%阈值，均值回归风险高——但RSI未超买，说明不是疯狂追涨阶段，属高位盘整；(2)Macro报告VIX月跌23%至18.7，未见恐慌升温信号，暂无急跌前兆；(3)若30天后跌10%，当前买入理由仍成立，因为核心逻辑是"在上升趋势中用小仓位参与、留子弹等更低价位"，而非"赌趋势延续"——即使跌10%，后续网格加码拉低均价，整体风险可控
  - 回测模式无持仓数据，当前仅为技术面+宏观面独立判断；建议实际操作时需结合真实持仓集中度和现金余额调整

---

**裁决逻辑说明**：

Quant / Macro / Risk 三方信号均处于 neutral 区间，无明显多空分歧。核心矛盾在于：
- **利多**：uptrend regime + VIX回落恐慌消退 + RSI中性无超买
- **利空**：96%估值分位极高 + MA120偏离15.11% + TNX暴涨134%利率环境严苛 + DXY 109+强美元虹吸

三方一致中性偏谨慎，Risk Officer仅给"concerned"而非"high_risk"，未触发强制降级规则。综合评估后给ACCUMULATE（小试探仓），而非HOLD或BUY——因为趋势仍在但估值极贵，最优策略是"留90%子弹等更低价位"，而非零仓位裸等回调（那是时点赌博）或一次性满仓追高（96%分位不允许）。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: 0
KEY_HEADWIND: DXY 109+强势美元叠加实际利率上行，黄金/商品遭遇双杀压力
KEY_TAILWIND: VIX回落至18.7，恐慌情绪显著消退，风险偏好边际改善
ONE_LINER: 利率飙升+强美元压制大类资产，但恐慌退潮提供缓冲，建议维持仓位观察利率拐点
```

**补充判断逻辑**：
- TNX月涨+134%极为罕见，金融条件急剧收紧，对估值类资产形成重压
- DXY 109+已接近历史高位区间，美元虹吸效应明显
- TIP月跌-3.7%确认实际利率上行趋势，黄金货币因素偏空
- VIX月跌-23%是唯一亮点，说明市场尚未进入恐慌模式，处于"钝痛"而非"剧痛"阶段

**结论**：当前宏观环境处于"紧缩未完、恐慌未起"的尴尬地带，无明确方向性信号，不宜激进加仓或大幅减仓。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 6
KEY_DATA:
  - 价格处于2年历史96%分位，估值偏高
  - RSI 49.89 中性，未超买
  - 价格偏离MA120达15.11%，均值回归风险高
ONE_LINER: 上升趋势中但价格分位极高且偏离度大，处于高位盘整状态，建议观望。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式缺乏具体持仓数据，无法精确评估集中度与风险敞口。在无当前持仓背景下，任何单次加仓建议占可投资现金比例上限15%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-14 > cutoff 2024-12-31)

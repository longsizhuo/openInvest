# Committee: NDQ.AX

**Date**: 2025-05-05
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.55)
**Dominant view**: quant
**Suggested allocation CNY**: 20000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-05",
  "vix": 23.64,
  "tnx": 4.343,
  "usdcny": 7.2706,
  "audcny": 4.6864
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.55
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 20000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 8000
  add_levels:
    - 价格跌至 MA250 支撑 45.37 附近（约 -5%）→ 加仓 ¥6,000
    - 价格跌破 44.0（约 -8%，进入更深层支撑区）→ 加仓 ¥6,000

RISK_PLAN:
  stop_loss_trigger: 收盘价跌破 42.0（MA250 下方约 -7%）且 VIX 仍 > 22 → 清仓止损
  what_if_wrong:
    worst_case_pnl_cny: -4000（假设全部建仓后跌 20%）
    recovery_estimate: 6-9 个月（下降趋势中恢复通常较慢）

PERSONAL_NOTE:
  - 回测模式下无真实持仓快照，Risk Officer 评估强度仅为 3（所有指标 N/A），风险判断置信度受限，需待真实数据后重新校验。
  - 本次建仓 ¥20,000 仅作试探性底仓，在假设子弹规模下占比极小（约 5% 级别），保留充足弹药等待趋势确认。
  - Quant 确认 downtrend（MA20 低于 MA120 约 9.1%），价格位于 2 年 80 分位偏贵区间——这不是追涨的环境。三线中性无一方强烈看多，核心纪律是"小仓试探、低位加码、严守止损"。若价格反弹站上 MA120 并放量突破，再考虑加速建仓；若跌破 42.0 支撑则果断认错离场。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: 0
KEY_HEADWIND: 10Y国债收益率月涨46%至4.34%，对风险资产估值形成重压
KEY_TAILWIND: 美元指数跌破100关口（-2.64%）叠加实际利率下行（TIP+1.76%），黄金/商品获双重货币支撑
ONE_LINER: 债市恐慌与美元走弱形成拉锯——整体维持现有配置，但黄金/商品端可适度偏向加仓
```

**逻辑补充**：
- VIX从30.57回落至23.64，恐慌情绪正在消退，但仍在20以上的"恐惧区"
- 美元DXY近期在99附近震荡企稳，尚未破位，但趋势偏弱
- 核心矛盾：名义利率飙升（财政/通胀预期重定价）vs 美元走弱+实际利率下行——后者为黄金提供结构性支撑，前者压制股票久期资产
- **如组合含黄金**：当前"弱美元+实际利率下行"构成明确双击环境


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: downtrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格分位2年80%高位，估值偏高
  - RSI 53.88中性，无超买超卖信号
  - MA20低于MA120 -9.10%，下降趋势确认
ONE_LINER: 下降趋势中价格高位盘整于MA250支撑45.37附近，RSI中性，SIGNAL neutral与REGIME downtrend一致，等待方向突破。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，无持仓快照）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无真实持仓数据，假设中性分散持仓；NDQ.AX 单一资产建议建仓比例上限 25%，若后续有集中度数据再评估是否需减仓。
```

**补充说明**：
- 本评估基于"中性持仓"假设，无法调用 Dreaming Insights（无历史行为数据）
- 回测模式下缺乏 portfolio_summary，所有量化指标标为 N/A
- STRENGTH=3 仅基于假设条件，实际风险需待真实持仓数据后重新评估
- 建议 CIO 在回测结束后获取完整持仓快照，再做正式风险判定


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-05 > cutoff 2024-12-31)

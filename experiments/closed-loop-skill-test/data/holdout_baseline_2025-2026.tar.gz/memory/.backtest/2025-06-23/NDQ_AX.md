# Committee: NDQ.AX

**Date**: 2025-06-23
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.65)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-23",
  "vix": 19.83,
  "tnx": 4.32,
  "usdcny": 7.188,
  "audcny": 4.6334
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.65
DOMINANT_VIEW: quant
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若价格回调至 MA120 (47.99) 且 RSI<50 → 可试探建仓 5-10% 子弹"
    - "若价格突破 50 并放量 → 视 regime 切换信号再议"

RISK_PLAN:
  stop_loss_trigger: "若已持仓：跌破 47.99（MA120）同日收盘 → 减仓 30%"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式无持仓数据）
    recovery_estimate: "range_bound 区间内，若从高点回落至 MA120 约 -2.2%，2-4 周可恢复"

PERSONAL_NOTE:
  - 价格处于 2 年分位 90% 的历史高位，当前属于"追高禁区"——Quant 明确指出回调风险累积，不值得在此位置建仓。
  - 回测模式无持仓上下文，但从纯信号角度：三方均 neutral/ok，无任何方向性催化剂，典型"不值得动"的状态。
  - 宏观层面 10Y 收益率飙升 (+55% MoM) 对利率敏感型资产（含科技权重的 NDQ）构成估值压制，Macro 原话"利率敏感型资产维持偏谨慎"。
  - 操作纪律：区间震荡行情最忌追涨杀跌，耐心等待价格回测 MA120 支撑或 regime 从 range_bound 切换至 uptrend 再行动。别被"怕错过"驱动——VIX 已回落但收益率还在飙升，这不是安全的全面做多环境。
```


---

## Macro Strategist (shared)

**宏观评估**

| 字段 | 判断 |
|------|------|
| **SIGNAL** | `neutral` |
| **STRENGTH** | 4 |
| **SCORE** | **+1** |
| **KEY_HEADWIND** | 10Y收益率飙升至4.32%（MoM +55%），名义利率快速上行压制风险资产估值，反映通胀预期或期限溢价抬升。 |
| **KEY_TAILWIND** | DXY跌至98.42逼近三年低点（MoM -7.46%），叠加TIP +3.78%实际利率下行，构成黄金/商品"双击"环境。 |
| **ONE_LINER** | 恐慌回落（VIX<20）+美元崩跌抵消收益率利空，宏观中性偏暖；**黄金/商品类维持偏多，利率敏感型资产维持偏谨慎**，整体维持持仓不加不减。 |

**关键逻辑**：名义利率暴涨但实际利率在降→通胀预期上行驱动而非紧缩驱动→弱美元环境下商品对冲价值凸显。短期风险在于收益率若突破4.5%可能触发risk-off。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位90%，历史高位，回调风险累积
  - RSI 61.59，中性偏强但未超买（<70）
  - MA20(49.08)与MA120(47.99)仅差2.27%，趋势强度不足
ONE_LINER: range_bound下价格于高位震荡，支撑在MA120(47.99)，RSI中性未突破，SIGNAL为neutral。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，持仓未还原）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式无持仓数据，基于中性假设无集中度风险信号，建议建仓比例上限25-30%（单一ETF行业标准）。
```


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-23 > cutoff 2024-12-31)

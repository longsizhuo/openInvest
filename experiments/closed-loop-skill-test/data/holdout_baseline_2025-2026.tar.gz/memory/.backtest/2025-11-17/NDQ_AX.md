# Committee: NDQ.AX

**Date**: 2025-11-17
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.48)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-17",
  "vix": 22.38,
  "tnx": 4.133,
  "usdcny": 7.0992,
  "audcny": 4.6379
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.48
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若NDQ.AX回调至现价-5%且VIX回落至<20 → 启动首轮试探仓 ¥11,000（子弹5%）"
    - "若继续回调至-8%且RSI<40 → 第二轮加仓 ¥22,000（子弹10%）"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX跌破近60日低点或VIX突破30 → 暂停一切加仓计划，已有仓位考虑减半"
  what_if_wrong:
    worst_case_pnl_cny: -15068（基于当前持仓223789×6.72%最坏情景）
    recovery_estimate: "3-6个月（纳指历史深度回撤典型恢复周期）"

PERSONAL_NOTE:
  - "当前NDQ.AX仓位33.6%处于中性水平，微亏-1.2%，风险可控，无被迫操作压力"
  - "本次建议不动用子弹（¥0），但预留回调加仓条件；若触发两档条件，累计动用约15%子弹（¥33,000）"
  - "为什么不加仓比加仓好：①Macro给的是neutral而非bullish，名义利率TNX月涨12%至4.13%直接压缩纳指成长股估值，这是NDQ.AX的核心逆风而非顺风；②Quant分析缺失导致技术面判断空白，缺少趋势强度和动量确认，此时加仓等于盲打；③宏观格局撕裂——美元崩塌+实际利率骤降的真正受益者是黄金和商品，而非纳指；当前环境纳指并非最优风险收益比标的，宁等Quant信号回归+利率压力缓解后再行加仓"
  - "纪律提示：设好回调网格但不要提前预判底部。VIX仍在22以上，市场情绪偏紧，耐心比勇气更值钱"


---

## Macro Strategist (shared)

根据你提供的宏观数据，直接输出判断：

---

```
SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: TNX 月涨12%突破4.1%，名义利率快速上行压制风险资产估值
KEY_TAILWIND: DXY跌破100(-4.6%)叠加实际利率骤降(TIP+12%)，黄金/商品双击窗口开启
ONE_LINER: 短端利率+恐慌双升但美元崩塌对冲，组合含黄金可维持偏多，纯权益端维持中性不加仓
```

---

**核心逻辑拆解**：

| 因素 | 方向 | 权重 |
|------|------|------|
| DXY 美元指数 99.59（月跌4.6%） | 🟢 强利好（尤其黄金） | ★★★★ |
| TIP 月涨12%（实际利率暴跌） | 🟢 强利好（尤其黄金） | ★★★★ |
| TNX 4.13%（月涨12%） | 🔴 利空（估值压缩） | ★★★ |
| VIX 22.38（月涨4%） | 🟡 偏高但非恐慌 | ★★ |

**结论**：宏观环境呈现"利率上行+美元崩塌"的撕裂格局。**黄金/商品类资产处于双击（DXY↓ + 实际利率↓）**，这是本轮最强宏观顺风；但权益端受名义利率上行压制，不宜激进加仓。**维持 > 加仓 > 减仓**。


---

## Round 1 — Independent Briefs


### Quant Analyst
我需要调用工具来获取多周期数据以进行更详细的分析，特别是为了完成 uptrend 衰竭检查。

```json
{
  "tool": "analyze_multi_timeframe",
  "input": {
    "symbol": "NDQ.AX"
  }
}
```

### Risk Officer
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: 33.6%
DRY_POWDER_CNY: 223,789
PNL_PCT: -1.2%
WORST_CASE_LOSS_PCT_AT_-20: -6.72%
ONE_LINER: 集中度健康，现金充裕，微亏无压力，建议回调时可适度加仓，建仓比例上限30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-17 > cutoff 2024-12-31)

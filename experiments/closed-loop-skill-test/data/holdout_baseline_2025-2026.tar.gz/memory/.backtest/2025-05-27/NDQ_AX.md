# Committee: NDQ.AX

**Date**: 2025-05-27
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-05-27",
  "vix": 18.96,
  "tnx": 4.434,
  "usdcny": 7.2037,
  "audcny": 4.6686
}
```

---

## CIO Memo (Round 3)

```
VERDICT: HOLD
CONFIDENCE: 0.50
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无加仓计划；三方信号均为中性，等待方向明确"

RISK_PLAN:
  stop_loss_trigger: "若持仓存在且价格跌破 MA120（约当前价 -2%）同时 VIX 重新站上 22 → 考虑减仓 20%"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式，无具体持仓金额）
    recovery_estimate: "N/A — 当前不建新仓，不存在新增浮亏风险"

PERSONAL_NOTE:
  - 回测模式下假设持仓中性，无极端集中度；NDQ.AX 当前价格处于历史 86 分位，估值偏贵，不是加仓的理想位置
  - 核心矛盾在宏观层：10Y 收益率单月暴涨 43% 至 4.43%，名义利率飙升对 Nasdaq 纯多头 ETF 构成直接估值压缩；虽然美元破 100 + 实际利率下行构成利好，但那是黄金/商品的故事，不是科技成长股的故事
  - Quant 给 range_bound + 价格在 MA120 遇阻、成交量低迷，RSI 59.87 中性偏强但无突破动能 → 技术面不支持追高
  - 三项检查清单（虽非 uptrend 但主动执行）：(1) 价格偏离 MA120 约 -2% 而非 >15%，均线回归压力有限；(2) VIX 从近期高位回落至 19 但 TNX 飙升意味着利率端的真实压力未消；(3) 若 30 天后跌 10%，当前中性信号下的买入逻辑同样不成立 → 确认 HOLD 正确
  - 心理纪律：三方一致"无方向"时最难的是忍住不动手；等 Quant 转 bullish（突破 MA120 + 放量）或 Macro 转 risk_on（TNX 回落 < 4.0%）再行动
```


---

## Macro Strategist (shared)

**宏观快照已确认** — 数据与参考一致。以下为判断：

---

```
SIGNAL: neutral
STRENGTH: 5
SCORE: +1
KEY_HEADWIND: 10Y收益率单月暴涨43%至4.43%，名义利率飙升压制成长股估值
KEY_TAILWIND: 美元跌至99.5（月跌5.4%）+实际利率下行（TIP月涨5.1%），黄金面临双击环境
ONE_LINER: 维持现有仓位；VIX回落至19表明恐慌消退，但TNX飙升令权益类需谨慎；DXY破百+实际利率降=黄金/商品可适度加仓
```

---

**逻辑拆解：**

| 指标 | 信号 | 方向 |
|------|------|------|
| VIX 18.96（月跌33%） | 恐慌消退 | ✅ risk_on |
| TNX 4.43%（月涨43%） | 名义利率飙升 | ❌ risk_off |
| DXY 99.52（破100） | 美元弱势 | ✅ 黄金利好 |
| TIP +5.1%（月） | 实际利率下行 | ✅ 黄金利好 |

**核心矛盾：** TNX暴涨但DXY反向走弱 + 实际利率下行 → 市场定价的是**通胀预期升温**而非增长强劲。这种组合下，黄金/商品受益明显，权益类资产面临估值重估压力。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - 价格分位86%处历史高位，估值偏高风险  
  - RSI 59.87中性偏强，未超买  
  - MA20与MA120纠缠（-1.94%），趋势不明，成交量低  
ONE_LINER: 震荡市中价格触及MA120阻力，技术指标中性，无明确方向，建议观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下持仓中性，无极端风险数据，建议建仓比例上限不超过总资产的30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-05-27 > cutoff 2024-12-31)

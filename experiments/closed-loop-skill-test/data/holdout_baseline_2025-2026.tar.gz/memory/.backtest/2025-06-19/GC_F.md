# Committee: GC=F

**Date**: 2025-06-19
**Symbol**: GC=F
**Verdict**: ACCUMULATE (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 18000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-19",
  "vix": 20.14,
  "tnx": 4.397,
  "usdcny": 7.1888,
  "audcny": 4.6776
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 18000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 18000
  add_levels:
    - if price drops 3% → add ¥15000
    - if price drops 6% → add ¥20000

RISK_PLAN:
  stop_loss_trigger: gold spot跌至 $3100 (≈¥710/g) 且 VIX > 25 → 减仓50%
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: 4-6个月

PERSONAL_NOTE:
  - 用户无持仓，子弹充足，但黄金价格处于2年分位99%极高位，Quant明确因高位风险选择neutral，此处Quant的谨慎即是对估值泡沫的量化警告，不可盲目追多。
  - 本次投入¥18000占子弹约5.7%，属于保守试探仓；Macro美元塌陷+实际利率下行构成黄金双击格局是建仓核心逻辑，但高分位必须用仓位纪律对冲。
  - uptrend中ACCUMULATE三检：①价格离MA120偏离11.29%<15%阈值，均值回归压力可控；②VIX≈20处于中性区间，未见恐慌急升；③若30天后跌10%，黄金避险属性+美元弱周期仍在，逻辑仍成立，但99%分位意味着只能小仓建底、留弹药等回调而非追高。


---

## Macro Strategist (shared)

```
SIGNAL: neutral
STRENGTH: 5
SCORE: -1
KEY_HEADWIND: 10Y国债收益率单月暴涨58%，名义利率飙升压制风险资产估值
KEY_TAILWIND: 美元指数月跌7.7%+实际利率下行，双击格局利好黄金与大宗商品
ONE_LINER: 名义利率急升与美元走弱矛盾并存，风险资产中性偏谨慎，黄金/商品类维持偏多
```

**核心判断**：
- **利率警报**：TNX 4.4% 月涨近六成，这是近期最大宏观变量，直接压缩成长股久期价值。
- **美元塌陷**：DXY 跌破99是重大信号，结合实际利率下行（TIP +3.3%），形成**黄金双击**环境。
- **情绪面**：VIX 20但回落，恐慌未升级，市场在消化利率冲击。

**结论**：宏观呈分裂态——对股票中性偏空（利率压制），对黄金/商品中性偏多（货币双击）。整体SCORE给-1，不激进减仓但需警惕利率路径进一步恶化的尾部风险。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: neutral  
STRENGTH: 6  
KEY_DATA:  
  - 价格2年分位99%，处于历史极高位，估值偏高  
  - RSI 57.16 中性，未超买但无上涨动力  
  - 价格离MA120偏离度11.29%，低于15%风险阈值，均值回归压力中等  
  - MA20>MA120 9.81%支撑趋势，但30日回报-0.63%显示短期疲软  
ONE_LINER: 上升趋势中价格触及99%分位高位，RSI中性但短期动能减弱，REGIME uptrend 下选择neutral 以规避高位回调风险。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式假设中性持仓，无极端风险，建议建仓比例上限为总资产的35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-19 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-06-19
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.58)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-19",
  "vix": 20.14,
  "tnx": 4.397,
  "usdcny": 7.1888,
  "audcny": 4.6776
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.58
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "无主动建仓/加仓动作"
    - "若后续 Macro 转为 risk_on 且价格回踩 MA120 附近（约当前价 -5%），重新评估入场"

RISK_PLAN:
  stop_loss_trigger: "10Y 美债收益率持续站稳 4.5% 以上且 VIX 重新攀升至 25+ → 若持有仓位考虑减仓；当前无持仓则维持空仓"
  what_if_wrong:
    worst_case_pnl_cny: 0
    recovery_estimate: "N/A（当前无仓位，踏空风险而非亏损风险）"

PERSONAL_NOTE:
  - 当前 NDQ.AX 处于 2 年价格分位 88% 的高位区间，估值显著偏贵，配合长端利率飙至 4.4% 的"利率风暴"环境，NASDAQ 类权益资产面临估值压缩的系统性压力，此时追高风险大于踏空风险。
  - Macro 风险信号（risk_off, strength 6）是本次决策的主导因素：名义利率暴涨 + 通胀预期推升 = 财政主导/滞胀定价，这正是科技成长股最不利的宏观组合；Quant 给出 neutral（RSI 58、MA 纠缠）并未提供逆势做多的强力理由。
  - 操守建议：回测模式下无实际持仓压力，但本次裁决的核心纪律是——**在"利率风暴 + 估值高位"的双重压制下，不做英雄式抄底**。等待两条确认信号再行动：①10Y 收益率回落至 4.0% 以下，②RSI 跌入 40-45 超卖区。在此之前，空仓等待本身就是一种积极的风险管理。


---

## Macro Strategist (shared)

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2.5
KEY_HEADWIND: 10Y收益率飙至4.4%（MoM+58%），估值压缩风险极高，长端利率风暴压制风险资产。
KEY_TAILWIND: 美元指数跌破99（MoM-7.7%）+实际利率下行（TIP+3.3%），黄金获双击利好。
ONE_LINERS: 利率风暴下维持防御，黄金/商品可持有，权益类倾向减仓观望。
```

**核心逻辑**：名义利率暴涨但实际利率却在下降——通胀预期被大幅推升，市场在定价"财政主导"或滞胀风险。VIX虽从高位回落但仍>20，恐慌未完全消散。美元走弱+实际利率下行构成黄金双击环境，但长端利率飙升对权益类资产构成系统性压制。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: neutral
STRENGTH: 4
KEY_DATA:
  - 2年价格分位88%，处于历史高位，估值偏高
  - RSI 58.81，中性区间无超买超卖
  - MA20与MA120仅差1.96%，趋势纠缠不明确
  - RVOL 1.37x，量能略增但无异常突破
ONE_LINER: 价格高位盘整且MA纠缠，RSI中性，震荡区间内无明确趋势，SIGNAL为neutral，支撑位MA250 46.19，阻力位近期高点。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，假设持仓中性，无极端风险。建议单资产建仓比例上限为投资组合的10%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-19 > cutoff 2024-12-31)

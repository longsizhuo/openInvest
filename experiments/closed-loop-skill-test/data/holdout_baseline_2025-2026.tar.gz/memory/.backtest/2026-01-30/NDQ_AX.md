# Committee: NDQ.AX

**Date**: 2026-01-30
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: risk
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2026-01-30",
  "vix": 17.44,
  "tnx": 4.241,
  "usdcny": 6.948,
  "audcny": 4.8966
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD  
CONFIDENCE: 0.5  
DOMINANT_VIEW: risk  
SUGGESTED_ALLOC_CNY: 0  
TRIM_REASON: N/A  
REENTRY_PRICE: N/A  
REENTRY_CONDITION: N/A  
EXPECTED_PATH: N/A  

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - 无加仓计划

RISK_PLAN:
  stop_loss_trigger: 若已持有，价格跌破 MA250（51.93）且 VIX 升破 25 则减仓 50%
  what_if_wrong:
    worst_case_pnl_cny: 0（因无新增仓位）
    recovery_estimate: N/A

PERSONAL_NOTE:
  - 回测模式下无法获取实际持仓数据，假设用户持仓中性（无极端集中度）。
  - 本次建议不新增仓位，观望为主，占子弹比例 0%。
  - 价格处于两年高位 82% 分位且 RSI 超卖，短期或有反弹但宏观利率上行压制估值，需等待趋势明朗后再行动。


---

## Macro Strategist (shared)

SIGNAL: neutral
STRENGTH: 4
SCORE: +1
KEY_HEADWIND: 10Y国债收益率月涨6.48%，名义利率上行压制风险资产估值
KEY_TAILWIND: 美元月贬8.21%叠加实际利率大幅下行，黄金遭遇"双击"利好环境
ONE_LINER: 混合信号——VIX回落+美元崩跌利好商品/黄金，但名义利率上行制约整体风险偏好，整体维持观望，黄金相关资产可偏积极


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 4  
KEY_DATA:  
  - 价格2年分位82%，处于历史高位  
  - RSI 31.05，进入超卖区域  
  - MA20(55.594)与MA120(55.588)几乎重合，趋势不明  
ONE_LINER: 在区间震荡中，价格高位但RSI超卖显示短期抛压，阻力MA120(55.59)，支撑MA250(51.93)，信号中性。

### Risk Officer
SIGNAL: high_risk
STRENGTH: 10
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无持仓与资金数据，无法评估实际风险，建议在回测验证前保持极低仓位或空仓。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2026-01-30 > cutoff 2024-12-31)

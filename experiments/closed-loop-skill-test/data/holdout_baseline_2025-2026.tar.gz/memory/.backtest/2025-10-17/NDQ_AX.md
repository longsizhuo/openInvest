# Committee: NDQ.AX

**Date**: 2025-10-17
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.45)
**Dominant view**: risk
**Suggested allocation CNY**: 100000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-10-17",
  "vix": 20.78,
  "tnx": 4.007,
  "usdcny": 7.123,
  "audcny": 4.6172
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.45
DOMINANT_VIEW: risk
SUGGESTED_ALLOC_CNY: 100000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 30000
  add_levels:
    - 若价格回撤 3% → 加仓 ¥30,000（累计 60K）
    - 若价格回撤 5% → 加仓 ¥40,000（累计 100K）
  reasoning: 价格处于2年99%分位 + Quant bearish 强度7构成背离，不宜一次性建满；金字塔分批留 70% 子弹等待更深回调

RISK_PLAN:
  stop_loss_trigger: NDQ.AX 较当前价下跌 8% 且 VIX > 25 → 减仓 30%
  what_if_wrong:
    worst_case_pnl_cny: -20000
    recovery_estimate: 3-6 个月

PERSONAL_NOTE:
  - 当前为回测模式，假设中性持仓（无极端集中度、无浮盈浮亏），无法获取精确现金流数据
  - 首笔 ¥30,000 为试探仓，约占总额 30%，保留 70% 子弹应对可能的均值回归
  - **uptrend 怀疑清单检查**：① MA120 偏离 +7.27% < 15% 阈值，但价格处于99%分位=均值回归风险已高，边际加仓需更谨慎；② VIX 20.78 月跌10%，情绪从恐慌区修复中，非"从低位上升"，暂不构成反转警报；③ 若30天后跌10%，对于99%分位高位资产属于合理回归，5%试探仓位风险可控，后续加仓需更深度回调
  - Quant bearish（强度7）+ Macro risk_on（强度6）形成明确分歧，Risk Officer 信心不足（强度3，backtest 数据缺失），三方无法达成一致 → 以风险为锚给保守方案
  - 纪律提示：量化看空+估值极端高位≠不能参与，而是"用小钱试水+严格止损"。不要因为宏观顺风就在顶部追满仓


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 6
SCORE: +2
KEY_HEADWIND: 10Y收益率升至4.01%（MoM +5%），对风险资产估值形成温和压制。
KEY_TAILWIND: 美元指数大幅走弱（MoM -8.2%）+ 实际利率显著回落（TIP +14.4%），黄金/商品双击环境成型。
ONE_LINER: 美元崩跌+实际利率下行构成强宏观顺风，风险情绪改善（VIX回落），可适度加仓；黄金端尤其受益。
```

**要点速读：**
- **VIX 20.78** — 刚过恐慌线但月跌10%，情绪正在修复
- **DXY 98.43** — 月跌8.2%为罕见级别弱势，美元信用叙事动摇
- **名义利率上 + 实际利率降** — 暗示通胀预期抬头，名义利率被通胀"稀释"
- **货币因素结论**：美元走弱+实际利率下行=黄金双击窗口打开，这是近期最核心的宏观驱动


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: bearish
STRENGTH: 7
KEY_DATA:
  - 价格处于2年历史99%分位，极高位置
  - RSI(14) 58.37，中性偏强，无超买但已缺乏估值优势
  - 价格离MA120偏离+7.27%，但离MA250偏离+12.31%，均值回归压力积累
ONE_LINER: 上升趋势中，但价格处于历史99%分位高位，均值回归压力极大，技术面倾向于回调修正，SIGNAL bearish 与 REGIME uptrend 构成趋势末期背离。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 3
CONCENTRATION_PCT: N/A（回测模式，假设中性持仓）
DRY_POWDER_CNY: N/A（回测模式，无精确现金数据）
PNL_PCT: N/A（回测模式，无持仓均价）
WORST_CASE_LOSS_PCT_AT_-20: N/A（无持仓权重无法计算）
ONE_LINER: 回测模式无持仓明细，基于中性假设风险适中；建议单次建仓不超过总仓位15-20%，待实际持仓数据接入后重新评估。
```

**备注**：当前为 Backtest Mode，Portfolio Summary 未提供具体持仓数字（集中度、现金、浮盈），无法执行完整的集中度/流动性/压力测试评估。以上 SIGNAL 基于"假设中性持仓"前提。如需精确风险评估，请在非回测环境下提供完整 portfolio_summary 数据。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-10-17 > cutoff 2024-12-31)

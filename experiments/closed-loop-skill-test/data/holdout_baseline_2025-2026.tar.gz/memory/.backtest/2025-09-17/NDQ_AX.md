# Committee: NDQ.AX

**Date**: 2025-09-17
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 50000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-09-17",
  "vix": 15.72,
  "tnx": 4.076,
  "usdcny": 7.1142,
  "audcny": 4.7577
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 50000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 10000
  add_levels:
    - "if price drops 3% → add ¥15000"
    - "if price drops 6% → add ¥25000"

RISK_PLAN:
  stop_loss_trigger: "价格跌破前低同时^VIX > 20 → 减仓50%"
  what_if_wrong:
    worst_case_pnl_cny: -10000
    recovery_estimate: "3-6个月"

PERSONAL_NOTE:
  - 用户处于回测模式，假设持仓中性，无明显集中度或浮盈亏压力。
  - 本次建议建仓金额（5万CNY）约占假设子弹规模的5-10%，属于保守试探仓。
  - 宏观极度友好但估值（VALUATION: 2年价格分位99%）和情绪（VIX极低暗示市场自满）构成矛盾，纪律是分批投入，严守止损，避免在情绪顶点一次性追高。
  - **uptrend中ACCUMULATE检查**：1) 价格离120日均线偏离约8%，低于15%警戒线，均值回归风险尚可控。2) VIX处于低位，未从低位开始明显上升，市场尚未出现焦虑信号。3) 若30天后跌10%，当前ACCUMULATE理由（宏观risk_on支撑）的长期性会受质疑，但分批策略允许在更低位加仓摊薄成本，部分对冲此风险。


---

## Macro Strategist (shared)

**Macro 快照评估**

VIX 暴跌近50%至15.72，恐慌几近消散；DXY 单月重挫13.5%至96.87，美元急剧走弱；TIP 上涨15%指向实际利率大幅下行；10Y 收益率同步回落至4.08%。

```
SIGNAL: risk_on
STRENGTH: 8
SCORE: +4
KEY_HEADWIND: VIX低于16暗示市场过度自满，地缘黑天鹅风险被低估
KEY_TAILWIND: 美元急跌+实际利率下行，黄金/商品获得货币面"双击"利好
ONE_LINER: 宏观环境极度友好——风险偏好回暖+美元弱势+实际利率走低，整体偏向加仓，黄金/商品尤佳
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 价格2年分位高达99%，历史极端高位
  - RSI 56.6 中性，未超买
  - 价格离MA120偏离度约8.0%，未触发>15%的均值回归警戒
  - MA20与MA120 spread 7.22%，需观察是否收窄
ONE_LINER: 虽处上升趋势，但价格处于2年99%极高位，上行空间严重受限，技术面显示高处不胜寒，建议中性观望。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式，无具体持仓数据。单资产建议建仓比例上限不超过总仓位的25-35%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-09-17 > cutoff 2024-12-31)

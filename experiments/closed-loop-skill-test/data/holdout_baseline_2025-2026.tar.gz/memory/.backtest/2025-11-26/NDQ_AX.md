# Committee: NDQ.AX

**Date**: 2025-11-26
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.50)
**Dominant view**: macro
**Suggested allocation CNY**: 30000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-11-26",
  "vix": 17.19,
  "tnx": 3.998,
  "usdcny": 7.0845,
  "audcny": 4.5844
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.50
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 30000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 15000
  add_levels:
    - "价格回落至 MA120（约当前价 -5.5%）时加 ¥10,000"
    - "价格回落至 2 年分位 80% 以下时再加 ¥5,000"

RISK_PLAN:
  stop_loss_trigger: "NDQ.AX 跌破 MA120 同时 VIX 升破 25 → 清仓全部试探仓位"
  what_if_wrong:
    worst_case_pnl_cny: -4500
    recovery_estimate: "2-4 个月（基于 uptrend regime 历史回踩中位恢复周期）"

PERSONAL_NOTE:
  - 当前为回测模式，无实际持仓数据，Risk Officer 关键字段全部 N/A，集中度与浮盈浮亏无法评估，整体判断保守度上调。
  - 本次建仓 ¥30,000 仅作为试探性开仓（回测假设总可投金额的 5%），核心逻辑是 Macro risk_on + regime uptrend 提供趋势支撑，而非一次性重仓押注。
  - uptrend ACCUMULATE 三项强制检查：①价格离 MA120 仅偏离 5.59%（<15%），均值回归压力可控；②VIX 数据未提供，无法判断恐慌指数拐点，此为盲点；③若 30 天后跌 10%，Macro risk_on 基础未变且 Quant 未给卖出信号，回调反而构成加仓窗口，理由仍成立。但需注意：Quant 明确指出 2 年价格分位 96%（偏贵）且信号为 neutral，名义利率上行（TNX +3% MoM）对高估值科技股构成结构性压制——这不是"回调即买"的无脑信号，而是"在趋势中用小仓位试探、留足子弹等更好价位"的纪律操作。


---

## Macro Strategist (shared)

```
SIGNAL: risk_on
STRENGTH: 7
SCORE: +3
KEY_HEADWIND: 名义利率上行（TNX +3% MoM），对高估值资产形成压制。
KEY_TAILWIND: 美元走弱（DXY -4.5%）+ 实际利率急降（TIP +13.6%），黄金/商品获双重利好。
ONE_LINER: 恐慌消退、美元崩跌、实际利率下行，宏观环境偏暖，风险资产可适度加仓；黄金受益显著。
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend
SIGNAL: neutral
STRENGTH: 5
KEY_DATA:
  - 2年价格分位96%，估值偏高，均值回归风险累积
  - RSI(14) 51.40，中性区域，无超买或超卖信号
  - 价格离MA120偏离度仅5.59%，趋势支撑存在但上行空间受压
ONE_LINER: 价格处于历史高位，RSI中性，上升趋势未破但调整压力显现，SIGNAL=neutral反映REGIME=uptrend中的高位谨慎逻辑。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A（回测模式，无持仓数据）
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 回测模式下无具体持仓数据，假设中性持仓，建议单资产集中度≤30%，建仓比例上限基于可投现金。
```

---

**补充说明**：
- 本次为历史回测，未提供 portfolio_summary 具体字段（持仓、均价、现金、总资产），故所有定量指标标记为 N/A
- Dreaming 长期行为模式暂无数据，无法判断用户是否有情绪化追涨历史
- 在有完整持仓数据的实盘评估中，将输出真实集中度、浮盈/浮亏及压力测试结果


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-11-26 > cutoff 2024-12-31)

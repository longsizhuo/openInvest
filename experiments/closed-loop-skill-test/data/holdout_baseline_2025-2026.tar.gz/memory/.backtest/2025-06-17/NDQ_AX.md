# Committee: NDQ.AX

**Date**: 2025-06-17
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.62)
**Dominant view**: macro
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-17",
  "vix": 21.6,
  "tnx": 4.393,
  "usdcny": 7.179,
  "audcny": 4.6714
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD
CONFIDENCE: 0.62
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 0
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: none
  first_tranche_cny: 0
  add_levels:
    - "若VIX回落至18以下且NDQ.AX回踩MA120（约¥48.03）获支撑，可建5%试探仓"
    - "若价格跌至2年分位70%附近且Macro转neutral，可追加至10%"

RISK_PLAN:
  stop_loss_trigger: "已持仓部分：VIX持续>25或NDQ.AX跌破MA120支撑¥48.03且收盘确认 → 减仓50%；VIX>30或跌破¥46 → 清仓"
  what_if_wrong:
    worst_case_pnl_cny: N/A（回测模式，持仓规模未知，基于最坏情景-4%估算）
    recovery_estimate: "range_bound regime下若回踩MA120后反弹，预计2-4周修复；若破位下行，可能需2-3个月"

PERSONAL_NOTE:
  - 回测模式下持仓数据缺失，Risk Officer无法评估真实集中度与现金流，裁决以防御为先
  - **估值警报**：价格处于2年88%分位（远超70%阈值），trailing估值偏贵，叠加10Y收益率4.39%高位压制科技股估值倍数，追高风险极大
  - **INDEP_DEFENSE_FLAG生效**：VIX从16.77急升至21.6进入恐慌区，即使Quant技术面中性（RSI 59、均线纠缠），市场情绪已转向防御——这是独立于regime的崩盘哨兵，任何加仓念头必须降一档
  - 三方信号一致偏空：Macro明确risk_off（SCORE -2）、Quant中性无做多催化、Risk concerned，无任何维度支撑立即建仓
  - 当前不是"持有现金焦虑"的时机——VIX>20时持币本身就是alpha，等VIX回落+价格回踩MA120才是合理进场窗口；若届时仍无仓位，可建5%试探仓+网格加仓，不必一次打满


---

## Macro Strategist (shared)

**宏观评估**

SIGNAL: risk_off
STRENGTH: 5
SCORE: -2
KEY_HEADWIND: 10Y收益率4.39%高位企稳+VIX从16.77急升至21.6进入恐慌区，无风险利率飙升压制风险资产估值。
KEY_TAILWIND: 美元指数近月暴跌7.2%至98.82+TIP月涨4.12%（实际利率下行），双击逻辑利好黄金/商品。
ONE_LINER: 利率飙升叠加VIX破20，风险资产承压明确，建议减仓或维持；黄金/商品有货币因素对冲但整体不宜加码。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound  
SIGNAL: neutral  
STRENGTH: 5  
KEY_DATA:  
  - 2年价格分位88%，处于高位估值偏高  
  - RSI(14) 59.30，中性区域无超买/超卖  
  - MA20与MA120价差仅1.81%，均线纠缠趋势不明  
ONE_LINER: 价格处历史高位但RSI中性且均线纠缠，range_bound下技术面偏中性，信号为neutral，支撑位MA120 48.03。

### Risk Officer
SIGNAL: concerned
STRENGTH: 5
CONCENTRATION_PCT: N/A
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: -4% (基于中性持仓假设估算)
ONE_LINER: 回测模式下持仓数据缺失，无法评估真实集中度与现金流；建议在完整数据下谨慎建仓，单资产占比上限不超过30%。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-17 > cutoff 2024-12-31)

# Committee: NDQ.AX

**Date**: 2025-01-09
**Symbol**: NDQ.AX
**Verdict**: ACCUMULATE (confidence 0.65)
**Dominant view**: macro
**Suggested allocation CNY**: 5000

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-01-09",
  "vix": 17.7,
  "tnx": 4.693,
  "usdcny": 7.3315,
  "audcny": 4.5537
}
```

---

## CIO Memo (Round 3)

VERDICT: ACCUMULATE
CONFIDENCE: 0.65
DOMINANT_VIEW: macro
SUGGESTED_ALLOC_CNY: 5000
TRIM_REASON: N/A
REENTRY_PRICE: N/A
REENTRY_CONDITION: N/A
EXPECTED_PATH: N/A

EXECUTION_PLAN:
  mode: pyramid
  first_tranche_cny: 5000
  add_levels:
    - “如果价格从当前回撤至MA120（约45.09）附近，可追加 ¥15,000”
    - “如果价格进一步跌至MA120下方5%且RSI<40，可再追加 ¥10,000”

RISK_PLAN:
  stop_loss_trigger: “跌破关键支撑 MA120 (45.09) 同时 VIX 突破 22 或 DXY 持续站稳 110 上方 → 减仓50%”
  what_if_wrong:
    worst_case_pnl_cny: -2500
    recovery_estimate: “6-12个月（取决于宏观紧缩持续时间）”

PERSONAL_NOTE:
  - 当前处于回测模式，无真实持仓上下文，假设为中性仓位，本次建仓作为试探性起点。
  - 本次建议金额占常规子弹比例极低（约0.5%-1%），旨在建立观察仓，严守纪律等待更佳风险回报比。
  - uptrend 中 ACCUMULATE 的怀疑清单检查：1) 价格偏离 MA120 为11.39%，未超过15%阈值，均值回归风险可控。2) VIX 已从高位回落，并未出现从低位急速上升的焦虑信号。3) 若30天后跌10%，考虑到宏观面（10Y收益率飙升、DXY走强）构成的硬约束，当前“趋势延续”的ACCUMULATE理由将受到严峻挑战，需准备减仓。**结论：宏观风险（risk_off）压倒技术趋势（uptrend），因此只给予最低限度试探仓，而非趋势跟随型加仓。**


---

## Macro Strategist (shared)

根据提供数据直接评估：

```
SIGNAL: risk_off
STRENGTH: 6
SCORE: -2
KEY_HEADWIND: 10Y收益率飙至4.69%、DXY破109、实际利率上行——金融条件急剧收紧，黄金/商品承压双杀。
KEY_TAILWIND: VIX从高位回落35%至17.7，市场恐慌情绪显著消退，风险资产定价暂稳。
ONE_LINER: 美债收益率与美元同步飙升，流动性收紧信号明确；组合偏向减仓防守，尤其回避久期资产与黄金。
```

**核心逻辑**：
- **利率端**：TNX 月涨140%至4.69%，紧缩预期主导，压制一切长久期资产估值
- **货币端**：DXY 109+高位继续走强 + TIP下跌（实际利率上行）= 黄金/商品"双杀"环境成型
- **情绪端**：VIX回落是唯一亮点，但在收益率暴力上行背景下，仅能支撑SCORE在-2而非更悲观

⚠️ **当前宏观组合对黄金/大宗商品极不友好**：美元走强 + 实际利率上行 = 双重逆风。


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: uptrend  
SIGNAL: bullish  
STRENGTH: 6  
KEY_DATA:  
  - 价格2年分位98%，估值偏高风险累积  
  - RSI 55.25中性偏多，未超买  
  - 价格离MA120偏离11.39%，低于15%均值回归阈值  
ONE_LINER: 上升趋势中，价格高位但RSI未超买且衰竭指标未亮红灯，支撑位MA120=45.09，信号看涨但需谨慎高分位。

### Risk Officer
```
SIGNAL: ok
STRENGTH: 2
CONCENTRATION_PCT: N/A (回测模式)
DRY_POWDER_CNY: N/A (回测模式)
PNL_PCT: N/A (回测模式)
WORST_CASE_LOSS_PCT_AT_-20: N/A (回测模式)
ONE_LINER: 回测模式无真实持仓数据，假设中性持仓无极端集中度；风险评估仅基于技术/宏观信号，无仓位风险维度可评。
```

**补充说明（给 CIO）**：
- 回测模式下持仓上下文无法精确还原，所有财务指标（集中度/浮盈/子弹/压力测试）均无法计算
- Dreaming 暂无历史行为模式数据
- 本评估 **不构成仓位建议**，仅确认技术/宏观层面无额外风险信号需要叠加
- 若回测推进到需要实际建仓环节，需还原完整 portfolio_context 后重新评估


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-01-09 > cutoff 2024-12-31)

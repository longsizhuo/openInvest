# Committee: NDQ.AX

**Date**: 2025-06-26
**Symbol**: NDQ.AX
**Verdict**: HOLD (confidence 0.50)
**Dominant view**: quant
**Suggested allocation CNY**: 0

---

## Macro Context Snapshot (for post-hoc attribution)

```json
{
  "captured_at": "2025-06-26",
  "vix": 16.59,
  "tnx": 4.253,
  "usdcny": 7.1764,
  "audcny": 4.6809
}
```

---

## CIO Memo (Round 3)

VERDICT: HOLD  
CONFIDENCE: 0.5  
DOMINANT_VIEW: quant  
SUGGESTED_ALLOC_CNY: 0  
TRIM_REASON: N/A  
REENTRY_PRICE: N/A  
REENTRY_CONDITION: N/A  
EXPECTED_PATH: N/A  

EXECUTION_PLAN:  
  mode: none  
  first_tranche_cny: 0  
  add_levels: []  

RISK_PLAN:  
  stop_loss_trigger: 若价格跌破 MA120（约 47.99）同时成交量持续放大（RVOL > 1.5x）→ 减仓 30%  
  what_if_wrong:  
    worst_case_pnl_cny: 按当前价格回撤 20% 估算，具体金额取决于持仓规模  
    recovery_estimate: 3-6 个月（基于历史高位区间震荡及估值回归所需时间）  

PERSONAL_NOTE:  
  - 回测模式，假设持仓中性，无极端集中度。  
  - 本次建议 HOLD，不新增仓位，不减仓，维持现有风险敞口。  
  - 操作纪律：价格处于 2 年历史 94% 高位且 RSI 接近超买，短期技术面承压明显；建议耐心等待价格回调至 MA120 支撑位附近或 RSI 回落至 50 以下再考虑加仓，避免追高。


---

## Macro Strategist (shared)

**宏观快照分析完毕，数据如下：**

- TNX 4.25% / MoM +60.98% → 名义利率暴力拉升，债市剧烈重新定价
- VIX 16.59 / MoM -22.22% → 恐慌回落至中性偏舒适区间
- DXY 97.15 / MoM -8.56% → 美元显著走弱
- TIP +2.05% → 实际利率下行，黄金利好

---

```
SIGNAL: neutral
STRENGTH: 4
SCORE: -1
KEY_HEADWIND: 10Y国债收益率单月飙升61%至4.25%，利率重新定价速度异常，对久期资产和估值形成压制
KEY_TAILWIND: 美元指数单月下挫8.6%至97.15，实际利率同步下行，构成黄金与大宗商品的"双击"货币环境
ONE_LINER: 利率剧震与美元走弱并存，信号矛盾偏中性——风险资产维持仓位，黄金/商品类可小幅加仓
```


---

## Round 1 — Independent Briefs


### Quant Analyst
REGIME: range_bound
SIGNAL: bearish
STRENGTH: 7
KEY_DATA:
  - 价格处于2年历史94%分位，估值绝对高位
  - RSI 67.63 接近超买区，上涨动能减弱
  - 成交量放大（RVOL 1.39x）伴随高位，或为卖压信号
ONE_LINER: 尽管处于 range_regime，但价格于历史极高位且RSI接近超买，技术面承压，SIGNAL bearish，阻力位看近期高点，支撑位看MA120（47.99）。

### Risk Officer
SIGNAL: ok
STRENGTH: 0
CONCENTRATION_PCT: N/A (回测模式，持仓上下文未知)
DRY_POWDER_CNY: N/A
PNL_PCT: N/A
WORST_CASE_LOSS_PCT_AT_-20: N/A
ONE_LINER: 技术面（BULLISH）与宏观面（RISK_ON）信号积极，无集中度与流动性数据佐证风险，回测模式下建议保持观察。


---

## Round 2 — Cross-Challenge Adjustments


### Quant adjusted (after seeing Risk)


### Risk adjusted (after seeing Quant)


---

**Contaminated**: false (decision_date 2025-06-26 > cutoff 2024-12-31)
